/* ModGuard popup — client-side mod scanner (free tier, 5/month). */
const MONTHLY_LIMIT = 5;

const INDICATORS = [
  // Credential / token theft
  { re: /launcher_profiles\.json/i, severity: "critical", category: "Credential theft", detail: "Reads Minecraft launcher profile (Microsoft auth tokens)." },
  { re: /usercache\.json/i, severity: "high", category: "Credential theft", detail: "Reads Minecraft usercache." },
  { re: /\.minecraft[\\/]/i, severity: "medium", category: "Filesystem", detail: "Touches .minecraft directory." },
  { re: /discord[\\/]Local Storage/i, severity: "critical", category: "Credential theft", detail: "Reads Discord local storage (token theft pattern)." },
  { re: /AppData[\\/](Roaming|Local)[\\/]discord/i, severity: "critical", category: "Credential theft", detail: "Accesses Discord app data." },
  { re: /Cookies[- ]journal|Login Data|Web Data/i, severity: "high", category: "Credential theft", detail: "Reads browser credential/cookie databases." },
  { re: /chrome[\\/]User Data/i, severity: "high", category: "Credential theft", detail: "Accesses Chrome user data." },
  { re: /firefox[\\/]Profiles/i, severity: "high", category: "Credential theft", detail: "Accesses Firefox profiles." },
  // Network exfil
  { re: /discord(app)?\.com\/api\/webhooks\//i, severity: "critical", category: "Network exfiltration", detail: "Hardcoded Discord webhook URL — common stealer beacon." },
  { re: /pastebin\.com\/raw\//i, severity: "high", category: "Network exfiltration", detail: "Pulls payload from Pastebin raw URL." },
  { re: /(anonfiles|gofile|bashupload|transfer\.sh)/i, severity: "high", category: "Network exfiltration", detail: "References anonymous file host." },
  { re: /\b(?:\d{1,3}\.){3}\d{1,3}\b/, severity: "medium", category: "Network", detail: "Hardcoded IP address literal." },
  // RCE
  { re: /Runtime\.getRuntime\s*\(\s*\)\s*\.\s*exec/i, severity: "high", category: "Code execution", detail: "Calls Runtime.exec — can launch OS commands." },
  { re: /ProcessBuilder/i, severity: "high", category: "Code execution", detail: "Uses ProcessBuilder — can launch subprocesses." },
  { re: /URLClassLoader/i, severity: "high", category: "Code execution", detail: "Loads classes from URLs (remote code loading)." },
  { re: /defineClass\s*\(/i, severity: "medium", category: "Code execution", detail: "Defines classes from raw bytes." },
  { re: /sun\.misc\.Unsafe/i, severity: "medium", category: "Code execution", detail: "Uses sun.misc.Unsafe." },
  // Reflection
  { re: /setAccessible\s*\(\s*true\s*\)/i, severity: "medium", category: "Reflection abuse", detail: "Calls setAccessible(true) — bypasses Java access controls." },
  { re: /Method\s*\.\s*invoke\s*\(/i, severity: "low", category: "Reflection abuse", detail: "Invokes methods reflectively (Method.invoke)." },
  // Agent / classloader hijack
  { re: /Instrumentation\b[\s\S]{0,80}addTransformer/i, severity: "high", category: "ClassLoader hijack", detail: "Registers a class-file transformer." },
  { re: /Premain-Class\s*:/i, severity: "high", category: "ClassLoader hijack", detail: "Declares a Java agent (Premain-Class)." },
  { re: /Agent-Class\s*:/i, severity: "high", category: "ClassLoader hijack", detail: "Declares an attach-time Java agent (Agent-Class)." },
  // Clipboard
  { re: /getSystemClipboard\s*\(/i, severity: "medium", category: "Clipboard hijack", detail: "Reads the system clipboard." },
  { re: /\bStringSelection\b/i, severity: "medium", category: "Clipboard hijack", detail: "Writes to the system clipboard." },
  // Persistence
  { re: /Startup\\.+\.(bat|cmd|exe|vbs)/i, severity: "critical", category: "Persistence", detail: "Writes to Windows Startup folder." },
  { re: /HKEY_(CURRENT|LOCAL)_(USER|MACHINE)/i, severity: "high", category: "Persistence", detail: "References Windows registry." },
  { re: /schtasks(\s|\.exe)/i, severity: "high", category: "Persistence", detail: "Uses schtasks (scheduled tasks)." },
  // In-game grief
  { re: /(server|Bukkit|getServer\(\))\.dispatchCommand/i, severity: "high", category: "In-game grief", detail: "Dispatches server commands programmatically." },
  { re: /performCommand\s*\(/i, severity: "high", category: "In-game grief", detail: "Forces the player to run a command." },
  { re: /["']\/pay\s+\S+/i, severity: "critical", category: "In-game grief", detail: "Hardcoded /pay command — direct money theft." },
  { re: /["']\/(op|deop|give\s+@?\w+|tp\s+@?\w+|gamemode\s+creative)\b/i, severity: "high", category: "In-game grief", detail: "Hardcoded admin/cheat command." },
  // Account hijack
  { re: /login\.microsoftonline\.com|login\.live\.com\/oauth20/i, severity: "high", category: "Account hijack", detail: "Talks to Microsoft OAuth endpoints." },
  { re: /api\.minecraftservices\.com|sessionserver\.mojang\.com/i, severity: "high", category: "Account hijack", detail: "Calls Mojang/Microsoft session APIs directly." },
];

const SUSPICIOUS_DOMAINS = [/\bwebhook\.site\b/i, /\bngrok\.io\b/i, /\bduckdns\.org\b/i, /\bno-ip\.org\b/i];
const SEV_WEIGHT = { low: 2, medium: 6, high: 14, critical: 28 };
const BASE64_DECODE_RE = /Base64[\s\S]{0,40}\.decode\s*\(|getDecoder\s*\(\s*\)\s*\.\s*decode\s*\(/i;
const EXEC_AFTER_DECODE_RE = /(defineClass\s*\(|Runtime\.getRuntime\s*\(\s*\)\s*\.\s*exec|ProcessBuilder)/i;

function bytesToText(u8) {
  try { return new TextDecoder("utf-8", { fatal: false }).decode(u8); } catch { return ""; }
}

function scanJar(bytes) {
  const findings = [];
  let files;
  try { files = fflate.unzipSync(bytes); }
  catch {
    return { findings: [{ severity: "high", category: "Format", detail: "Not a valid ZIP/JAR archive." }], score: 100, manifest: {}, stats: { fileCount: 0, classCount: 0 } };
  }
  const names = Object.keys(files);
  const classFiles = names.filter(n => n.endsWith(".class"));
  const nestedJars = names.filter(n => n.endsWith(".jar")).length;

  let shortNames = 0;
  for (const n of classFiles) {
    const base = n.split("/").pop().replace(/\.class$/, "");
    if (base.length <= 2) shortNames++;
  }
  const obfRatio = classFiles.length ? shortNames / classFiles.length : 0;
  if (obfRatio > 0.4 && classFiles.length > 20) {
    findings.push({ severity: "medium", category: "Obfuscation", detail: `High ratio of short class names (${Math.round(obfRatio * 100)}%).` });
  }
  if (nestedJars > 0) {
    findings.push({ severity: "high", category: "Dropper", detail: `Contains ${nestedJars} nested .jar file(s) — dropper pattern.` });
  }

  // Manifest parse
  const manifest = {};
  const fabricBytes = files["fabric.mod.json"];
  if (fabricBytes) {
    try {
      const j = JSON.parse(bytesToText(fabricBytes));
      manifest.modName = j.name; manifest.modId = j.id; manifest.version = j.version;
      if (Array.isArray(j.authors) && j.authors.length) {
        manifest.author = typeof j.authors[0] === "string" ? j.authors[0] : j.authors[0]?.name;
      }
    } catch {}
  }
  const forgeBytes = files["META-INF/mods.toml"] || files["META-INF/neoforge.mods.toml"];
  if (forgeBytes) {
    const t = bytesToText(forgeBytes);
    manifest.modId ??= t.match(/modId\s*=\s*"([^"]+)"/)?.[1];
    manifest.modName ??= t.match(/displayName\s*=\s*"([^"]+)"/)?.[1];
    manifest.author ??= t.match(/authors?\s*=\s*"([^"]+)"/)?.[1];
    manifest.version ??= t.match(/version\s*=\s*"([^"]+)"/)?.[1];
  }
  if (!manifest.author) {
    findings.push({ severity: "low", category: "Manifest", detail: "No author declared in mod manifest." });
  }

  const seen = new Set();
  let chainFlagged = false;
  for (const name of names) {
    const f = files[name];
    if (!f || f.length === 0 || name.endsWith("/")) continue;
    if (f.length > 5_000_000) continue;
    const text = bytesToText(f);
    if (!text) continue;
    for (const ind of INDICATORS) {
      const key = ind.category + ":" + ind.detail;
      if (seen.has(key)) continue;
      const m = text.match(ind.re);
      if (m) {
        seen.add(key);
        findings.push({ severity: ind.severity, category: ind.category, detail: ind.detail, evidence: `${name} — "${m[0].slice(0, 100)}"` });
      }
    }
    for (const dom of SUSPICIOUS_DOMAINS) {
      const key = "dom:" + dom.source;
      if (seen.has(key)) continue;
      const m = text.match(dom);
      if (m) { seen.add(key); findings.push({ severity: "medium", category: "Network", detail: `Suspicious domain: ${m[0]}`, evidence: name }); }
    }
    if (!chainFlagged && BASE64_DECODE_RE.test(text) && EXEC_AFTER_DECODE_RE.test(text)) {
      chainFlagged = true;
      findings.push({ severity: "high", category: "Code execution", detail: "Base64 decode + defineClass/exec/ProcessBuilder in same file — hidden-payload chain.", evidence: name });
    }
  }

  const hasMod = !!(files["fabric.mod.json"] || files["META-INF/mods.toml"] || files["META-INF/neoforge.mods.toml"] || files["mcmod.info"]);
  if (classFiles.length > 0 && classFiles.length < 3 && !hasMod) {
    findings.push({ severity: "medium", category: "Stub jar", detail: `Only ${classFiles.length} class file(s) and no mod manifest — looks like a stub.` });
  } else if (classFiles.length === 0 && !hasMod && nestedJars === 0) {
    findings.push({ severity: "medium", category: "Stub jar", detail: "No classes and no mod manifest — not a functional mod." });
  }

  let score = 0;
  for (const f of findings) score += SEV_WEIGHT[f.severity];
  score = Math.min(100, score);
  return { findings, score, manifest, stats: { fileCount: names.length, classCount: classFiles.length } };
}

function verdict(score) {
  if (score >= 60) return { label: "Confirmed malicious", cls: "v-bad" };
  if (score >= 35) return { label: "Likely malicious", cls: "v-bad" };
  if (score >= 18) return { label: "Suspicious", cls: "v-sus" };
  if (score >= 6) return { label: "Low risk", cls: "v-low" };
  return { label: "Looks safe", cls: "v-safe" };
}

// Quota
function monthKey() { const d = new Date(); return `${d.getFullYear()}-${d.getMonth() + 1}`; }
async function getQuota() {
  const k = monthKey();
  const data = await chrome.storage.local.get(["modguard_quota"]);
  const q = data.modguard_quota;
  if (!q || q.month !== k) return { month: k, count: 0 };
  return q;
}
async function bumpQuota() {
  const q = await getQuota();
  q.count++;
  await chrome.storage.local.set({ modguard_quota: q });
  return q;
}

async function renderQuota() {
  const q = await getQuota();
  document.getElementById("quota").textContent = `${q.count} / ${MONTHLY_LIMIT} this month`;
  if (q.count >= MONTHLY_LIMIT) {
    document.getElementById("limit").classList.remove("hidden");
    document.getElementById("drop").style.opacity = "0.5";
    document.getElementById("drop").style.pointerEvents = "none";
  }
}

function renderResult(name, report) {
  const v = verdict(report.score);
  const m = report.manifest;
  const metaParts = [];
  if (m.modName) metaParts.push(`<b>${escapeHtml(m.modName)}</b>`);
  if (m.version) metaParts.push(`v${escapeHtml(m.version)}`);
  if (m.author) metaParts.push(`by ${escapeHtml(m.author)}`);
  metaParts.push(`${report.stats.classCount} classes`);

  const sevOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  const sorted = [...report.findings].sort((a, b) => sevOrder[a.severity] - sevOrder[b.severity]);

  const findingsHtml = sorted.length
    ? sorted.map(f => `
      <div class="f ${f.severity}">
        <div class="f-head"><span class="f-cat">${escapeHtml(f.category)}</span><span class="f-sev">${f.severity}</span></div>
        <div class="f-detail">${escapeHtml(f.detail)}</div>
      </div>`).join("")
    : `<div class="f low"><div class="f-detail">No malicious patterns matched. Still — install from CurseForge/Modrinth.</div></div>`;

  const el = document.getElementById("result");
  el.innerHTML = `
    <div class="verdict ${v.cls}">
      <span>${v.label}</span>
      <span class="score">score ${report.score}/100</span>
    </div>
    <div class="meta"><div>${escapeHtml(name)}</div><div>${metaParts.join(" · ")}</div></div>
    <div class="findings">${findingsHtml}</div>
  `;
  el.classList.remove("hidden");
}

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
}

async function handleFile(file) {
  if (!file) return;
  if (!/\.jar$/i.test(file.name)) { setStatus("That's not a .jar file."); return; }
  const q = await getQuota();
  if (q.count >= MONTHLY_LIMIT) { renderQuota(); return; }

  setStatus(`Scanning ${file.name}…`);
  document.getElementById("result").classList.add("hidden");
  try {
    const buf = new Uint8Array(await file.arrayBuffer());
    const report = scanJar(buf);
    await bumpQuota();
    setStatus("");
    renderResult(file.name, report);
    renderQuota();
  } catch (e) {
    setStatus("Scan failed: " + (e?.message || e));
  }
}

function setStatus(msg) {
  const s = document.getElementById("status");
  if (!msg) { s.classList.add("hidden"); s.textContent = ""; return; }
  s.textContent = msg; s.classList.remove("hidden");
}

document.addEventListener("DOMContentLoaded", () => {
  renderQuota();
  const drop = document.getElementById("drop");
  const file = document.getElementById("file");
  file.addEventListener("change", e => handleFile(e.target.files?.[0]));
  drop.addEventListener("dragover", e => { e.preventDefault(); drop.classList.add("dragover"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("dragover"));
  drop.addEventListener("drop", e => {
    e.preventDefault(); drop.classList.remove("dragover");
    handleFile(e.dataTransfer?.files?.[0]);
  });
});
