
-- Roles enum + table
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text,
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO anon, authenticated;
GRANT INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Profiles public read" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, username)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)));
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Verdict enum
CREATE TYPE public.verdict AS ENUM ('safe', 'low_risk', 'suspicious', 'likely_malicious', 'confirmed_malicious', 'unknown');

-- Known mods (admin-curated)
CREATE TABLE public.known_mods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sha256 text NOT NULL UNIQUE,
  name text NOT NULL,
  author text,
  verdict public.verdict NOT NULL DEFAULT 'unknown',
  source text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.known_mods TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.known_mods TO authenticated;
GRANT ALL ON public.known_mods TO service_role;
ALTER TABLE public.known_mods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Known mods public read" ON public.known_mods FOR SELECT USING (true);
CREATE POLICY "Admins manage known mods" ON public.known_mods FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE INDEX known_mods_name_idx ON public.known_mods USING gin (to_tsvector('simple', name));

-- Scans
CREATE TABLE public.scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  sha256 text NOT NULL,
  code_verdict public.verdict NOT NULL,
  reputation_verdict public.verdict NOT NULL,
  final_verdict public.verdict NOT NULL,
  findings jsonb NOT NULL DEFAULT '[]'::jsonb,
  reputation jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.scans TO authenticated;
GRANT ALL ON public.scans TO service_role;
ALTER TABLE public.scans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own scans" ON public.scans FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own scans" ON public.scans FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users delete own scans" ON public.scans FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX scans_user_idx ON public.scans (user_id, created_at DESC);

-- Reputation cache (server-only)
CREATE TABLE public.mod_reputation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cache_key text NOT NULL UNIQUE,
  payload jsonb NOT NULL,
  fetched_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.mod_reputation TO service_role;
ALTER TABLE public.mod_reputation ENABLE ROW LEVEL SECURITY;
-- No policies = no client access. Service role bypasses RLS.

-- Reports
CREATE TYPE public.report_status AS ENUM ('open', 'investigating', 'confirmed', 'dismissed');

CREATE TABLE public.reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mod_name text NOT NULL,
  author text,
  sha256 text,
  description text NOT NULL,
  status public.report_status NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.reports TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.reports TO authenticated;
GRANT ALL ON public.reports TO service_role;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Reports public read" ON public.reports FOR SELECT USING (true);
CREATE POLICY "Users create reports" ON public.reports FOR INSERT TO authenticated WITH CHECK (auth.uid() = reporter_id);
CREATE POLICY "Users edit own reports" ON public.reports FOR UPDATE TO authenticated USING (auth.uid() = reporter_id OR public.has_role(auth.uid(), 'admin')) WITH CHECK (auth.uid() = reporter_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users delete own reports" ON public.reports FOR DELETE TO authenticated USING (auth.uid() = reporter_id OR public.has_role(auth.uid(), 'admin'));

-- Report votes
CREATE TABLE public.report_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES public.reports(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vote smallint NOT NULL CHECK (vote IN (-1, 1)),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (report_id, user_id)
);
GRANT SELECT ON public.report_votes TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.report_votes TO authenticated;
GRANT ALL ON public.report_votes TO service_role;
ALTER TABLE public.report_votes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Votes public read" ON public.report_votes FOR SELECT USING (true);
CREATE POLICY "Users manage own votes" ON public.report_votes FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Report comments
CREATE TABLE public.report_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES public.reports(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.report_comments TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.report_comments TO authenticated;
GRANT ALL ON public.report_comments TO service_role;
ALTER TABLE public.report_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Comments public read" ON public.report_comments FOR SELECT USING (true);
CREATE POLICY "Users post comments" ON public.report_comments FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users edit own comments" ON public.report_comments FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users delete own comments" ON public.report_comments FOR DELETE TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- Articles
CREATE TABLE public.articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  summary text NOT NULL,
  body text NOT NULL,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.articles TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.articles TO authenticated;
GRANT ALL ON public.articles TO service_role;
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Published articles public read" ON public.articles FOR SELECT USING (published_at IS NOT NULL OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage articles" ON public.articles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER touch_profiles BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_known_mods BEFORE UPDATE ON public.known_mods FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_reports BEFORE UPDATE ON public.reports FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_articles BEFORE UPDATE ON public.articles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Seed articles
INSERT INTO public.articles (slug, title, summary, body, published_at) VALUES
('how-mod-stealers-work', 'How Minecraft Mod Stealers Work', 'A breakdown of how malicious mods steal Microsoft accounts, Discord tokens, and game items.', E'## The basics\n\nMost malicious Minecraft mods are token stealers. They read files from your `.minecraft` folder (especially `launcher_profiles.json` and `usercache.json`) and POST them to a Discord webhook or remote server.\n\n## Common attack patterns\n\n- **Microsoft auth token theft** — your Microsoft refresh token gets exfiltrated. The attacker then logs in as you.\n- **Discord token theft** — mods that read `%appdata%/discord/Local Storage` and steal your session.\n- **Browser cookie theft** — Chrome/Edge/Firefox cookie databases copied off your machine.\n- **In-game item griefing** — mods that issue `/give`, `/drop`, or transfer items to another account.\n\n## How to protect yourself\n\n1. **Only download mods from CurseForge or Modrinth.** Avoid random Discord links and shady "free hack client" sites.\n2. **Enable 2FA** on your Microsoft and Discord accounts.\n3. **Scan every mod** before adding it to your mods folder.\n4. **Check the author** — established mod authors have history. New accounts with one mod are a red flag.', now()),
('safe-mod-sources', 'Where to Download Mods Safely', 'A short guide to trusted mod sources and red flags to avoid.', E'## Trusted sources\n\n- **CurseForge** (curseforge.com)\n- **Modrinth** (modrinth.com)\n- **Official mod author GitHub releases**\n\n## Red flags\n\n- Discord servers offering "exclusive" or "leaked" mods\n- "Free hack client" websites\n- Mods with no GitHub source\n- Authors with no history outside this one mod\n- Mods that require disabling antivirus\n\n## Use ModGuard\n\nUpload any `.jar` before installing it. ModGuard scans the bytecode for known stealer patterns and cross-checks the mod and author across CurseForge, Modrinth, GitHub, and Reddit.', now()),
('enabling-2fa', 'Enable 2FA on Microsoft and Discord', 'Step-by-step: secure your accounts in under 5 minutes.', E'## Microsoft\n\n1. Go to https://account.microsoft.com/security\n2. Click "Two-step verification" → Turn on\n3. Use the Microsoft Authenticator app (not SMS — SMS can be SIM-swapped)\n\n## Discord\n\n1. User Settings → My Account → Enable Two-Factor Auth\n2. Use an authenticator app (Authy, Google Authenticator, 1Password)\n3. Save your backup codes somewhere offline\n\n## Why this matters\n\nEven if a malicious mod steals your password or session token, 2FA stops the attacker at the login step.', now());

-- Seed a few known-malicious hashes (fracturizer-family example placeholders)
INSERT INTO public.known_mods (sha256, name, author, verdict, source, notes) VALUES
('814f6c25c3e02b9c4e6f5d9a3a7a5b2e9b1c0e2d4f6a8b9c1d3e5f7a9b1c3d5e', 'Fracturizer (sample)', 'unknown', 'confirmed_malicious', 'https://github.com/fractureiser-investigation/fractureiser', 'Known stealer family that targets Microsoft tokens and Discord credentials.'),
('0000000000000000000000000000000000000000000000000000000000000001', 'Example Safe Mod', 'TrustedAuthor', 'safe', 'https://modrinth.com', 'Placeholder — replace with real verified hash.');
