
CREATE TYPE public.verdict AS ENUM (
  'safe', 'low_risk', 'suspicious', 'likely_malicious', 'confirmed_malicious', 'unknown'
);

-- Malware signature DB
CREATE TABLE public.known_mods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sha256 text NOT NULL UNIQUE,
  name text NOT NULL,
  author text,
  verdict public.verdict NOT NULL DEFAULT 'unknown',
  source text,
  notes text,
  game_id text,
  hit_count integer NOT NULL DEFAULT 1,
  first_seen timestamptz NOT NULL DEFAULT now(),
  last_seen timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX known_mods_verdict_idx ON public.known_mods (verdict);
CREATE INDEX known_mods_last_seen_idx ON public.known_mods (last_seen DESC);

GRANT SELECT ON public.known_mods TO anon, authenticated;
GRANT ALL ON public.known_mods TO service_role;
ALTER TABLE public.known_mods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "known_mods readable by all" ON public.known_mods
  FOR SELECT TO anon, authenticated USING (true);

-- Public scan telemetry feed
CREATE TABLE public.scan_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sha256 text,
  file_name text NOT NULL,
  game_id text NOT NULL,
  verdict public.verdict NOT NULL,
  severity_counts jsonb NOT NULL DEFAULT '{}'::jsonb,
  source text NOT NULL CHECK (source IN ('file','url')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX scan_events_created_at_idx ON public.scan_events (created_at DESC);
CREATE INDEX scan_events_sha256_idx ON public.scan_events (sha256);
CREATE INDEX scan_events_game_idx ON public.scan_events (game_id);
CREATE INDEX scan_events_verdict_idx ON public.scan_events (verdict);

GRANT SELECT ON public.scan_events TO anon, authenticated;
GRANT ALL ON public.scan_events TO service_role;
ALTER TABLE public.scan_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "scan_events readable by all" ON public.scan_events
  FOR SELECT TO anon, authenticated USING (true);
-- inserts only happen via service_role inside server fns

-- Reputation cache (server-only)
CREATE TABLE public.mod_reputation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cache_key text NOT NULL UNIQUE,
  payload jsonb NOT NULL,
  fetched_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.mod_reputation TO service_role;
ALTER TABLE public.mod_reputation ENABLE ROW LEVEL SECURITY;
-- no policies = service_role only via GRANT bypass
