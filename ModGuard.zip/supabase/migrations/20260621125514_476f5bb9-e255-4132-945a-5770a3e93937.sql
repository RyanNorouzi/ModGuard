-- ModGuard Process Monitor — backend tables
CREATE TABLE public.monitor_agents (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  label          text        NOT NULL,
  secret_hash    text        NOT NULL,
  hostname       text,
  os             text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  last_seen_at   timestamptz
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monitor_agents TO authenticated;
GRANT ALL ON public.monitor_agents TO service_role;
ALTER TABLE public.monitor_agents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "agents owned by user" ON public.monitor_agents FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.monitor_snapshots (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id   uuid        NOT NULL REFERENCES public.monitor_agents(id) ON DELETE CASCADE,
  user_id    uuid        NOT NULL,
  taken_at   timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.monitor_snapshots TO authenticated;
GRANT ALL ON public.monitor_snapshots TO service_role;
ALTER TABLE public.monitor_snapshots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "snapshots owned by user" ON public.monitor_snapshots FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.process_samples (
  id                   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_id          uuid        NOT NULL REFERENCES public.monitor_snapshots(id) ON DELETE CASCADE,
  user_id              uuid        NOT NULL,
  pid                  integer     NOT NULL,
  name                 text        NOT NULL,
  mod_id               text,
  game_id              text,
  cpu_pct              numeric     NOT NULL,
  mem_mb               numeric     NOT NULL,
  net_in_kbps          numeric     NOT NULL DEFAULT 0,
  net_out_kbps         numeric     NOT NULL DEFAULT 0,
  started_at           timestamptz,
  parent_pid           integer,
  cmdline              text,
  risk                 text        NOT NULL DEFAULT 'low',
  persists_after_close boolean     NOT NULL DEFAULT false,
  abnormal_resources   boolean     NOT NULL DEFAULT false,
  sampled_at           timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.process_samples TO authenticated;
GRANT ALL ON public.process_samples TO service_role;
ALTER TABLE public.process_samples ENABLE ROW LEVEL SECURITY;
CREATE POLICY "process_samples owned by user" ON public.process_samples FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE INDEX process_samples_user_sampled ON public.process_samples (user_id, sampled_at DESC);
CREATE INDEX process_samples_snapshot ON public.process_samples (snapshot_id);

CREATE TABLE public.network_samples (
  id               uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_id      uuid        NOT NULL REFERENCES public.monitor_snapshots(id) ON DELETE CASCADE,
  user_id          uuid        NOT NULL,
  conn_id          text        NOT NULL,
  pid              integer     NOT NULL,
  process_name     text        NOT NULL,
  remote_host      text        NOT NULL,
  remote_ip        text        NOT NULL,
  remote_port      integer     NOT NULL,
  bytes_sent       bigint      NOT NULL DEFAULT 0,
  bytes_received   bigint      NOT NULL DEFAULT 0,
  request_count    integer     NOT NULL DEFAULT 0,
  first_seen       timestamptz NOT NULL,
  last_seen        timestamptz NOT NULL,
  unknown_domain   boolean     NOT NULL DEFAULT false,
  sampled_at       timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.network_samples TO authenticated;
GRANT ALL ON public.network_samples TO service_role;
ALTER TABLE public.network_samples ENABLE ROW LEVEL SECURITY;
CREATE POLICY "network_samples owned by user" ON public.network_samples FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE INDEX network_samples_user_sampled ON public.network_samples (user_id, sampled_at DESC);

CREATE TABLE public.consent_violations (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_id  uuid        NOT NULL REFERENCES public.monitor_snapshots(id) ON DELETE CASCADE,
  user_id      uuid        NOT NULL,
  mod_id       text        NOT NULL,
  mod_name     text        NOT NULL,
  capability   text        NOT NULL,
  declared     boolean     NOT NULL,
  observed     boolean     NOT NULL,
  detail       text,
  recorded_at  timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.consent_violations TO authenticated;
GRANT ALL ON public.consent_violations TO service_role;
ALTER TABLE public.consent_violations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "consent_violations owned by user" ON public.consent_violations FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.process_baselines (
  id           uuid    PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid    NOT NULL,
  process_name text    NOT NULL,
  sample_count integer NOT NULL DEFAULT 0,
  cpu_mean     numeric NOT NULL DEFAULT 0,
  cpu_stddev   numeric NOT NULL DEFAULT 0,
  mem_mean     numeric NOT NULL DEFAULT 0,
  mem_stddev   numeric NOT NULL DEFAULT 0,
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, process_name)
);
GRANT SELECT, INSERT, UPDATE ON public.process_baselines TO authenticated;
GRANT ALL ON public.process_baselines TO service_role;
ALTER TABLE public.process_baselines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "baselines owned by user" ON public.process_baselines FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.monitor_alerts (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid        NOT NULL,
  kind         text        NOT NULL,
  severity     text        NOT NULL,
  title        text        NOT NULL,
  message      text        NOT NULL,
  pid          integer,
  process_name text,
  remote_host  text,
  target_key   text        NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  resolved_at  timestamptz,
  UNIQUE (user_id, kind, target_key, created_at)
);
GRANT SELECT, INSERT, UPDATE ON public.monitor_alerts TO authenticated;
GRANT ALL ON public.monitor_alerts TO service_role;
ALTER TABLE public.monitor_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "alerts owned by user" ON public.monitor_alerts FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE INDEX monitor_alerts_user_open ON public.monitor_alerts (user_id, created_at DESC)
  WHERE resolved_at IS NULL;