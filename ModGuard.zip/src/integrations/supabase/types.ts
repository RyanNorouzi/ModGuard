export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      consent_violations: {
        Row: {
          capability: string
          declared: boolean
          detail: string | null
          id: string
          mod_id: string
          mod_name: string
          observed: boolean
          recorded_at: string
          snapshot_id: string
          user_id: string
        }
        Insert: {
          capability: string
          declared: boolean
          detail?: string | null
          id?: string
          mod_id: string
          mod_name: string
          observed: boolean
          recorded_at?: string
          snapshot_id: string
          user_id: string
        }
        Update: {
          capability?: string
          declared?: boolean
          detail?: string | null
          id?: string
          mod_id?: string
          mod_name?: string
          observed?: boolean
          recorded_at?: string
          snapshot_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "consent_violations_snapshot_id_fkey"
            columns: ["snapshot_id"]
            isOneToOne: false
            referencedRelation: "monitor_snapshots"
            referencedColumns: ["id"]
          },
        ]
      }
      known_mods: {
        Row: {
          author: string | null
          created_at: string
          first_seen: string
          game_id: string | null
          hit_count: number
          id: string
          last_seen: string
          name: string
          notes: string | null
          sha256: string
          source: string | null
          updated_at: string
          verdict: Database["public"]["Enums"]["verdict"]
        }
        Insert: {
          author?: string | null
          created_at?: string
          first_seen?: string
          game_id?: string | null
          hit_count?: number
          id?: string
          last_seen?: string
          name: string
          notes?: string | null
          sha256: string
          source?: string | null
          updated_at?: string
          verdict?: Database["public"]["Enums"]["verdict"]
        }
        Update: {
          author?: string | null
          created_at?: string
          first_seen?: string
          game_id?: string | null
          hit_count?: number
          id?: string
          last_seen?: string
          name?: string
          notes?: string | null
          sha256?: string
          source?: string | null
          updated_at?: string
          verdict?: Database["public"]["Enums"]["verdict"]
        }
        Relationships: []
      }
      mod_reputation: {
        Row: {
          cache_key: string
          fetched_at: string
          id: string
          payload: Json
        }
        Insert: {
          cache_key: string
          fetched_at?: string
          id?: string
          payload: Json
        }
        Update: {
          cache_key?: string
          fetched_at?: string
          id?: string
          payload?: Json
        }
        Relationships: []
      }
      monitor_agents: {
        Row: {
          created_at: string
          hostname: string | null
          id: string
          label: string
          last_seen_at: string | null
          os: string | null
          secret_hash: string
          user_id: string
        }
        Insert: {
          created_at?: string
          hostname?: string | null
          id?: string
          label: string
          last_seen_at?: string | null
          os?: string | null
          secret_hash: string
          user_id: string
        }
        Update: {
          created_at?: string
          hostname?: string | null
          id?: string
          label?: string
          last_seen_at?: string | null
          os?: string | null
          secret_hash?: string
          user_id?: string
        }
        Relationships: []
      }
      monitor_alerts: {
        Row: {
          created_at: string
          id: string
          kind: string
          message: string
          pid: number | null
          process_name: string | null
          remote_host: string | null
          resolved_at: string | null
          severity: string
          target_key: string
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          kind: string
          message: string
          pid?: number | null
          process_name?: string | null
          remote_host?: string | null
          resolved_at?: string | null
          severity: string
          target_key: string
          title: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          kind?: string
          message?: string
          pid?: number | null
          process_name?: string | null
          remote_host?: string | null
          resolved_at?: string | null
          severity?: string
          target_key?: string
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      monitor_snapshots: {
        Row: {
          agent_id: string
          created_at: string
          id: string
          taken_at: string
          user_id: string
        }
        Insert: {
          agent_id: string
          created_at?: string
          id?: string
          taken_at: string
          user_id: string
        }
        Update: {
          agent_id?: string
          created_at?: string
          id?: string
          taken_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "monitor_snapshots_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "monitor_agents"
            referencedColumns: ["id"]
          },
        ]
      }
      network_samples: {
        Row: {
          bytes_received: number
          bytes_sent: number
          conn_id: string
          first_seen: string
          id: string
          last_seen: string
          pid: number
          process_name: string
          remote_host: string
          remote_ip: string
          remote_port: number
          request_count: number
          sampled_at: string
          snapshot_id: string
          unknown_domain: boolean
          user_id: string
        }
        Insert: {
          bytes_received?: number
          bytes_sent?: number
          conn_id: string
          first_seen: string
          id?: string
          last_seen: string
          pid: number
          process_name: string
          remote_host: string
          remote_ip: string
          remote_port: number
          request_count?: number
          sampled_at?: string
          snapshot_id: string
          unknown_domain?: boolean
          user_id: string
        }
        Update: {
          bytes_received?: number
          bytes_sent?: number
          conn_id?: string
          first_seen?: string
          id?: string
          last_seen?: string
          pid?: number
          process_name?: string
          remote_host?: string
          remote_ip?: string
          remote_port?: number
          request_count?: number
          sampled_at?: string
          snapshot_id?: string
          unknown_domain?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "network_samples_snapshot_id_fkey"
            columns: ["snapshot_id"]
            isOneToOne: false
            referencedRelation: "monitor_snapshots"
            referencedColumns: ["id"]
          },
        ]
      }
      process_baselines: {
        Row: {
          cpu_mean: number
          cpu_stddev: number
          id: string
          mem_mean: number
          mem_stddev: number
          process_name: string
          sample_count: number
          updated_at: string
          user_id: string
        }
        Insert: {
          cpu_mean?: number
          cpu_stddev?: number
          id?: string
          mem_mean?: number
          mem_stddev?: number
          process_name: string
          sample_count?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          cpu_mean?: number
          cpu_stddev?: number
          id?: string
          mem_mean?: number
          mem_stddev?: number
          process_name?: string
          sample_count?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      process_samples: {
        Row: {
          abnormal_resources: boolean
          cmdline: string | null
          cpu_pct: number
          game_id: string | null
          id: string
          mem_mb: number
          mod_id: string | null
          name: string
          net_in_kbps: number
          net_out_kbps: number
          parent_pid: number | null
          persists_after_close: boolean
          pid: number
          risk: string
          sampled_at: string
          snapshot_id: string
          started_at: string | null
          user_id: string
        }
        Insert: {
          abnormal_resources?: boolean
          cmdline?: string | null
          cpu_pct: number
          game_id?: string | null
          id?: string
          mem_mb: number
          mod_id?: string | null
          name: string
          net_in_kbps?: number
          net_out_kbps?: number
          parent_pid?: number | null
          persists_after_close?: boolean
          pid: number
          risk?: string
          sampled_at?: string
          snapshot_id: string
          started_at?: string | null
          user_id: string
        }
        Update: {
          abnormal_resources?: boolean
          cmdline?: string | null
          cpu_pct?: number
          game_id?: string | null
          id?: string
          mem_mb?: number
          mod_id?: string | null
          name?: string
          net_in_kbps?: number
          net_out_kbps?: number
          parent_pid?: number | null
          persists_after_close?: boolean
          pid?: number
          risk?: string
          sampled_at?: string
          snapshot_id?: string
          started_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "process_samples_snapshot_id_fkey"
            columns: ["snapshot_id"]
            isOneToOne: false
            referencedRelation: "monitor_snapshots"
            referencedColumns: ["id"]
          },
        ]
      }
      scan_events: {
        Row: {
          created_at: string
          file_name: string
          game_id: string
          id: string
          severity_counts: Json
          sha256: string | null
          source: string
          verdict: Database["public"]["Enums"]["verdict"]
        }
        Insert: {
          created_at?: string
          file_name: string
          game_id: string
          id?: string
          severity_counts?: Json
          sha256?: string | null
          source: string
          verdict: Database["public"]["Enums"]["verdict"]
        }
        Update: {
          created_at?: string
          file_name?: string
          game_id?: string
          id?: string
          severity_counts?: Json
          sha256?: string | null
          source?: string
          verdict?: Database["public"]["Enums"]["verdict"]
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      verdict:
        | "safe"
        | "low_risk"
        | "suspicious"
        | "likely_malicious"
        | "confirmed_malicious"
        | "unknown"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      verdict: [
        "safe",
        "low_risk",
        "suspicious",
        "likely_malicious",
        "confirmed_malicious",
        "unknown",
      ],
    },
  },
} as const
