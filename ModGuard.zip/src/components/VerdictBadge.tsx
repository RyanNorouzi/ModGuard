import { Shield, ShieldAlert, ShieldCheck, ShieldX, HelpCircle, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

export type Verdict =
  | "safe"
  | "low_risk"
  | "suspicious"
  | "likely_malicious"
  | "confirmed_malicious"
  | "unknown";

const config: Record<Verdict, { label: string; icon: typeof Shield; cls: string }> = {
  safe: { label: "Safe", icon: ShieldCheck, cls: "bg-safe/15 text-safe border-safe/30" },
  low_risk: { label: "Low Risk", icon: Shield, cls: "bg-safe/10 text-safe border-safe/25" },
  suspicious: { label: "Suspicious", icon: AlertTriangle, cls: "bg-warn/15 text-warn border-warn/30" },
  likely_malicious: { label: "Likely Malicious", icon: ShieldAlert, cls: "bg-danger/15 text-danger border-danger/30" },
  confirmed_malicious: { label: "Confirmed Malicious", icon: ShieldX, cls: "bg-critical/20 text-critical border-critical/40" },
  unknown: { label: "Unknown", icon: HelpCircle, cls: "bg-muted text-muted-foreground border-border" },
};

export function VerdictBadge({ verdict, size = "md" }: { verdict: Verdict; size?: "sm" | "md" | "lg" }) {
  const c = config[verdict] ?? config.unknown;
  const Icon = c.icon;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium",
        c.cls,
        size === "sm" && "px-2 py-0.5 text-xs",
        size === "md" && "px-2.5 py-1 text-sm",
        size === "lg" && "px-3 py-1.5 text-base",
      )}
    >
      <Icon className={cn(size === "sm" ? "h-3 w-3" : size === "lg" ? "h-5 w-5" : "h-4 w-4")} />
      {c.label}
    </span>
  );
}
