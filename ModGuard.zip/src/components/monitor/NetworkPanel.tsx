import { Globe, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";
import type { MonitorConnection } from "@/lib/monitor-types";

function fmtBytes(n: number) {
  if (n > 1_000_000) return `${(n / 1_000_000).toFixed(1)} MB`;
  if (n > 1_000) return `${(n / 1_000).toFixed(1)} KB`;
  return `${n} B`;
}

export function NetworkPanel({ connections }: { connections: MonitorConnection[] }) {
  return (
    <div className="rounded-lg border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface))]">
      <div className="flex items-center justify-between border-b border-[hsl(var(--mon-border))] px-4 py-2.5">
        <div className="flex items-center gap-2">
          <Globe className="h-4 w-4 text-[hsl(var(--mon-muted))]" />
          <h3 className="font-mono text-xs uppercase tracking-widest text-[hsl(var(--mon-muted))]">Outbound Connections</h3>
        </div>
        <span className="font-mono text-xs text-[hsl(var(--mon-muted))]">{connections.length} active</span>
      </div>
      <div className="divide-y divide-[hsl(var(--mon-border))]">
        {connections.map((c) => (
          <div
            key={c.id}
            className={cn(
              "grid grid-cols-12 gap-3 px-4 py-3 text-sm transition-colors",
              "hover:bg-[hsl(var(--mon-accent))]/8 hover:text-[hsl(var(--mon-fg))]",
              "active:bg-[hsl(var(--mon-accent))]/12",
              c.unknownDomain && "bg-[hsl(var(--mon-bad))]/8",
            )}
          >
            <div className="col-span-5 min-w-0">
              <div className="flex items-center gap-2">
                <span className="truncate font-medium text-[hsl(var(--mon-fg))]">{c.remoteHost}</span>
                {c.unknownDomain && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-[hsl(var(--mon-bad))]/40 bg-[hsl(var(--mon-bad))]/15 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--mon-bad))]">
                    <ShieldAlert className="h-2.5 w-2.5" /> Unknown
                  </span>
                )}
              </div>
              <div className="font-mono text-[11px] text-[hsl(var(--mon-muted))]">
                {c.remoteIp}:{c.remotePort} • {c.processName} (PID {c.pid})
              </div>
            </div>
            <div className="col-span-2 text-right font-mono text-xs">
              <div className="text-[hsl(var(--mon-fg))]">{fmtBytes(c.bytesSent)}</div>
              <div className="text-[10px] uppercase text-[hsl(var(--mon-muted))]">sent</div>
            </div>
            <div className="col-span-2 text-right font-mono text-xs">
              <div className="text-[hsl(var(--mon-fg))]">{fmtBytes(c.bytesReceived)}</div>
              <div className="text-[10px] uppercase text-[hsl(var(--mon-muted))]">recv</div>
            </div>
            <div className="col-span-3 text-right font-mono text-xs">
              <div className="text-[hsl(var(--mon-fg))]">{c.requestCount} req</div>
              <div className="text-[10px] text-[hsl(var(--mon-muted))]">first seen {new Date(c.firstSeen).toLocaleTimeString()}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}