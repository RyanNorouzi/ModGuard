import { Activity, Cpu } from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import type { ResourceSample } from "@/lib/monitor-types";

export function ResourceGraph({ series }: { series: ResourceSample[] }) {
  const cur = series[series.length - 1];
  return (
    <div className="rounded-lg border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface))]">
      <div className="flex items-center justify-between border-b border-[hsl(var(--mon-border))] px-4 py-2.5">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-[hsl(var(--mon-muted))]" />
          <h3 className="font-mono text-xs uppercase tracking-widest text-[hsl(var(--mon-muted))]">CPU + GPU over time</h3>
        </div>
        {cur && (
          <div className="flex items-center gap-4 font-mono text-xs">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-[hsl(var(--mon-accent))]" /> CPU {cur.cpuPct}%
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-[hsl(var(--mon-accent-2))]" /> GPU {cur.gpuPct}%
            </span>
          </div>
        )}
      </div>
      <div className="h-56 px-2 py-3">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={series} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="g-cpu" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(var(--mon-accent))" stopOpacity={0.55} />
                <stop offset="100%" stopColor="hsl(var(--mon-accent))" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="g-gpu" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(var(--mon-accent-2))" stopOpacity={0.45} />
                <stop offset="100%" stopColor="hsl(var(--mon-accent-2))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="hsl(var(--mon-border))" strokeDasharray="2 4" vertical={false} />
            <XAxis dataKey="t" hide />
            <YAxis domain={[0, 100]} stroke="hsl(var(--mon-muted))" fontSize={10} width={28} tickFormatter={(v) => `${v}`} />
            <Tooltip
              contentStyle={{
                background: "hsl(var(--mon-surface-2))",
                border: "1px solid hsl(var(--mon-border))",
                borderRadius: 8,
                fontSize: 12,
              }}
              labelFormatter={(v) => new Date(v as string).toLocaleTimeString()}
              formatter={(v: number, n) => [`${v}%`, n === "cpuPct" ? "CPU" : "GPU"]}
            />
            <Area type="monotone" dataKey="cpuPct" stroke="hsl(var(--mon-accent))" strokeWidth={2} fill="url(#g-cpu)" />
            <Area type="monotone" dataKey="gpuPct" stroke="hsl(var(--mon-accent-2))" strokeWidth={2} fill="url(#g-gpu)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export const _Cpu = Cpu;