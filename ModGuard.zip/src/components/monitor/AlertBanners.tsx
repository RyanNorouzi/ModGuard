import { AlertTriangle, ShieldAlert, Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import type { MonitorAlert } from "@/lib/monitor-types";

const ICON = {
  persistence: ShieldAlert,
  unknown_domain: AlertTriangle,
  abnormal_resources: Activity,
};

const TONE = {
  info: "border-[hsl(var(--mon-accent))]/30 bg-[hsl(var(--mon-accent))]/10 text-[hsl(var(--mon-fg))]",
  warning: "border-[hsl(var(--mon-warn))]/40 bg-[hsl(var(--mon-warn))]/12 text-[hsl(var(--mon-warn))]",
  critical: "border-[hsl(var(--mon-crit))]/50 bg-[hsl(var(--mon-crit))]/15 text-[hsl(var(--mon-crit))]",
};

export function AlertBanners({ alerts }: { alerts: MonitorAlert[] }) {
  if (alerts.length === 0) return null;
  return (
    <div className="space-y-2">
      {alerts.map((a) => {
        const Icon = ICON[a.kind];
        return (
          <div key={a.id} className={cn("flex items-start gap-3 rounded-lg border px-4 py-3", TONE[a.severity])}>
            <Icon className="h-5 w-5 flex-none mt-0.5" />
            <div className="min-w-0">
              <div className="font-medium">{a.title}</div>
              <div className="text-sm opacity-90">{a.message}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}