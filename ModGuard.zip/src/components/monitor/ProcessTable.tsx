import { useMemo, useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { RiskPill } from "./RiskPill";
import type { MonitorProcess } from "@/lib/monitor-types";

type SortKey = "name" | "cpuPct" | "memMb" | "netOutKbps" | "startedAt" | "risk";

const RISK_RANK = { low: 0, medium: 1, high: 2, suspicious: 3 } as const;

function fmtUptime(iso: string) {
  const ms = Date.now() - new Date(iso).getTime();
  const m = Math.floor(ms / 60000);
  if (m < 1) return "<1m";
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}

export function ProcessTable({
  processes,
  selectedPid,
  onSelect,
}: {
  processes: MonitorProcess[];
  selectedPid: number | null;
  onSelect: (p: MonitorProcess) => void;
}) {
  const [sortKey, setSortKey] = useState<SortKey>("risk");
  const [dir, setDir] = useState<"asc" | "desc">("desc");

  const sorted = useMemo(() => {
    const copy = [...processes];
    copy.sort((a, b) => {
      let av: number | string; let bv: number | string;
      if (sortKey === "risk") { av = RISK_RANK[a.risk]; bv = RISK_RANK[b.risk]; }
      else if (sortKey === "name") { av = a.name; bv = b.name; }
      else if (sortKey === "startedAt") { av = a.startedAt; bv = b.startedAt; }
      else { av = a[sortKey] as number; bv = b[sortKey] as number; }
      if (av < bv) return dir === "asc" ? -1 : 1;
      if (av > bv) return dir === "asc" ? 1 : -1;
      return 0;
    });
    return copy;
  }, [processes, sortKey, dir]);

  const toggle = (k: SortKey) => {
    if (k === sortKey) setDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(k); setDir(k === "name" ? "asc" : "desc"); }
  };

  return (
    <div className="rounded-lg border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface))] overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-[hsl(var(--mon-surface-2))] text-xs uppercase tracking-wider text-[hsl(var(--mon-muted))]">
            <tr>
              <Th label="Process" k="name" sortKey={sortKey} dir={dir} onClick={toggle} />
              <Th label="PID" k="name" sortKey={sortKey} dir={dir} onClick={() => {}} noSort />
              <Th label="CPU" k="cpuPct" sortKey={sortKey} dir={dir} onClick={toggle} align="right" />
              <Th label="Memory" k="memMb" sortKey={sortKey} dir={dir} onClick={toggle} align="right" />
              <Th label="Net ↑" k="netOutKbps" sortKey={sortKey} dir={dir} onClick={toggle} align="right" />
              <Th label="Uptime" k="startedAt" sortKey={sortKey} dir={dir} onClick={toggle} align="right" />
              <Th label="Risk" k="risk" sortKey={sortKey} dir={dir} onClick={toggle} align="right" />
            </tr>
          </thead>
          <tbody>
            {sorted.map((p) => (
              <tr
                key={p.pid}
                onClick={() => onSelect(p)}
                className={cn(
                  "border-t border-[hsl(var(--mon-border))] cursor-pointer transition-colors",
                  "hover:bg-[hsl(var(--mon-accent))]/10 hover:text-[hsl(var(--mon-fg))]",
                  "active:bg-[hsl(var(--mon-accent))]/15",
                  selectedPid === p.pid && "bg-[hsl(var(--mon-accent))]/10",
                  p.persistsAfterClose && "bg-[hsl(var(--mon-crit))]/8",
                )}
              >
                <td className="px-3 py-2.5">
                  <div className="font-medium text-[hsl(var(--mon-fg))]">{p.name}</div>
                  {p.cmdline && (
                    <div className="font-mono text-[11px] text-[hsl(var(--mon-muted))] truncate max-w-[420px]">{p.cmdline}</div>
                  )}
                </td>
                <td className="px-3 py-2.5 font-mono text-xs text-[hsl(var(--mon-muted))]">{p.pid}</td>
                <td className={cn("px-3 py-2.5 text-right font-mono tabular-nums", p.cpuPct > 50 && "text-[hsl(var(--mon-warn))]", p.cpuPct > 80 && "text-[hsl(var(--mon-bad))]")}>{p.cpuPct.toFixed(1)}%</td>
                <td className="px-3 py-2.5 text-right font-mono tabular-nums">{p.memMb.toLocaleString()} MB</td>
                <td className={cn("px-3 py-2.5 text-right font-mono tabular-nums", p.netOutKbps > 80 && "text-[hsl(var(--mon-warn))]")}>{p.netOutKbps} KB/s</td>
                <td className="px-3 py-2.5 text-right font-mono text-xs text-[hsl(var(--mon-muted))]">{fmtUptime(p.startedAt)}</td>
                <td className="px-3 py-2.5 text-right"><RiskPill risk={p.risk} size="sm" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Th({
  label, k, sortKey, dir, onClick, align = "left", noSort = false,
}: {
  label: string; k: SortKey; sortKey: SortKey; dir: "asc" | "desc";
  onClick: (k: SortKey) => void; align?: "left" | "right"; noSort?: boolean;
}) {
  const active = !noSort && sortKey === k;
  return (
    <th className={cn("px-3 py-2 font-medium", align === "right" && "text-right")}>
      <button
        type="button"
        onClick={() => !noSort && onClick(k)}
        className={cn(
          "inline-flex items-center gap-1 rounded-sm px-1 py-0.5 -mx-1 transition-colors",
          align === "right" && "flex-row-reverse",
          !noSort && "hover:text-[hsl(var(--mon-fg))] hover:bg-[hsl(var(--mon-accent))]/10",
          "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[hsl(var(--mon-accent))]",
        )}
      >
        {label}
        {active && (dir === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />)}
      </button>
    </th>
  );
}