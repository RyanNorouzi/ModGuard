import { CheckCircle2, XCircle, Minus, FileCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ConsentDiff } from "@/lib/monitor-types";

export function ConsentCheck({ diffs }: { diffs: ConsentDiff[] }) {
  if (diffs.length === 0) {
    return (
      <div className="rounded-lg border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface))] px-4 py-6 text-center text-sm text-[hsl(var(--mon-muted))]">
        No installed mods are reporting consent drift.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {diffs.map((d) => (
        <div key={d.modId} className="rounded-lg border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface))]">
          <div className="flex items-center justify-between border-b border-[hsl(var(--mon-border))] px-4 py-2.5">
            <div className="flex items-center gap-2">
              <FileCheck className="h-4 w-4 text-[hsl(var(--mon-muted))]" />
              <span className="font-mono text-xs uppercase tracking-widest text-[hsl(var(--mon-muted))]">Consent check</span>
              <span className="text-sm font-medium text-[hsl(var(--mon-fg))]">{d.modName}</span>
            </div>
            <span className={cn(
              "rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider",
              d.mismatches.length > 0
                ? "border-[hsl(var(--mon-bad))]/40 bg-[hsl(var(--mon-bad))]/15 text-[hsl(var(--mon-bad))]"
                : "border-[hsl(var(--mon-ok))]/30 bg-[hsl(var(--mon-ok))]/15 text-[hsl(var(--mon-ok))]",
            )}>
              {d.mismatches.length} mismatch{d.mismatches.length === 1 ? "" : "es"}
            </span>
          </div>
          <div className="grid grid-cols-12 gap-2 border-b border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface-2))]/40 px-4 py-1.5 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--mon-muted))]">
            <div className="col-span-6">Capability</div>
            <div className="col-span-3 text-center">Claims</div>
            <div className="col-span-3 text-center">Observed</div>
          </div>
          <div className="divide-y divide-[hsl(var(--mon-border))]">
            {d.claims.map((c) => {
              const mismatch = c.declared !== c.observed;
              return (
                <div
                  key={c.capability}
                  className={cn(
                    "grid grid-cols-12 items-center gap-2 px-4 py-2 text-sm transition-colors",
                    "hover:bg-[hsl(var(--mon-accent))]/8 hover:text-[hsl(var(--mon-fg))]",
                    "active:bg-[hsl(var(--mon-accent))]/12",
                    mismatch && "bg-[hsl(var(--mon-bad))]/8",
                  )}
                >
                  <div className="col-span-6">
                    <div className={cn("font-mono text-xs", mismatch && "text-[hsl(var(--mon-bad))]")}>{c.capability}</div>
                    {c.detail && <div className="text-[11px] text-[hsl(var(--mon-muted))]">{c.detail}</div>}
                  </div>
                  <div className="col-span-3 flex justify-center">
                    <Yes value={c.declared} />
                  </div>
                  <div className="col-span-3 flex justify-center">
                    <Yes value={c.observed} dangerous={mismatch && c.observed} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

function Yes({ value, dangerous = false }: { value: boolean; dangerous?: boolean }) {
  if (!value) return <Minus className="h-4 w-4 text-[hsl(var(--mon-muted))]" />;
  return value && dangerous
    ? <XCircle className="h-4 w-4 text-[hsl(var(--mon-bad))]" />
    : <CheckCircle2 className="h-4 w-4 text-[hsl(var(--mon-ok))]" />;
}