import { ShieldCheck, ShieldAlert, ShieldX, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { riskColor } from "@/lib/monitor-adapter";
import type { RiskLabel } from "@/lib/monitor-types";

const ICON = {
  low: ShieldCheck,
  medium: AlertTriangle,
  high: ShieldAlert,
  suspicious: ShieldX,
} as const;

const LABEL: Record<RiskLabel, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  suspicious: "Suspicious",
};

export function RiskPill({ risk, size = "md" }: { risk: RiskLabel; size?: "sm" | "md" }) {
  const Icon = ICON[risk];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-mono uppercase tracking-wider",
        riskColor(risk),
        size === "sm" ? "px-2 py-0.5 text-[10px]" : "px-2.5 py-1 text-xs",
      )}
    >
      <Icon className={size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5"} />
      {LABEL[risk]}
    </span>
  );
}