import { Sparkles, X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useExplanation } from "@/lib/monitor-adapter";
import type { MonitorProcess } from "@/lib/monitor-types";
import { RiskPill } from "./RiskPill";

const ACTION_LABEL = {
  allow: "Allow",
  monitor: "Keep monitoring",
  kill: "Kill process",
  uninstall: "Uninstall parent mod",
} as const;

export function ExplanationSheet({
  process,
  onClose,
}: {
  process: MonitorProcess | null;
  onClose: () => void;
}) {
  const q = useExplanation(process);

  return (
    <Sheet open={!!process} onOpenChange={(v) => !v && onClose()}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-md bg-[hsl(var(--mon-bg))] border-l border-[hsl(var(--mon-border))] text-[hsl(var(--mon-fg))]"
      >
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2 text-[hsl(var(--mon-fg))]">
            <Sparkles className="h-4 w-4 text-[hsl(var(--mon-accent))]" />
            Claude explanation
          </SheetTitle>
        </SheetHeader>

        {!process ? null : (
          <div className="mt-4 space-y-4">
            <div>
              <div className="font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--mon-muted))]">Process</div>
              <div className="font-medium">{process.name}</div>
              <div className="font-mono text-xs text-[hsl(var(--mon-muted))]">PID {process.pid}</div>
            </div>

            <div>
              <div className="font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--mon-muted))]">Risk</div>
              <div className="mt-1"><RiskPill risk={process.risk} /></div>
            </div>

            <div className="rounded-lg border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface))] p-3">
              {q.isLoading && (
                <div className="flex items-center gap-2 text-sm text-[hsl(var(--mon-muted))]">
                  <Loader2 className="h-4 w-4 animate-spin" /> Asking Claude…
                </div>
              )}
              {q.isError && (
                <div className="text-sm text-[hsl(var(--mon-bad))]">Couldn't reach the explanation service.</div>
              )}
              {q.data && (
                <>
                  <p className="text-sm leading-relaxed">{q.data.summary}</p>
                  <ul className="mt-3 space-y-1.5 text-sm text-[hsl(var(--mon-muted))]">
                    {q.data.reasons.map((r, i) => (
                      <li key={i} className="flex gap-2">
                        <span className="mt-1.5 h-1 w-1 flex-none rounded-full bg-[hsl(var(--mon-accent))]" />
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                  {q.data.recommendedAction && (
                    <div className="mt-4 flex items-center justify-between rounded-md border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface-2))] px-3 py-2">
                      <span className="font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--mon-muted))]">Recommended</span>
                      <span className="text-sm font-medium">{ACTION_LABEL[q.data.recommendedAction]}</span>
                    </div>
                  )}
                </>
              )}
            </div>

            <Button variant="outline" onClick={onClose} className="w-full bg-transparent border-[hsl(var(--mon-border))] text-[hsl(var(--mon-fg))] hover:bg-[hsl(var(--mon-accent))]/10 hover:text-[hsl(var(--mon-fg))] focus-visible:ring-[hsl(var(--mon-accent))]">
              <X className="h-4 w-4" /> Close
            </Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}