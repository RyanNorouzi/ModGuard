// Extra static-analysis passes for the mod scanner:
//  1) Entropy analysis on string constants + class-name obfuscation
//  2) Native-in-JAR detection (PE/ELF binaries bundled inside a mod)
// Upstream hash comparison lives in upstream-hash.server.ts (async).

import type { Finding } from "./scan-static.server";

// ---------- Shannon entropy ----------
export function shannonEntropy(s: string): number {
  if (!s) return 0;
  const counts = new Map<string, number>();
  for (const ch of s) counts.set(ch, (counts.get(ch) ?? 0) + 1);
  const len = s.length;
  let h = 0;
  for (const c of counts.values()) {
    const p = c / len;
    h -= p * Math.log2(p);
  }
  return h;
}

// ---------- Pass 1: entropy ----------
const STRING_LITERAL_RE = /[\x20-\x7e]{24,}/g;

export function entropyPass(
  files: Record<string, Uint8Array>,
  classFiles: string[],
  findings: Finding[],
  hasNetworkIndicator: () => boolean,
) {
  // a) String-constant entropy
  let highEntropyHits = 0;
  let firstEvidence: string | undefined;
  let scanned = 0;
  for (const name of classFiles) {
    if (scanned > 400) break; // cap
    const bytes = files[name];
    if (!bytes || bytes.length === 0 || bytes.length > 2_000_000) continue;
    scanned++;
    // decode as latin1 to preserve byte values cheaply
    let text = "";
    for (let i = 0; i < bytes.length; i++) text += String.fromCharCode(bytes[i]);
    const matches = text.match(STRING_LITERAL_RE);
    if (!matches) continue;
    for (const m of matches) {
      if (m.length < 32) continue;
      const e = shannonEntropy(m);
      if (e > 4.8) {
        highEntropyHits++;
        firstEvidence ??= `${name} — "${m.slice(0, 60)}…" (entropy ${e.toFixed(2)})`;
        if (highEntropyHits >= 3) break;
      }
    }
    if (highEntropyHits >= 3) break;
  }
  if (highEntropyHits > 0) {
    const sev: Finding["severity"] = highEntropyHits >= 3 ? "high" : "medium";
    findings.push({
      severity: sev,
      category: "Obfuscation",
      detail: `High-entropy string constants detected (${highEntropyHits}+) — possible encoded/encrypted payload.`,
      evidence: firstEvidence,
    });
    if (hasNetworkIndicator()) {
      findings.push({
        severity: "high",
        category: "Obfuscation",
        detail: "Encoded payload combined with network indicators — likely hidden exfiltration channel.",
      });
    }
  }

  // b) Class-name namespace entropy
  if (classFiles.length >= 20) {
    const bases = classFiles.map((n) => n.split("/").pop()!.replace(/\.class$/, ""));
    const joined = bases.join("");
    const nameEntropy = shannonEntropy(joined);
    const longRandom = bases.filter((b) => b.length >= 6 && shannonEntropy(b) > 3.8).length;
    if (nameEntropy > 4.6 && longRandom / bases.length > 0.4) {
      findings.push({
        severity: "medium",
        category: "Obfuscation",
        detail: `Class names appear randomized (avg entropy ${nameEntropy.toFixed(2)}, ${Math.round((longRandom / bases.length) * 100)}% high-entropy) — ProGuard or custom obfuscator.`,
      });
    }
  }
}

// ---------- Pass 2: native binaries inside the JAR ----------
const NATIVE_EXT_RE = /\.(dll|so|dylib)$/i;

// Reuse the game-scanner's PE/ELF detection signatures
function isPE(b: Uint8Array): boolean {
  return b.length >= 2 && b[0] === 0x4d && b[1] === 0x5a;
}
function isELF(b: Uint8Array): boolean {
  return b.length >= 4 && b[0] === 0x7f && b[1] === 0x45 && b[2] === 0x4c && b[3] === 0x46;
}
function isMachO(b: Uint8Array): boolean {
  if (b.length < 4) return false;
  const m = (b[0] << 24) | (b[1] << 16) | (b[2] << 8) | b[3];
  return m === 0xfeedface || m === 0xfeedfacf || m === 0xcefaedfe || m === 0xcffaedfe;
}

// Lightweight printable-ASCII string extraction (min length 6).
function extractAscii(bytes: Uint8Array, limit = 4_000_000): string[] {
  const end = Math.min(bytes.length, limit);
  const out: string[] = [];
  let cur: number[] = [];
  for (let i = 0; i < end; i++) {
    const b = bytes[i];
    if (b >= 0x20 && b < 0x7f) {
      cur.push(b);
    } else {
      if (cur.length >= 6) out.push(String.fromCharCode.apply(null, cur));
      if (cur.length) cur = [];
    }
  }
  if (cur.length >= 6) out.push(String.fromCharCode.apply(null, cur));
  return out;
}

const NATIVE_STEALER_PATTERNS: Array<{ re: RegExp; detail: string; severity: Finding["severity"] }> = [
  { re: /\b(RedLine|LummaC2|Lumma|Raccoon|Vidar|Stealc|RisePro|MetaStealer)\b/i, severity: "critical", detail: "Native binary contains a known stealer family string." },
  { re: /\b(AsyncRAT|njRAT|QuasarRAT|NanoCore|Remcos|DCRat|XWorm|AgentTesla|FormBook)\b/i, severity: "critical", detail: "Native binary contains a known RAT family string." },
  { re: /\bxmrig\b|stratum\+(tcp|ssl):\/\//i, severity: "critical", detail: "Native binary contains XMRig / Stratum miner strings." },
  { re: /discord(app)?\.com\/api\/webhooks\//i, severity: "critical", detail: "Native binary contains a hardcoded Discord webhook." },
  { re: /api\.telegram\.org\/bot/i, severity: "critical", detail: "Native binary contains a hardcoded Telegram bot beacon." },
  { re: /\b(WriteProcessMemory|VirtualAllocEx|CreateRemoteThread|NtUnmapViewOfSection|SetWindowsHookEx)\b/, severity: "high", detail: "Native binary imports process-injection APIs." },
];

export function nativeInJarPass(
  files: Record<string, Uint8Array>,
  findings: Finding[],
) {
  const nativeNames = Object.keys(files).filter((n) => NATIVE_EXT_RE.test(n));
  if (nativeNames.length === 0) return;

  // Detect whether any class loads native code at all
  let loadsNative = false;
  const classNames = Object.keys(files).filter((n) => n.endsWith(".class"));
  for (const n of classNames) {
    const b = files[n];
    if (!b || b.length > 2_000_000) continue;
    let text = "";
    for (let i = 0; i < b.length; i++) text += String.fromCharCode(b[i]);
    if (/System\.(loadLibrary|load)\b/.test(text)) { loadsNative = true; break; }
  }

  for (const name of nativeNames) {
    const bytes = files[name];
    if (!bytes || bytes.length === 0) continue;
    const kind = isPE(bytes) ? "PE (.dll)" : isELF(bytes) ? "ELF (.so)" : isMachO(bytes) ? "Mach-O (.dylib)" : null;
    if (!kind) {
      findings.push({
        severity: "medium",
        category: "Native binary",
        detail: `Bundled native file ${name} has no recognizable PE/ELF/Mach-O header — possibly disguised.`,
      });
      continue;
    }

    findings.push({
      severity: "medium",
      category: "Native binary",
      detail: `Bundled native ${kind} inside JAR: ${name} (${Math.round(bytes.length / 1024)} KB).`,
    });

    if (bytes.length > 2_000_000) {
      findings.push({
        severity: "medium",
        category: "Native binary",
        detail: `Native binary ${name} is unusually large (${Math.round(bytes.length / 1024 / 1024)} MB) — review carefully.`,
      });
    }

    if (!loadsNative) {
      findings.push({
        severity: "high",
        category: "Native binary",
        detail: `Native binary ${name} is bundled but no Java class calls System.loadLibrary / System.load — payload may be dropped instead of loaded.`,
      });
    }

    // Scan strings inside the binary
    const strings = extractAscii(bytes);
    const seen = new Set<string>();
    for (const s of strings) {
      for (const p of NATIVE_STEALER_PATTERNS) {
        if (seen.has(p.detail)) continue;
        const m = s.match(p.re);
        if (m) {
          seen.add(p.detail);
          findings.push({
            severity: p.severity,
            category: "Native binary",
            detail: p.detail,
            evidence: `${name} — "${m[0].slice(0, 120)}"`,
          });
        }
      }
    }
  }
}
