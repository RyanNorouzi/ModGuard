import { unzipSync } from "fflate";

export type GameFinding = {
  severity: "low" | "medium" | "high" | "critical";
  category: string;
  detail: string;
  evidence?: string;
};

type Indicator = {
  re: RegExp;
  severity: GameFinding["severity"];
  category: string;
  detail: string;
};

// Tuned for cracked-game / installer malware (stealers, RATs, miners, loaders).
const INDICATORS: Indicator[] = [
  // ----- Known malware family names (string-tagged in the binary or its resources) -----
  { re: /\b(RedLine|RedlineStealer)\b/i, severity: "critical", category: "Known malware family", detail: "RedLine Stealer string detected." },
  { re: /\bLumma(C2|Stealer)?\b/i, severity: "critical", category: "Known malware family", detail: "Lumma Stealer string detected." },
  { re: /\b(Raccoon\s*Stealer|RaccoonStealer)\b/i, severity: "critical", category: "Known malware family", detail: "Raccoon Stealer string detected." },
  { re: /\bVidar(Stealer)?\b/i, severity: "critical", category: "Known malware family", detail: "Vidar Stealer string detected." },
  { re: /\b(MetaStealer|Stealc|RisePro|Atomic\s*Stealer|ClipBanker)\b/i, severity: "critical", category: "Known malware family", detail: "Known stealer family string detected." },
  { re: /\b(AsyncRAT|njRAT|QuasarRAT|NanoCore|Remcos|DCRat|XWorm|AgentTesla|FormBook|Emotet|TrickBot|SmokeLoader|PrivateLoader|Amadey)\b/i, severity: "critical", category: "Known malware family", detail: "Known RAT/loader family string detected." },

  // ----- Credential & wallet theft -----
  { re: /\\Login Data\b|\\Cookies\b|\\Web Data\b|\\Local State\b/i, severity: "high", category: "Credential theft", detail: "Reads browser credential / cookie / state files (stealer pattern)." },
  { re: /AppData\\(Roaming|Local)\\(Discord|discordcanary|discordptb)/i, severity: "critical", category: "Credential theft", detail: "Accesses Discord app data (token grab)." },
  { re: /\\key[34]\.db\b|\\logins\.json\b|\\signons\.sqlite\b/i, severity: "high", category: "Credential theft", detail: "Reads Firefox/Gecko credential stores." },
  { re: /\bwallet\.dat\b|\bMultiBit\b|\b(electrum|exodus|atomic|metamask)\b/i, severity: "high", category: "Credential theft", detail: "Targets crypto wallet files (Bitcoin/Ethereum/Exodus/MetaMask)." },
  { re: /\\\.ssh\\id_(rsa|ed25519|ecdsa)\b/i, severity: "high", category: "Credential theft", detail: "Reads SSH private keys." },
  { re: /\.kdbx\b|KeePass/i, severity: "medium", category: "Credential theft", detail: "References KeePass password database." },
  { re: /\\Telegram\s*Desktop\\tdata\b/i, severity: "high", category: "Credential theft", detail: "Reads Telegram Desktop session (account hijack)." },
  { re: /Steam\\config\\loginusers\.vdf|\\ssfn[0-9]+/i, severity: "high", category: "Credential theft", detail: "Reads Steam session files (account hijack)." },

  // ----- Network exfiltration -----
  { re: /discord(app)?\.com\/api\/webhooks\//i, severity: "critical", category: "Network exfiltration", detail: "Hardcoded Discord webhook — standard stealer beacon." },
  { re: /api\.telegram\.org\/bot[\w:-]+/i, severity: "critical", category: "Network exfiltration", detail: "Hardcoded Telegram bot endpoint — stealer beacon." },
  { re: /pastebin\.com\/raw\/|hastebin\.com\/raw\//i, severity: "high", category: "Network exfiltration", detail: "Pulls payload/config from Pastebin-style raw URL." },
  { re: /\b(anonfiles|gofile\.io|bashupload|transfer\.sh|filebin\.net|tmpfiles\.org|cdn\.discordapp\.com\/attachments)\b/i, severity: "high", category: "Network exfiltration", detail: "References anonymous file host (common payload drop)." },
  { re: /\.onion\b/i, severity: "high", category: "Network exfiltration", detail: "References a Tor .onion address." },
  { re: /\b(?:\d{1,3}\.){3}\d{1,3}\b(?::\d{2,5})?/, severity: "medium", category: "Network", detail: "Hardcoded IP address (possibly C2)." },
  { re: /\b(ngrok\.io|webhook\.site|duckdns\.org|no-ip\.org|portmap\.io)\b/i, severity: "high", category: "Network exfiltration", detail: "Dynamic DNS / tunnel host (common C2)." },

  // ----- Crypto miner -----
  { re: /\bxmrig\b|--donate-level\b/i, severity: "critical", category: "Crypto miner", detail: "XMRig miner binary or flags found." },
  { re: /stratum\+(tcp|ssl):\/\//i, severity: "critical", category: "Crypto miner", detail: "Stratum mining pool URL." },
  { re: /\b(supportxmr|minexmr|nanopool|ethermine|hashvault|moneroocean)\b/i, severity: "critical", category: "Crypto miner", detail: "Known mining pool reference." },

  // ----- LOLbin abuse / loaders -----
  { re: /powershell(\.exe)?\s+(-\w+\s+)*-(e|en|enc|encoded(command)?)\b/i, severity: "high", category: "Loader / LOLbin", detail: "PowerShell -EncodedCommand — base64-hidden payload." },
  { re: /certutil(\.exe)?\s+(-\w+\s+)*-decode\b/i, severity: "high", category: "Loader / LOLbin", detail: "certutil -decode (downloader/decoder trick)." },
  { re: /mshta(\.exe)?\s+(https?:|vbscript:|javascript:)/i, severity: "high", category: "Loader / LOLbin", detail: "mshta remote / scripting payload." },
  { re: /rundll32(\.exe)?\s+javascript:/i, severity: "critical", category: "Loader / LOLbin", detail: "rundll32 javascript: payload." },
  { re: /regsvr32(\.exe)?\s+(\/s\s+)?(\/n\s+\/u\s+)?\/i:https?:/i, severity: "critical", category: "Loader / LOLbin", detail: "regsvr32 squiblydoo remote scriptlet." },
  { re: /bitsadmin(\.exe)?\s+\/transfer\b/i, severity: "high", category: "Loader / LOLbin", detail: "bitsadmin /transfer used as downloader." },
  { re: /Invoke-(WebRequest|Expression|RestMethod)\b|IEX\s*\(/i, severity: "high", category: "Loader / LOLbin", detail: "PowerShell download-and-execute pattern." },
  { re: /\[System\.Reflection\.Assembly\]::Load\b/i, severity: "high", category: "Loader / LOLbin", detail: "Reflective .NET assembly load (fileless execution)." },

  // ----- Defender / AV evasion -----
  { re: /Set-MpPreference\s+-Disable\w+|Add-MpPreference\s+-ExclusionPath/i, severity: "critical", category: "AV evasion", detail: "Disables Microsoft Defender or adds an exclusion." },
  { re: /sc(\.exe)?\s+(stop|config)\s+(WinDefend|Sense|SecurityHealthService|wuauserv)\b/i, severity: "critical", category: "AV evasion", detail: "Stops/disables Defender or Windows Update service." },
  { re: /\bnetsh\s+advfirewall\s+set\b/i, severity: "high", category: "AV evasion", detail: "Modifies Windows Firewall." },

  // ----- Persistence -----
  { re: /\\Startup\\[^\s"']+\.(exe|bat|cmd|vbs|js|lnk|scr)/i, severity: "critical", category: "Persistence", detail: "Drops a file into the Windows Startup folder." },
  { re: /reg(\.exe)?\s+add\s+["']?HK(CU|LM)\\Software\\Microsoft\\Windows\\CurrentVersion\\Run/i, severity: "critical", category: "Persistence", detail: "Adds a Run-key registry entry." },
  { re: /schtasks(\.exe)?\s+\/create\b/i, severity: "high", category: "Persistence", detail: "Creates a scheduled task." },
  { re: /\bvssadmin(\.exe)?\s+delete\s+shadows\b/i, severity: "critical", category: "Destructive", detail: "Deletes Volume Shadow Copies (ransomware precursor)." },
  { re: /\bbcdedit(\.exe)?\s+\/set\b/i, severity: "high", category: "Destructive", detail: "Modifies boot configuration (recovery sabotage)." },
  { re: /\bwbadmin(\.exe)?\s+delete\b/i, severity: "high", category: "Destructive", detail: "Deletes Windows backups." },
  { re: /\bcipher(\.exe)?\s+\/w:/i, severity: "medium", category: "Destructive", detail: "Wipes free disk space (anti-forensics)." },

  // ----- UAC bypass -----
  { re: /\b(fodhelper|computerdefaults|sdclt|eventvwr)\.exe\b/i, severity: "high", category: "Privilege escalation", detail: "Known UAC-bypass binary referenced." },

  // ----- Self-deletion / sandbox check -----
  { re: /timeout\s+\/t\s+\d+\s*&\s*del\b|ping\s+127\.0\.0\.1.+&\s*del\b/i, severity: "medium", category: "Self-delete", detail: "Self-deleting script pattern." },
  { re: /\b(VBoxService|VBoxTray|vmware-vmx|vboxguest|qemu-ga|Sandboxie)\b/i, severity: "medium", category: "Sandbox evasion", detail: "Checks for VM / sandbox environment." },

  // ----- Packers / crypters -----
  { re: /UPX[0-9]|\bUPX!/i, severity: "low", category: "Packed binary", detail: "Packed with UPX — common but obscures content." },
  { re: /\bThemida\b|\bVMProtect\b|\bEnigma Protector\b/i, severity: "medium", category: "Packed binary", detail: "Commercial protector (Themida/VMProtect/Enigma) — often used to hide malware." },

  // ----- Pirate-scene tags (informational, raises overall risk) -----
  { re: /\b(CODEX|PLAZA|EMPRESS|SKIDROW|RELOADED|FLT|HOODLUM|FitGirl|DODI|RUNE|TENOKE|RAZOR1911|0xdeadc0de)\b/, severity: "medium", category: "Pirate-scene", detail: "Cracked-release group tag — installer is from a piracy source; treat with extreme caution." },
];

export type GameStaticReport = {
  fileType: string;
  size: number;
  findings: GameFinding[];
  score: number;
  rationale: string[];
  stats: {
    stringsScanned: number;
    archiveEntries?: number;
    nestedExecutables?: number;
    encryptedArchive?: boolean;
  };
};

const SEV_WEIGHT: Record<GameFinding["severity"], number> = { low: 2, medium: 6, high: 14, critical: 28 };

function detectFileType(b: Uint8Array): string {
  if (b.length >= 2 && b[0] === 0x4d && b[1] === 0x5a) return "PE executable (.exe/.dll)";
  if (b.length >= 4 && b[0] === 0x50 && b[1] === 0x4b && (b[2] === 0x03 || b[2] === 0x05 || b[2] === 0x07)) return "ZIP archive (.zip/.jar/.apk)";
  if (b.length >= 4 && b[0] === 0x52 && b[1] === 0x61 && b[2] === 0x72 && b[3] === 0x21) return "RAR archive";
  if (b.length >= 6 && b[0] === 0x37 && b[1] === 0x7a && b[2] === 0xbc && b[3] === 0xaf && b[4] === 0x27 && b[5] === 0x1c) return "7-Zip archive";
  if (b.length >= 4 && b[0] === 0x4d && b[1] === 0x53 && b[2] === 0x43 && b[3] === 0x46) return "Microsoft Cabinet (.cab)";
  if (b.length >= 8 && b[0] === 0xd0 && b[1] === 0xcf && b[2] === 0x11 && b[3] === 0xe0) return "OLE container (.msi/.doc)";
  if (b.length >= 0x8006 && b[0x8001] === 0x43 && b[0x8002] === 0x44 && b[0x8003] === 0x30 && b[0x8004] === 0x30 && b[0x8005] === 0x31) return "ISO 9660 disc image";
  if (b.length >= 6 && b[0] === 0x4e && b[1] === 0x75 && b[2] === 0x6c && b[3] === 0x73 && b[4] === 0x6f && b[5] === 0x66) return "NSIS installer";
  return "Unknown binary";
}

// Extract printable ASCII + UTF-16LE strings (min length 6) from a binary blob.
function extractStrings(bytes: Uint8Array, limit = 60_000_000): string[] {
  const end = Math.min(bytes.length, limit);
  const out: string[] = [];
  // ASCII pass
  let cur: number[] = [];
  for (let i = 0; i < end; i++) {
    const b = bytes[i];
    if (b >= 0x20 && b < 0x7f) {
      cur.push(b);
    } else {
      if (cur.length >= 6) out.push(String.fromCharCode.apply(null, cur));
      if (cur.length) cur = [];
    }
  }
  if (cur.length >= 6) out.push(String.fromCharCode.apply(null, cur));
  // UTF-16LE pass
  cur = [];
  for (let i = 0; i + 1 < end; i += 2) {
    const a = bytes[i], n = bytes[i + 1];
    if (n === 0 && a >= 0x20 && a < 0x7f) {
      cur.push(a);
    } else {
      if (cur.length >= 6) out.push(String.fromCharCode.apply(null, cur));
      if (cur.length) cur = [];
    }
  }
  if (cur.length >= 6) out.push(String.fromCharCode.apply(null, cur));
  return out;
}

function scanStrings(strings: string[], findings: GameFinding[], evidencePrefix = "") {
  const seen = new Set<string>();
  for (const s of strings) {
    for (const ind of INDICATORS) {
      const key = ind.category + ":" + ind.detail;
      if (seen.has(key)) continue;
      const m = s.match(ind.re);
      if (m) {
        seen.add(key);
        findings.push({
          severity: ind.severity,
          category: ind.category,
          detail: ind.detail,
          evidence: (evidencePrefix ? evidencePrefix + " — " : "") + '"' + m[0].slice(0, 120) + '"',
        });
      }
    }
  }
}

const NESTED_EXEC_RE = /\.(exe|dll|scr|bat|cmd|vbs|js|jse|wsf|ps1|psm1|lnk|hta|msi|jar|com|pif|reg)$/i;

function buildRationale(findings: GameFinding[], score: number, fileType: string): string[] {
  const lines: string[] = [];
  const cats = new Set(findings.map((f) => f.category));
  if (cats.has("Known malware family")) lines.push("Binary contains the name of a known malware family (stealer, RAT, or loader) — extremely high confidence of malware.");
  if (cats.has("Credential theft")) lines.push("Targets browser logins, Discord/Telegram sessions, Steam tokens, SSH keys, or crypto wallets.");
  if (cats.has("Network exfiltration")) lines.push("Sends data to an attacker-controlled endpoint (Discord webhook, Telegram bot, anonymous file host, or Tor).");
  if (cats.has("Crypto miner")) lines.push("Embeds a cryptocurrency miner that will silently use your GPU/CPU.");
  if (cats.has("Loader / LOLbin")) lines.push("Uses obfuscated Windows tools (PowerShell -enc, mshta, regsvr32, certutil) to fetch and run hidden payloads.");
  if (cats.has("AV evasion")) lines.push("Tries to disable Microsoft Defender or add itself to the exclusion list before running its payload.");
  if (cats.has("Persistence")) lines.push("Installs itself to survive reboot (Startup folder, Run key, or scheduled task).");
  if (cats.has("Destructive")) lines.push("Calls vssadmin/bcdedit/wbadmin — deletes shadow copies or backups (ransomware-style sabotage).");
  if (cats.has("Privilege escalation")) lines.push("Uses a known Windows UAC-bypass technique to gain admin rights silently.");
  if (cats.has("Pirate-scene")) lines.push("File is tagged by a piracy release group. Cracked installers very frequently bundle stealers or miners alongside the game.");
  if (cats.has("Packed binary")) lines.push("Binary is packed/protected (UPX, Themida, VMProtect) — obscures the payload from scanners.");
  if (cats.has("Sandbox evasion")) lines.push("Checks if it's running in a VM or sandbox (to avoid analysis).");
  if (cats.has("Nested executable")) lines.push("Archive hides .exe / .dll / .bat files inside — classic way to smuggle a payload past 'just a zip' first impressions.");
  if (cats.has("Encrypted archive")) lines.push("Archive is password-protected. Cracked-game packagers do this specifically to bypass antivirus scanning. Treat as malicious until proven otherwise.");
  if (findings.length === 0) {
    lines.push("No malicious patterns matched. Heuristic scanning of compiled binaries is limited — a clean result does NOT mean the file is safe, especially for cracked games.");
  } else {
    lines.push("Risk score: " + score + "/100 across " + findings.length + " finding" + (findings.length === 1 ? "" : "s") + ".");
  }
  if (fileType.startsWith("PE") || fileType.includes("installer") || fileType.includes("ISO")) {
    lines.push("Heads-up: cracked games and 'free download' installers are the #1 source of stealer/miner infections on Windows. The only safe option is the official storefront.");
  }
  return lines;
}

export function staticScanGame(bytes: Uint8Array, fileName: string): GameStaticReport {
  const fileType = detectFileType(bytes);
  const findings: GameFinding[] = [];
  let archiveEntries: number | undefined;
  let nestedExecutables: number | undefined;
  let encryptedArchive: boolean | undefined;

  // Archive (ZIP family) — walk entries first
  if (fileType.startsWith("ZIP")) {
    try {
      const files = unzipSync(bytes);
      const names = Object.keys(files);
      archiveEntries = names.length;
      const exec = names.filter((n) => NESTED_EXEC_RE.test(n));
      nestedExecutables = exec.length;
      if (exec.length > 0) {
        findings.push({
          severity: "high",
          category: "Nested executable",
          detail: "Archive contains " + exec.length + " executable file(s) inside.",
          evidence: exec.slice(0, 5).join(", "),
        });
      }
      if (names.some((n) => /(^|\/)autorun\.inf$/i.test(n))) {
        findings.push({ severity: "high", category: "Persistence", detail: "Contains autorun.inf (autostart on removable media)." });
      }
      // Scan small text-ish entries
      for (const n of names) {
        const f = files[n];
        if (!f || f.length === 0 || f.length > 4_000_000) continue;
        if (/\.(txt|nfo|bat|cmd|ps1|vbs|js|inf|ini|xml|json|cfg|conf|reg|html?)$/i.test(n)) {
          const txt = new TextDecoder("utf-8", { fatal: false }).decode(f);
          scanStrings([txt], findings, n);
        }
      }
    } catch (err) {
      // fflate throws on encrypted/password-protected entries
      const msg = err instanceof Error ? err.message : String(err);
      if (/encrypt|password/i.test(msg)) {
        encryptedArchive = true;
        findings.push({
          severity: "high",
          category: "Encrypted archive",
          detail: "Archive is password-protected — cracked-game packagers do this to hide payloads from antivirus.",
        });
      } else {
        findings.push({ severity: "medium", category: "Format", detail: "Could not parse archive: " + msg.slice(0, 80) });
      }
    }
  }
  if (fileType.startsWith("RAR") || fileType.startsWith("7-Zip")) {
    findings.push({
      severity: "low",
      category: "Format",
      detail: fileType + " can't be fully unpacked in-browser — we scan the raw bytes for strings, but nested executables aren't enumerated. Cracked-game RAR/7z bundles are very often password-protected for AV evasion.",
    });
  }

  // String scan over the raw bytes
  const strings = extractStrings(bytes);
  scanStrings(strings, findings);

  let score = 0;
  for (const f of findings) score += SEV_WEIGHT[f.severity];
  score = Math.min(100, score);

  // Pirate-scene + any high finding → escalate
  if (findings.some((f) => f.category === "Pirate-scene") && findings.some((f) => f.severity === "high" || f.severity === "critical")) {
    score = Math.min(100, score + 10);
  }

  return {
    fileType,
    size: bytes.length,
    findings,
    score,
    rationale: buildRationale(findings, score, fileType),
    stats: {
      stringsScanned: strings.length,
      archiveEntries,
      nestedExecutables,
      encryptedArchive,
    },
  };
}

export function gameCodeVerdictFromScore(score: number): "safe" | "low_risk" | "suspicious" | "likely_malicious" | "confirmed_malicious" {
  if (score >= 60) return "confirmed_malicious";
  if (score >= 35) return "likely_malicious";
  if (score >= 18) return "suspicious";
  if (score >= 6) return "low_risk";
  return "safe";
}
