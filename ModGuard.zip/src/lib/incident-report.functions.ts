import { createServerFn } from "@tanstack/react-start";

type EventInput = {
  t: number;
  kind: string;
  severity: string;
  title: string;
  detail: string;
};

type ReportInput = {
  fileName: string;
  fileSize: number;
  verdict: string;
  events: EventInput[];
};

export const generateIncidentReport = createServerFn({ method: "POST" })
  .inputValidator((input: ReportInput) => {
    if (!input || typeof input.fileName !== "string" || !Array.isArray(input.events)) {
      throw new Error("Invalid report input");
    }
    return input;
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) throw new Error("Missing ANTHROPIC_API_KEY");

    const timeline = data.events
      .map(
        (e) =>
          `- +${(e.t / 1000).toFixed(2)}s [${e.severity.toUpperCase()}] (${e.kind}) ${e.title} — ${e.detail}`,
      )
      .join("\n");

    const prompt = `You are a security analyst writing an incident report for a hackathon judging panel.

Sample analyzed in ModGuard Sandbox:
- File: ${data.fileName}
- Size: ${(data.fileSize / 1024).toFixed(1)} KB
- Automated verdict: ${data.verdict}

Observed behavior timeline:
${timeline}

Respond with a single JSON object (no markdown fences, no prose outside the JSON) with this exact shape:
{
  "purpose": "One to two plain-English sentences describing what this mod appears designed to do — its real intended function or pretext. Be concrete about the in-game / user-visible effect (e.g. 'Auto-types /pay ryrythebro 9999 in chat the moment you join a Minecraft server, transferring your in-game currency without asking.'). If the timeline shows chat-command injection, sendChat, or sendCommand calls, name the exact command and recipient when visible.",
  "suspiciousBackends": [
    { "host": "example.com", "why": "short reason this backend is not needed for the mod's stated purpose" }
  ],
  "report": "Full Markdown incident report (string) with sections: # Incident Summary, ## Verdict, ## Timeline of Behavior, ## Indicators of Compromise, ## Risk Assessment, ## Recommended Actions, ## Purpose of the Mod. Under 500 words. Do not invent indicators that aren't in the timeline."
}

suspiciousBackends must only include hosts/endpoints that appear in the timeline AND are not justifiable for the mod's apparent purpose. Empty array if none.`;

    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-5-sonnet-latest",
        max_tokens: 1500,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!resp.ok) {
      const text = await resp.text();
      throw new Error(`Anthropic API error ${resp.status}: ${text.slice(0, 300)}`);
    }

    const json = (await resp.json()) as {
      content?: Array<{ type: string; text?: string }>;
    };
    const raw =
      json.content
        ?.filter((b) => b.type === "text")
        .map((b) => b.text ?? "")
        .join("\n")
        .trim() ?? "";

    let report = raw;
    let purpose = "";
    let suspiciousBackends: Array<{ host: string; why: string }> = [];
    try {
      const jsonStr = raw.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/i, "").trim();
      const start = jsonStr.indexOf("{");
      const end = jsonStr.lastIndexOf("}");
      const sliced = start >= 0 && end > start ? jsonStr.slice(start, end + 1) : jsonStr;
      const parsed = JSON.parse(sliced) as {
        purpose?: string;
        suspiciousBackends?: Array<{ host?: string; why?: string }>;
        report?: string;
      };
      if (parsed.report) report = parsed.report;
      if (typeof parsed.purpose === "string") purpose = parsed.purpose;
      if (Array.isArray(parsed.suspiciousBackends)) {
        suspiciousBackends = parsed.suspiciousBackends
          .filter((b) => b && typeof b.host === "string")
          .map((b) => ({ host: b.host as string, why: String(b.why ?? "") }));
      }
    } catch {
      // fall back to raw markdown
    }

    return { report, purpose, suspiciousBackends, generatedAt: new Date().toISOString() };
  });