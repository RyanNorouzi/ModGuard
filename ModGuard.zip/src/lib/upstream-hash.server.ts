// Upstream hash comparison against Modrinth.
// Best-effort: any network failure returns null and never blocks the scan.

export type UpstreamResult =
  | { status: "verified"; project: string; version: string; url: string }
  | { status: "mismatch"; project: string; version: string; expectedSha512?: string; url: string }
  | { status: "version_not_found"; project: string; declaredVersion: string; url: string }
  | { status: "no_match" }
  | { status: "skipped"; reason: string };

async function sha512Hex(bytes: Uint8Array): Promise<string> {
  const ab = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(ab).set(bytes);
  const buf = await crypto.subtle.digest("SHA-512", ab);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

type ModrinthVersion = {
  id: string;
  version_number: string;
  files: Array<{ hashes: { sha1?: string; sha512?: string }; url: string; primary?: boolean }>;
};

export async function checkUpstreamHash(
  bytes: Uint8Array,
  modId: string | undefined,
  declaredVersion: string | undefined,
): Promise<UpstreamResult> {
  if (!modId) return { status: "skipped", reason: "No modId in manifest." };
  const slug = modId.toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
  if (!slug) return { status: "skipped", reason: "Empty slug." };

  try {
    const res = await fetch(`https://api.modrinth.com/v2/project/${encodeURIComponent(slug)}/version`, {
      headers: { "User-Agent": "ModGuard/1.0 (lovable.app)" },
    });
    if (res.status === 404) return { status: "no_match" };
    if (!res.ok) return { status: "skipped", reason: `Modrinth HTTP ${res.status}` };
    const versions = (await res.json()) as ModrinthVersion[];
    if (!Array.isArray(versions) || versions.length === 0) return { status: "no_match" };

    const localSha512 = await sha512Hex(bytes);

    // Any version file matches → verified
    for (const v of versions) {
      for (const f of v.files) {
        if (f.hashes?.sha512?.toLowerCase() === localSha512) {
          return {
            status: "verified",
            project: slug,
            version: v.version_number,
            url: `https://modrinth.com/mod/${slug}/version/${encodeURIComponent(v.version_number)}`,
          };
        }
      }
    }

    // Declared version exists on Modrinth but our hash differs → mismatch
    if (declaredVersion) {
      const match = versions.find((v) => v.version_number === declaredVersion);
      if (match) {
        const primary = match.files.find((f) => f.primary) ?? match.files[0];
        return {
          status: "mismatch",
          project: slug,
          version: declaredVersion,
          expectedSha512: primary?.hashes?.sha512,
          url: `https://modrinth.com/mod/${slug}/version/${encodeURIComponent(declaredVersion)}`,
        };
      }
      return {
        status: "version_not_found",
        project: slug,
        declaredVersion,
        url: `https://modrinth.com/mod/${slug}`,
      };
    }

    return { status: "no_match" };
  } catch (e) {
    return { status: "skipped", reason: e instanceof Error ? e.message : "fetch failed" };
  }
}
