import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const ScanInput = z.object({
  fileName: z.string().min(1).max(256),
  fileBase64: z.string().min(8).max(120_000_000),
});

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const ab = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(ab).set(bytes);
  const buf = await crypto.subtle.digest("SHA-256", ab);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export const scanGameFile = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ScanInput.parse(input))
  .handler(async ({ data }) => {
    const { staticScanGame, gameCodeVerdictFromScore } = await import("./scan-game-static.server");
    const bytes = base64ToBytes(data.fileBase64);
    if (bytes.length > 80_000_000) {
      throw new Error("File too large (max 80MB). For full game installers, scan just the setup .exe or upload the inner installer archive.");
    }
    const sha256 = await sha256Hex(bytes);
    const report = staticScanGame(bytes, data.fileName);
    const verdict = gameCodeVerdictFromScore(report.score);
    return {
      sha256,
      fileName: data.fileName,
      fileType: report.fileType,
      size: report.size,
      verdict,
      findings: report.findings,
      rationale: report.rationale,
      stats: report.stats,
      score: report.score,
    };
  });
