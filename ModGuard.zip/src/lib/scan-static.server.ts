import { unzipSync, strFromU8 } from "fflate";
import { entropyPass, nativeInJarPass } from "./scan-extras.server";

export type Finding = {
  severity: "low" | "medium" | "high" | "critical";
  category: string;
  detail: string;
  evidence?: string;
};

type Indicator = {
  re: RegExp;
  severity: Finding["severity"];
  category: string;
  detail: string;
};

const INDICATORS: Indicator[] = [
  // Credential / token theft
  { re: /launcher_profiles\.json/i, severity: "critical", category: "Credential theft", detail: "Reads Minecraft launcher profile (Microsoft auth tokens)." },
  { re: /usercache\.json/i, severity: "high", category: "Credential theft", detail: "Reads Minecraft usercache." },
  { re: /\.minecraft[\\/]/i, severity: "medium", category: "Filesystem", detail: "Touches .minecraft directory." },
  { re: /discord[\\/]Local Storage/i, severity: "critical", category: "Credential theft", detail: "Reads Discord local storage (token theft pattern)." },
  { re: /AppData[\\/](Roaming|Local)[\\/]discord/i, severity: "critical", category: "Credential theft", detail: "Accesses Discord app data." },
  { re: /Cookies[- ]journal|Login Data|Web Data/i, severity: "high", category: "Credential theft", detail: "Reads browser credential/cookie databases." },
  { re: /chrome[\\/]User Data/i, severity: "high", category: "Credential theft", detail: "Accesses Chrome user data." },
  { re: /firefox[\\/]Profiles/i, severity: "high", category: "Credential theft", detail: "Accesses Firefox profiles." },

  // Network exfiltration
  { re: /discord(app)?\.com\/api\/webhooks\//i, severity: "critical", category: "Network exfiltration", detail: "Hardcoded Discord webhook URL — common stealer beacon." },
  { re: /pastebin\.com\/raw\//i, severity: "high", category: "Network exfiltration", detail: "Pulls payload from Pastebin raw URL." },
  { re: /(anonfiles|gofile|bashupload|transfer\.sh)/i, severity: "high", category: "Network exfiltration", detail: "References anonymous file host." },
  { re: /\b(?:\d{1,3}\.){3}\d{1,3}\b/, severity: "medium", category: "Network", detail: "Hardcoded IP address literal." },

  // Remote code execution
  { re: /Runtime\.getRuntime\s*\(\s*\)\s*\.\s*exec/i, severity: "high", category: "Code execution", detail: "Calls Runtime.exec — can launch OS commands." },
  { re: /ProcessBuilder/i, severity: "high", category: "Code execution", detail: "Uses ProcessBuilder — can launch subprocesses." },
  { re: /URLClassLoader/i, severity: "high", category: "Code execution", detail: "Loads classes from URLs (remote code loading)." },
  { re: /defineClass\s*\(/i, severity: "medium", category: "Code execution", detail: "Defines classes from raw bytes (often used to hide payload)." },
  { re: /sun\.misc\.Unsafe/i, severity: "medium", category: "Code execution", detail: "Uses sun.misc.Unsafe." },
  { re: /MethodHandles\.privateLookupIn/i, severity: "low", category: "Code execution", detail: "Uses private reflection lookup." },

  // Reflection abuse
  { re: /setAccessible\s*\(\s*true\s*\)/i, severity: "medium", category: "Reflection abuse", detail: "Calls setAccessible(true) — bypasses Java access controls to touch private fields/methods." },
  { re: /Method\s*\.\s*invoke\s*\(/i, severity: "low", category: "Reflection abuse", detail: "Invokes methods reflectively (Method.invoke) — common payload-hiding pattern." },

  // ClassLoader hijacking / Java agents
  { re: /Instrumentation\b[\s\S]{0,80}addTransformer/i, severity: "high", category: "ClassLoader hijack", detail: "Registers a class-file transformer — can rewrite other mods at runtime." },
  { re: /Premain-Class\s*:/i, severity: "high", category: "ClassLoader hijack", detail: "Declares a Java agent (Premain-Class) — runs before the JVM main entrypoint." },
  { re: /Agent-Class\s*:/i, severity: "high", category: "ClassLoader hijack", detail: "Declares an attach-time Java agent (Agent-Class)." },

  // Clipboard hijack (crypto address swap, password steal)
  { re: /getSystemClipboard\s*\(/i, severity: "medium", category: "Clipboard hijack", detail: "Reads the system clipboard — used to steal copied passwords or swap crypto addresses." },
  { re: /\bStringSelection\b/i, severity: "medium", category: "Clipboard hijack", detail: "Writes to the system clipboard (StringSelection)." },

  // Persistence
  { re: /Startup\\.+\.(bat|cmd|exe|vbs)/i, severity: "critical", category: "Persistence", detail: "Writes to Windows Startup folder." },
  { re: /HKEY_(CURRENT|LOCAL)_(USER|MACHINE)/i, severity: "high", category: "Persistence", detail: "References Windows registry." },
  { re: /schtasks(\s|\.exe)/i, severity: "high", category: "Persistence", detail: "Uses schtasks (scheduled tasks)." },
  { re: /crontab|systemd\/user/i, severity: "medium", category: "Persistence", detail: "Linux persistence reference." },

  // In-game grief / SMP money theft
  { re: /(server|Bukkit|getServer\(\))\.dispatchCommand/i, severity: "high", category: "In-game grief", detail: "Dispatches server commands programmatically — can run /pay, /op, /give as player or console." },
  { re: /performCommand\s*\(/i, severity: "high", category: "In-game grief", detail: "Forces the player to run a chat command (used to drain SMP balances via /pay)." },
  { re: /sendChatMessage\s*\(\s*["']\//i, severity: "high", category: "In-game grief", detail: "Sends slash-commands through the player's chat (e.g. /pay, /trust, /sethome)." },
  { re: /["']\/pay\s+\S+/i, severity: "critical", category: "In-game grief", detail: "Hardcoded /pay command — direct in-game money theft." },
  { re: /\b(EssentialsX?|CoinsEngine|PlayerPoints|TokenManager)\b/, severity: "low", category: "In-game grief", detail: "References an economy plugin — verify it's not draining balances." },
  // Bare "pay <user> <amount>" — bytecode often stores the command WITHOUT the leading '/'
  // because the mod prepends '/' at runtime (e.g. networkHandler.sendChatCommand("/" + COMMAND)).
  { re: /\bpay\s+[A-Za-z0-9_]{2,16}\s+\d+\s*[kmbKMB]?\b/, severity: "critical", category: "In-game grief", detail: "Hardcoded pay command with target player + amount — auto-drains your in-game balance to a fixed account." },
  { re: /\b(tpa|tpahere|trust|sethome|warp)\s+[A-Za-z0-9_]{2,16}\b/, severity: "high", category: "In-game grief", detail: "Hardcoded teleport/trust command targeting a specific player — common grief/raid setup." },
  // Fabric / Yarn chat-send APIs (intermediary mappings)
  { re: /sendChatCommand\s*\(|sendChatMessage\s*\(|sendCommand\s*\(/i, severity: "medium", category: "In-game grief", detail: "Programmatically sends chat or slash commands as the player." },
  { re: /class_634\b/, severity: "low", category: "In-game grief", detail: "Uses ClientPlayNetworkHandler (Yarn class_634) — required to send chat/commands as the player." },
  // Auto-execute on join (Fabric events)
  { re: /ClientPlayConnectionEvents\$?Join|ClientPlayConnectionEvents\.JOIN/, severity: "medium", category: "Auto-execute", detail: "Hooks the 'player joins server' event — used to run actions the moment you connect." },
  { re: /ClientTickEvents(\$|\.)(END_CLIENT_TICK|EndTick)/, severity: "low", category: "Auto-execute", detail: "Hooks the client tick loop — used to delay or repeatedly fire actions." },
  { re: /["']\/(op|deop|give\s+@?\w+|tp\s+@?\w+|gamemode\s+creative)\b/i, severity: "high", category: "In-game grief", detail: "Hardcoded admin/cheat command found in code." },
  { re: /EconomyResponse|net\.milkbowl\.vault\.economy/i, severity: "medium", category: "In-game grief", detail: "Calls Vault economy API (withdraw/transfer balances)." },
  { re: /player\.getInventory\(\)\.clear|inventory\.clear\s*\(\s*\)/i, severity: "medium", category: "In-game grief", detail: "Clears a player's inventory." },

  // Microsoft / Mojang account hijack
  { re: /login\.microsoftonline\.com|login\.live\.com\/oauth20/i, severity: "high", category: "Account hijack", detail: "Talks to Microsoft OAuth endpoints — token-replay / phishing risk." },
  { re: /api\.minecraftservices\.com|sessionserver\.mojang\.com/i, severity: "high", category: "Account hijack", detail: "Calls Mojang/Microsoft session APIs directly — possible session hijack." },
  { re: /access_token|refresh_token|XSTSToken|userhash/i, severity: "medium", category: "Account hijack", detail: "Handles raw Microsoft auth tokens (access/refresh/XSTS)." },
];

const SUSPICIOUS_DOMAINS = [
  /\bwebhook\.site\b/i,
  /\bngrok\.io\b/i,
  /\bduckdns\.org\b/i,
  /\bno-ip\.org\b/i,
];

export type StaticReport = {
  findings: Finding[];
  score: number; // 0-100, higher = worse
  rationale: string[]; // plain-language reasons for the verdict
  manifest: {
    modId?: string;
    modName?: string;
    author?: string;
    version?: string;
    description?: string;
    homepage?: string;
    issues?: string;
  };
  stats: {
    fileCount: number;
    classCount: number;
    obfuscationRatio: number;
    nestedJars: number;
  };
};

const SEV_WEIGHT: Record<Finding["severity"], number> = { low: 2, medium: 6, high: 14, critical: 28 };

function buildRationale(findings: Finding[], score: number): string[] {
  if (findings.length === 0) {
    return ["No malicious code patterns matched. The jar looks clean to static analysis, but reputation and dynamic behavior still matter — only install from trusted sources."];
  }
  const cats = new Set(findings.map((f) => f.category));
  const lines: string[] = [];
  if (cats.has("Credential theft")) lines.push("Reads files that hold your Microsoft / Mojang login tokens or Discord token — classic account-stealer behavior.");
  if (cats.has("Network exfiltration")) lines.push("Sends data to an attacker-controlled URL (Discord webhook, Pastebin, anonymous file host).");
  if (cats.has("Account hijack")) lines.push("Talks directly to Microsoft/Mojang auth endpoints — could replay or steal your login session.");
  if (cats.has("In-game grief")) lines.push("Can run server commands like /pay, /op, /give, or clear your inventory — used to drain SMP money and grief.");
  if (cats.has("Auto-execute")) lines.push("Runs actions automatically on join or every tick — the user never types or clicks anything.");
  if (cats.has("Suspicious filename")) lines.push("Archive contains a folder/file with an openly malicious name (stealer, grabber, keylogger, etc.) — the author didn't even hide it.");
  if (cats.has("Code execution")) lines.push("Can execute OS commands or load extra code at runtime — a malicious payload can be downloaded after install.");
  if (cats.has("Dropper")) lines.push("Hides another .jar inside itself — a common way to ship a stealer disguised as a normal mod.");
  if (cats.has("Obfuscation")) lines.push("Code is obfuscated (single-letter class names) — legitimate mods rarely need this.");
  if (cats.has("Persistence")) lines.push("Tries to keep itself running after Minecraft closes (startup folder, registry, scheduled task).");
  if (cats.has("Network") && !cats.has("Network exfiltration")) lines.push("Contains hardcoded IP addresses or suspicious domains (ngrok, webhook.site, etc.).");
  if (cats.has("Manifest")) lines.push("Manifest is missing or incomplete — legitimate mods declare an author and ID.");
  lines.push(`Risk score: ${score}/100 based on ${findings.length} finding${findings.length === 1 ? "" : "s"}.`);
  return lines;
}


export function staticScanJar(jarBytes: Uint8Array): StaticReport {
  const findings: Finding[] = [];
  const manifest: StaticReport["manifest"] = {};

  let files: Record<string, Uint8Array>;
  try {
    files = unzipSync(jarBytes);
  } catch {
    findings.push({ severity: "high", category: "Format", detail: "File is not a valid ZIP/JAR archive." });
    return { findings, score: 100, rationale: ["Not a valid ZIP/JAR archive — Minecraft mods must be valid jar files."], manifest, stats: { fileCount: 0, classCount: 0, obfuscationRatio: 0, nestedJars: 0 } };
  }

  const names = Object.keys(files);
  const classFiles = names.filter((n) => n.endsWith(".class"));
  const nestedJars = names.filter((n) => n.endsWith(".jar")).length;

  // Suspicious entry/path names — even legitimate-looking jars get flagged if they ship a
  // resource folder literally named "money-stealer", "grabber", "keylogger", etc.
  const SUSPICIOUS_PATH_RE = /(^|\/)(money[-_]?stealer|token[-_]?grabber|grabber|stealer|keylogger|keylog|injector|rat|backdoor|crypter|loader|payload|exploit|griefer|nuker)(\/|\.|$)/i;
  for (const n of names) {
    if (SUSPICIOUS_PATH_RE.test(n)) {
      findings.push({
        severity: "critical",
        category: "Suspicious filename",
        detail: "Archive contains a file/folder with an openly malicious name.",
        evidence: n,
      });
      break;
    }
  }

  // Obfuscation heuristic: ratio of class file basenames with length <= 2
  let shortNames = 0;
  for (const n of classFiles) {
    const base = n.split("/").pop()!.replace(/\.class$/, "");
    if (base.length <= 2) shortNames++;
  }
  const obfuscationRatio = classFiles.length ? shortNames / classFiles.length : 0;
  if (obfuscationRatio > 0.4 && classFiles.length > 20) {
    findings.push({
      severity: "medium",
      category: "Obfuscation",
      detail: `High ratio of single/double-letter class names (${Math.round(obfuscationRatio * 100)}%).`,
    });
  }
  if (nestedJars > 0) {
    findings.push({
      severity: "high",
      category: "Dropper",
      detail: `Contains ${nestedJars} nested .jar file(s) — jar-in-jar droppers are a known stealer pattern.`,
    });
  }

  // Manifest parsing
  const manifestBytes = files["META-INF/MANIFEST.MF"];
  if (manifestBytes) {
    const text = strFromU8(manifestBytes);
    const main = text.match(/Main-Class:\s*(.+)/i)?.[1]?.trim();
    if (main) manifest.modId = main;
  }
  const fabricBytes = files["fabric.mod.json"];
  if (fabricBytes) {
    try {
      const j = JSON.parse(strFromU8(fabricBytes));
      manifest.modId = j.id;
      manifest.modName = j.name;
      manifest.version = j.version;
      manifest.description = j.description;
      if (Array.isArray(j.authors) && j.authors.length) {
        manifest.author = typeof j.authors[0] === "string" ? j.authors[0] : j.authors[0]?.name;
      }
      manifest.homepage = j.contact?.homepage;
      manifest.issues = j.contact?.issues;
    } catch { /* ignore */ }
  }
  const forgeBytes = files["META-INF/mods.toml"] || files["META-INF/neoforge.mods.toml"];
  if (forgeBytes) {
    const t = strFromU8(forgeBytes);
    manifest.modId ??= t.match(/modId\s*=\s*"([^"]+)"/)?.[1];
    manifest.modName ??= t.match(/displayName\s*=\s*"([^"]+)"/)?.[1];
    manifest.author ??= t.match(/authors?\s*=\s*"([^"]+)"/)?.[1];
    manifest.version ??= t.match(/version\s*=\s*"([^"]+)"/)?.[1];
    manifest.description ??= t.match(/description\s*=\s*'''([\s\S]*?)'''/)?.[1]?.trim();
  }

  if (!manifest.author) {
    findings.push({ severity: "low", category: "Manifest", detail: "No author declared in mod manifest." });
  }

  // Description self-describes auto-execute behavior, e.g.
  // "Automatically runs a command when you join donutsmp.net."
  if (manifest.description) {
    const d = manifest.description;
    if (/automatic\w*[\s\S]{0,40}(run|send|execute|type)[\s\S]{0,40}(command|chat|message)/i.test(d) ||
        /(run|send|execute|type)[\s\S]{0,40}command[\s\S]{0,40}(when|on)[\s\S]{0,40}join/i.test(d)) {
      findings.push({
        severity: "high",
        category: "Auto-execute",
        detail: "Mod description openly states it auto-runs a chat command when you join a server.",
        evidence: d.slice(0, 160),
      });
    }
    // Specific target server hostnames frequently used in pay-on-join scams
    const serverHost = d.match(/\b([a-z0-9-]+\.(?:net|com|org|gg|io|club|fun|xyz))\b/i);
    if (serverHost && /\b(join|server|smp)\b/i.test(d)) {
      findings.push({
        severity: "medium",
        category: "Auto-execute",
        detail: "Mod targets a specific server (" + serverHost[1] + ") — combined with command-send APIs this is auto-pay-on-join behavior.",
        evidence: d.slice(0, 160),
      });
    }
    // Filename / displayed-name mismatch with manifest id — common disguise
    // (e.g. file looks like "Auction_Sniper.jar" but mod id is "autocommand").
  }

  // Scan content
  const seen = new Set<string>();
  const BASE64_DECODE_RE = /Base64[\s\S]{0,40}\.decode\s*\(|getDecoder\s*\(\s*\)\s*\.\s*decode\s*\(/i;
  const EXEC_AFTER_DECODE_RE = /(defineClass\s*\(|Runtime\.getRuntime\s*\(\s*\)\s*\.\s*exec|ProcessBuilder)/i;
  let base64ExecChainFlagged = false;

  for (const name of names) {
    if (name.endsWith("/") || files[name].length === 0) continue;
    if (files[name].length > 5_000_000) continue; // skip very large
    const text = strFromU8(files[name], true);
    if (!text) continue;

    for (const ind of INDICATORS) {
      const key = `${ind.category}:${ind.detail}`;
      if (seen.has(key)) continue;
      const m = text.match(ind.re);
      if (m) {
        seen.add(key);
        findings.push({
          severity: ind.severity,
          category: ind.category,
          detail: ind.detail,
          evidence: `${name} — "${m[0].slice(0, 120)}"`,
        });
      }
    }
    for (const dom of SUSPICIOUS_DOMAINS) {
      const key = `Suspicious domain:${dom.source}`;
      if (seen.has(key)) continue;
      const m = text.match(dom);
      if (m) {
        seen.add(key);
        findings.push({
          severity: "medium",
          category: "Network",
          detail: `Suspicious domain reference: ${m[0]}`,
          evidence: name,
        });
      }
    }

    // Base64 -> execute chain (same file)
    if (!base64ExecChainFlagged && BASE64_DECODE_RE.test(text) && EXEC_AFTER_DECODE_RE.test(text)) {
      base64ExecChainFlagged = true;
      findings.push({
        severity: "high",
        category: "Code execution",
        detail: "Base64 decode combined with defineClass/Runtime.exec/ProcessBuilder in the same file — classic hidden-payload chain.",
        evidence: name,
      });
    }
  }

  // Empty / stub JAR
  const hasModManifest = !!(files["fabric.mod.json"] || files["META-INF/mods.toml"] || files["META-INF/neoforge.mods.toml"] || files["mcmod.info"]);
  if (classFiles.length > 0 && classFiles.length < 3 && !hasModManifest) {
    findings.push({
      severity: "medium",
      category: "Stub jar",
      detail: `Jar contains only ${classFiles.length} class file(s) and no mod manifest — looks like a stub or loader, not a real mod.`,
    });
  } else if (classFiles.length === 0 && !hasModManifest && nestedJars === 0) {
    findings.push({
      severity: "medium",
      category: "Stub jar",
      detail: "Jar has no classes and no mod manifest — not a functional Minecraft mod.",
    });
  }


  // Extra passes: entropy + native-in-JAR
  const hasNetworkIndicator = () =>
    findings.some((f) => f.category === "Network exfiltration" || f.category === "Network" || f.category === "Account hijack");
  try { entropyPass(files, classFiles, findings, hasNetworkIndicator); } catch { /* best effort */ }
  try { nativeInJarPass(files, findings); } catch { /* best effort */ }

  let score = 0;
  for (const f of findings) score += SEV_WEIGHT[f.severity];
  score = Math.min(100, score);

  // Correlation: auto-execute + in-game grief = auto-pay-on-join. Push to critical.
  const cats2 = new Set(findings.map((f) => f.category));
  if (cats2.has("Auto-execute") && cats2.has("In-game grief")) {
    findings.unshift({
      severity: "critical",
      category: "Auto-execute",
      detail: "Auto-runs a chat command on join — this is the exact pattern of 'auto /pay' money-stealer mods.",
    });
    score = Math.min(100, score + 30);
  }

  return {
    findings,
    score,
    rationale: buildRationale(findings, score),
    manifest,
    stats: {
      fileCount: names.length,
      classCount: classFiles.length,
      obfuscationRatio,
      nestedJars,
    },
  };
}

export function codeVerdictFromScore(score: number): "safe" | "low_risk" | "suspicious" | "likely_malicious" | "confirmed_malicious" {
  if (score >= 60) return "confirmed_malicious";
  if (score >= 35) return "likely_malicious";
  if (score >= 18) return "suspicious";
  if (score >= 6) return "low_risk";
  return "safe";
}
