// Single adapter for the Process Monitor UI.
// - Default source: mock (so the UI is fully demo-able while Claude builds the backend)
// - Set VITE_MONITOR_SOURCE=live and implement the contract in BACKEND_HANDOFF.md
//   to flip to real data — no UI changes required.

import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  mockAlerts, mockConnections, mockConsent, mockExplanation,
  mockProcesses, mockResourceSeries,
} from "./monitor-mock";
import type {
  ConsentDiff, MonitorAlert, MonitorConnection, MonitorProcess,
  ProcessExplanation, ResourceSample, RiskLabel,
} from "./monitor-types";

const SOURCE = (import.meta.env.VITE_MONITOR_SOURCE as string | undefined) ?? "mock";
const LIVE = SOURCE === "live";

async function authHeaders(): Promise<HeadersInit> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function jget<T>(path: string): Promise<T> {
  const res = await fetch(path, { headers: await authHeaders() });
  if (!res.ok) throw new Error(`${path} ${res.status}`);
  return res.json() as Promise<T>;
}

export function useProcesses() {
  return useQuery<MonitorProcess[]>({
    queryKey: ["monitor", "processes", SOURCE],
    queryFn: () => (LIVE ? jget("/api/monitor/processes") : Promise.resolve(mockProcesses())),
    refetchInterval: 3000,
  });
}

export function useConnections() {
  return useQuery<MonitorConnection[]>({
    queryKey: ["monitor", "connections", SOURCE],
    queryFn: () => (LIVE ? jget("/api/monitor/connections") : Promise.resolve(mockConnections())),
    refetchInterval: 4000,
  });
}

export function useConsentDiff() {
  return useQuery<ConsentDiff[]>({
    queryKey: ["monitor", "consent", SOURCE],
    queryFn: () => (LIVE ? jget("/api/monitor/consent") : Promise.resolve(mockConsent())),
    refetchInterval: 10_000,
  });
}

export function useAlerts() {
  return useQuery<MonitorAlert[]>({
    queryKey: ["monitor", "alerts", SOURCE],
    queryFn: () => (LIVE ? jget("/api/monitor/alerts") : Promise.resolve(mockAlerts())),
    refetchInterval: 5000,
  });
}

// Rolling resource series — keeps last 60 samples client-side so the chart
// updates smoothly even when the backend returns the full window each poll.
export function useResourceSeries() {
  const [series, setSeries] = useState<ResourceSample[]>(() => (LIVE ? [] : mockResourceSeries()));
  useEffect(() => {
    let cancelled = false;
    const tick = async () => {
      try {
        const next = LIVE
          ? await jget<ResourceSample[]>("/api/monitor/resources?range=2m")
          : mockResourceSeries();
        if (cancelled) return;
        if (LIVE) {
          setSeries(next.slice(-60));
        } else {
          // simulate a rolling window
          setSeries((prev) => [...prev.slice(1), next[next.length - 1]]);
        }
      } catch {
        // ignore transient network errors
      }
    };
    const id = setInterval(tick, 2000);
    return () => { cancelled = true; clearInterval(id); };
  }, []);
  return series;
}

export function useExplanation(p: MonitorProcess | null) {
  return useQuery<ProcessExplanation>({
    queryKey: ["monitor", "explanation", SOURCE, p?.pid ?? "none"],
    enabled: !!p,
    queryFn: async () => {
      if (!p) throw new Error("no process");
      if (LIVE) {
        const res = await fetch("/api/monitor/explain", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ pid: p.pid }),
        });
        if (!res.ok) throw new Error(`explain ${res.status}`);
        return (await res.json()) as ProcessExplanation;
      }
      // Fake a network round-trip for demo realism
      await new Promise((r) => setTimeout(r, 600));
      return mockExplanation(p.pid, p.name, p.risk);
    },
    staleTime: 60_000,
  });
}

export function riskColor(risk: RiskLabel) {
  switch (risk) {
    case "low": return "text-[hsl(var(--mon-ok))] bg-[hsl(var(--mon-ok))]/15 border-[hsl(var(--mon-ok))]/30";
    case "medium": return "text-[hsl(var(--mon-warn))] bg-[hsl(var(--mon-warn))]/15 border-[hsl(var(--mon-warn))]/30";
    case "high": return "text-[hsl(var(--mon-bad))] bg-[hsl(var(--mon-bad))]/15 border-[hsl(var(--mon-bad))]/35";
    case "suspicious": return "text-[hsl(var(--mon-crit))] bg-[hsl(var(--mon-crit))]/20 border-[hsl(var(--mon-crit))]/40";
  }
}

export const MONITOR_SOURCE = SOURCE;
export const MONITOR_IS_LIVE = LIVE;