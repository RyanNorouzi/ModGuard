// App version. Bump on every change.
// - Major (1.x.x): big feature / breaking change
// - Minor (x.1.x): new feature
// - Patch (x.x.1): small fix or copy change
export const APP_VERSION = "1.1.0";
