import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

const ScanInput = z.object({
  fileName: z.string().min(1).max(256),
  fileBase64: z.string().min(8).max(60_000_000),
});

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const ab = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(ab).set(bytes);
  const buf = await crypto.subtle.digest("SHA-256", ab);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

type FinalVerdict = "safe" | "low_risk" | "suspicious" | "likely_malicious" | "confirmed_malicious";

export const scanJar = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ScanInput.parse(input))
  .handler(async ({ data }) => {
    const { staticScanJar, codeVerdictFromScore } = await import("./scan-static.server");
    const { fetchReputation, reputationVerdict, combineVerdicts } = await import("./reputation.server");

    const bytes = base64ToBytes(data.fileBase64);
    if (bytes.length > 45_000_000) {
      throw new Error("File too large (max 45MB).");
    }
    const sha256 = await sha256Hex(bytes);

    const supabasePublic = createClient<Database>(
      process.env.SUPABASE_URL!,
      process.env.SUPABASE_PUBLISHABLE_KEY!,
      { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
    );
    const { data: known } = await supabasePublic
      .from("known_mods")
      .select("name, author, verdict, source, notes")
      .eq("sha256", sha256)
      .maybeSingle();

    const stat = staticScanJar(bytes);

    // Upstream hash comparison (Modrinth) — best effort
    const { checkUpstreamHash } = await import("./upstream-hash.server");
    const upstream = await checkUpstreamHash(bytes, stat.manifest.modId, stat.manifest.version);
    if (upstream.status === "mismatch") {
      stat.findings.push({
        severity: "critical",
        category: "Upstream mismatch",
        detail: `Claims to be "${upstream.project}" v${upstream.version} but its hash does not match the official Modrinth release — possible trojanized redistribution.`,
        evidence: upstream.url,
      });
      stat.score = Math.min(100, stat.score + 35);
      stat.rationale.unshift("This file claims to be a known mod but its bytes don't match the official release on Modrinth — someone may have modified and re-uploaded it.");
    } else if (upstream.status === "version_not_found") {
      stat.findings.push({
        severity: "medium",
        category: "Upstream mismatch",
        detail: `Declared version "${upstream.declaredVersion}" not published on Modrinth for project "${upstream.project}".`,
        evidence: upstream.url,
      });
      stat.score = Math.min(100, stat.score + 8);
    } else if (upstream.status === "verified") {
      stat.score = Math.max(0, stat.score - 5);
      stat.rationale.unshift(`Verified: hash matches the official Modrinth release of ${upstream.project} v${upstream.version}.`);
    }

    const codeVerdict = codeVerdictFromScore(stat.score);
    const name = stat.manifest.modName ?? stat.manifest.modId ?? data.fileName.replace(/\.jar$/i, "");
    const author = stat.manifest.author;

    const cacheKey = `${sha256}|${name.toLowerCase()}`;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: cached } = await supabaseAdmin
      .from("mod_reputation")
      .select("payload, fetched_at")
      .eq("cache_key", cacheKey)
      .maybeSingle();

    let reputation;
    if (cached && Date.now() - new Date(cached.fetched_at).getTime() < 7 * 86_400_000) {
      reputation = cached.payload as Awaited<ReturnType<typeof fetchReputation>>;
    } else {
      reputation = await fetchReputation(name, author);
      await supabaseAdmin
        .from("mod_reputation")
        .upsert(
          { cache_key: cacheKey, payload: reputation as never, fetched_at: new Date().toISOString() },
          { onConflict: "cache_key" },
        );
    }

    const repVerdict = reputationVerdict(reputation);
    let finalVerdict: FinalVerdict;
    if (known?.verdict === "confirmed_malicious") finalVerdict = "confirmed_malicious";
    else if (known?.verdict === "safe") finalVerdict = "safe";
    else finalVerdict = combineVerdicts(codeVerdict, repVerdict);

    return {
      sha256,
      fileName: data.fileName,
      name,
      author: author ?? null,
      known,
      codeVerdict,
      reputationVerdict: repVerdict,
      finalVerdict,
      findings: stat.findings,
      rationale: stat.rationale,
      manifest: stat.manifest,
      stats: stat.stats,
      reputation,
      upstream,
    };
  });
