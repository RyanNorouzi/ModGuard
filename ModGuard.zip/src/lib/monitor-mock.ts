// Deterministic-ish mock generator for the Process Monitor.
// Used while the companion-agent backend is being built by Claude.
// Swap to live data by setting VITE_MONITOR_SOURCE=live.

import type {
  ConsentDiff, MonitorAlert, MonitorConnection, MonitorProcess,
  MonitorSnapshot, ProcessExplanation, ResourceSample, RiskLabel,
} from "./monitor-types";

const TRUSTED_HOSTS = new Set([
  "minecraft.net", "session.minecraft.net", "api.modrinth.com",
  "media.forgecdn.net", "edge.forgecdn.net", "roblox.com",
  "presence.roblox.com", "auth.roblox.com",
]);

const SUSPICIOUS_HOSTS = [
  "pastebin.com", "discord-app-cdn.click", "free-robux-gen.xyz",
  "cdn.r0blox.top", "telegra.ph", "transfer.sh",
];

function jitter(base: number, spread: number) {
  return Math.max(0, base + (Math.random() - 0.5) * 2 * spread);
}

const PROCS: Omit<MonitorProcess, "cpuPct" | "memMb" | "netInKbps" | "netOutKbps" | "startedAt" | "risk">[] = [
  { pid: 4812, name: "javaw.exe (Minecraft)", gameId: "minecraft", cmdline: "javaw -Xmx4G -jar forge-1.20.1.jar", parentPid: 1024 },
  { pid: 5120, name: "RobloxPlayerBeta.exe", gameId: "roblox", cmdline: "RobloxPlayerBeta.exe --place=1818", parentPid: 1024 },
  { pid: 7311, name: "modloader_helper.exe", modId: "mod-3", gameId: "minecraft", cmdline: "modloader_helper.exe --silent", parentPid: 4812, persistsAfterClose: false, abnormalResources: true },
  { pid: 9920, name: "powershell.exe", gameId: "minecraft", cmdline: "powershell -nop -w hidden -enc <base64>", parentPid: 7311, persistsAfterClose: true, abnormalResources: false },
  { pid: 2204, name: "GameOverlayUI.exe", gameId: "cs2", cmdline: "GameOverlayUI.exe", parentPid: 1024 },
  { pid: 6680, name: "chrome.exe (mod portal)", cmdline: "chrome.exe --app=https://modrinth.com" },
];

function riskFor(p: typeof PROCS[number]): RiskLabel {
  if (p.name.includes("powershell")) return "suspicious";
  if (p.persistsAfterClose) return "high";
  if (p.abnormalResources) return "medium";
  if (p.name === "modloader_helper.exe") return "medium";
  return "low";
}

export function mockProcesses(): MonitorProcess[] {
  const t0 = Date.now() - 1000 * 60 * 12;
  return PROCS.map((p, i) => ({
    ...p,
    cpuPct: jitter(p.name.includes("javaw") ? 38 : p.name.includes("Roblox") ? 22 : p.abnormalResources ? 64 : 4, 6),
    memMb: Math.round(jitter(p.name.includes("javaw") ? 2800 : p.name.includes("Roblox") ? 1400 : 180, 60)),
    netInKbps: Math.round(jitter(p.name.includes("powershell") ? 0 : 18, 8)),
    netOutKbps: Math.round(jitter(p.name.includes("powershell") ? 124 : p.name === "modloader_helper.exe" ? 96 : 6, 12)),
    startedAt: new Date(t0 + i * 1000 * 47).toISOString(),
    risk: riskFor(p),
  }));
}

export function mockConnections(): MonitorConnection[] {
  const now = Date.now();
  const rows: Omit<MonitorConnection, "id" | "unknownDomain">[] = [
    { pid: 4812, processName: "javaw.exe (Minecraft)", remoteHost: "session.minecraft.net", remoteIp: "13.107.42.16", remotePort: 443, bytesSent: 4_812_000, bytesReceived: 11_900_000, requestCount: 87, firstSeen: new Date(now - 1000 * 60 * 11).toISOString(), lastSeen: new Date(now - 1000 * 4).toISOString() },
    { pid: 4812, processName: "javaw.exe (Minecraft)", remoteHost: "media.forgecdn.net", remoteIp: "152.199.21.175", remotePort: 443, bytesSent: 120_000, bytesReceived: 3_400_000, requestCount: 12, firstSeen: new Date(now - 1000 * 60 * 10).toISOString(), lastSeen: new Date(now - 1000 * 60 * 2).toISOString() },
    { pid: 5120, processName: "RobloxPlayerBeta.exe", remoteHost: "presence.roblox.com", remoteIp: "128.116.0.5", remotePort: 443, bytesSent: 220_000, bytesReceived: 980_000, requestCount: 41, firstSeen: new Date(now - 1000 * 60 * 8).toISOString(), lastSeen: new Date(now - 1000 * 6).toISOString() },
    { pid: 7311, processName: "modloader_helper.exe", remoteHost: "free-robux-gen.xyz", remoteIp: "104.21.55.12", remotePort: 443, bytesSent: 1_900_000, bytesReceived: 24_000, requestCount: 211, firstSeen: new Date(now - 1000 * 60 * 7).toISOString(), lastSeen: new Date(now - 1000 * 2).toISOString() },
    { pid: 9920, processName: "powershell.exe", remoteHost: "transfer.sh", remoteIp: "144.76.136.153", remotePort: 443, bytesSent: 12_400_000, bytesReceived: 8_000, requestCount: 3, firstSeen: new Date(now - 1000 * 60 * 3).toISOString(), lastSeen: new Date(now - 1000 * 30).toISOString() },
    { pid: 9920, processName: "powershell.exe", remoteHost: "discord-app-cdn.click", remoteIp: "172.67.190.4", remotePort: 443, bytesSent: 8_000, bytesReceived: 410_000, requestCount: 6, firstSeen: new Date(now - 1000 * 60 * 5).toISOString(), lastSeen: new Date(now - 1000 * 45).toISOString() },
  ];
  return rows.map((r, i) => ({
    ...r,
    id: `conn-${i}`,
    unknownDomain: !TRUSTED_HOSTS.has(r.remoteHost),
  }));
}

export function mockResourceSeries(): ResourceSample[] {
  const out: ResourceSample[] = [];
  const now = Date.now();
  for (let i = 59; i >= 0; i--) {
    const t = new Date(now - i * 2000).toISOString();
    const drift = Math.sin(i / 6) * 8;
    out.push({
      t,
      cpuPct: Math.round(Math.max(4, Math.min(95, 42 + drift + (Math.random() - 0.5) * 10))),
      gpuPct: Math.round(Math.max(2, Math.min(98, 58 + Math.cos(i / 4) * 12 + (Math.random() - 0.5) * 8))),
      memPct: Math.round(Math.max(20, Math.min(90, 61 + Math.sin(i / 11) * 4))),
    });
  }
  return out;
}

export function mockConsent(): ConsentDiff[] {
  return [
    {
      modId: "mod-3",
      modName: "EpicTextures Loader",
      claims: [
        { capability: "fs.read.gameDir", declared: true, observed: true, detail: "Reads texture cache." },
        { capability: "fs.write.gameDir", declared: true, observed: true },
        { capability: "network.outbound", declared: false, observed: true, detail: "Outbound POST to free-robux-gen.xyz" },
        { capability: "process.spawn", declared: false, observed: true, detail: "Spawned powershell.exe with encoded command" },
        { capability: "persistence.autostart", declared: false, observed: true, detail: "Wrote to HKCU\\Run" },
        { capability: "telemetry.anonymous", declared: true, observed: false, detail: "Declared but never observed (good)." },
      ],
      get mismatches() {
        return this.claims.filter((c) => c.declared !== c.observed);
      },
    },
  ].map((c) => ({ ...c, mismatches: c.claims.filter((x) => x.declared !== x.observed) }));
}

export function mockAlerts(): MonitorAlert[] {
  const now = new Date().toISOString();
  return [
    {
      id: "a1",
      kind: "persistence",
      severity: "critical",
      title: "Process persists after game closed",
      message: "powershell.exe (PID 9920) is still running 4m after Minecraft exited.",
      pid: 9920,
      processName: "powershell.exe",
      createdAt: now,
    },
    {
      id: "a2",
      kind: "unknown_domain",
      severity: "warning",
      title: "Outbound traffic to unrecognized domain",
      message: "modloader_helper.exe is sending data to free-robux-gen.xyz — not on the allowlist for any installed mod.",
      pid: 7311,
      processName: "modloader_helper.exe",
      remoteHost: "free-robux-gen.xyz",
      createdAt: now,
    },
    {
      id: "a3",
      kind: "abnormal_resources",
      severity: "warning",
      title: "Abnormal resource usage",
      message: "modloader_helper.exe is using 64% CPU — 12× its 7-day baseline.",
      pid: 7311,
      processName: "modloader_helper.exe",
      createdAt: now,
    },
  ];
}

export function mockExplanation(pid: number, processName: string, risk: RiskLabel): ProcessExplanation {
  const reasons: Record<RiskLabel, string[]> = {
    low: ["Signed by a trusted vendor.", "Network activity stays within the game's official domains.", "Resource usage matches the 7-day baseline."],
    medium: ["Network activity exceeds the declared mod manifest.", "Some outbound traffic goes to domains not on the mod's allowlist."],
    high: ["The process keeps running after the parent game exited — typical of persistence/stealer behavior.", "It writes to autostart registry keys it did not declare."],
    suspicious: ["Launched a hidden PowerShell with a base64-encoded command.", "Uploaded data to a public file-drop service.", "No matching declaration in the mod's manifest."],
  };
  const summary: Record<RiskLabel, string> = {
    low: `${processName} looks normal for this kind of mod — nothing unexpected on disk or network.`,
    medium: `${processName} is doing a couple of things its manifest didn't promise. Probably not malicious, but worth watching.`,
    high: `${processName} is showing classic post-exit persistence behavior. Treat it as untrusted until it's cleared.`,
    suspicious: `${processName} is behaving like a credential stealer: hidden shell, encoded payload, off-allowlist uploads. Recommend killing and uninstalling the parent mod.`,
  };
  const action: Record<RiskLabel, ProcessExplanation["recommendedAction"]> = {
    low: "allow", medium: "monitor", high: "kill", suspicious: "uninstall",
  };
  return { pid, risk, summary: summary[risk], reasons: reasons[risk], recommendedAction: action[risk] };
}

export function mockSnapshot(): MonitorSnapshot {
  return {
    takenAt: new Date().toISOString(),
    processes: mockProcesses(),
    connections: mockConnections(),
    resources: mockResourceSeries(),
    alerts: mockAlerts(),
    consent: mockConsent(),
  };
}