import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

export type ReputationSource = {
  source: string;
  url: string;
  title: string;
  snippet?: string;
  signal: "positive" | "neutral" | "negative" | "warning";
};

export type ReputationReport = {
  presence_score: number; // 0-100, lower = more obscure
  community_sentiment: "positive" | "mixed" | "neutral" | "negative" | "malware_accused";
  author_trust: "established" | "new" | "unknown" | "suspicious";
  summary: string;
  sources: ReputationSource[];
  curseforge?: { found: boolean; downloads?: number; url?: string };
  modrinth?: { found: boolean; downloads?: number; url?: string; author?: string };
  github_author?: { found: boolean; followers?: number; public_repos?: number; created_at?: string; url?: string };
};

const UA = { "User-Agent": "ModGuard/1.0 (+https://modguard.app)" };

async function safeFetch(url: string, init?: RequestInit, timeoutMs = 8000): Promise<Response | null> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), timeoutMs);
    const r = await fetch(url, { ...init, signal: ctl.signal, headers: { ...UA, ...(init?.headers || {}) } });
    clearTimeout(t);
    return r;
  } catch {
    return null;
  }
}

async function checkModrinth(name: string): Promise<ReputationReport["modrinth"] & { hit?: ReputationSource }> {
  if (!name) return { found: false };
  const url = `https://api.modrinth.com/v2/search?query=${encodeURIComponent(name)}&limit=3`;
  const r = await safeFetch(url);
  if (!r?.ok) return { found: false };
  const j = (await r.json().catch(() => null)) as { hits?: Array<{ title: string; slug: string; downloads: number; author: string }> } | null;
  const top = j?.hits?.find((h) => h.title.toLowerCase().includes(name.toLowerCase()) || name.toLowerCase().includes(h.title.toLowerCase()));
  if (!top) return { found: false };
  return {
    found: true,
    downloads: top.downloads,
    url: `https://modrinth.com/mod/${top.slug}`,
    author: top.author,
    hit: {
      source: "Modrinth",
      url: `https://modrinth.com/mod/${top.slug}`,
      title: `${top.title} by ${top.author}`,
      snippet: `${top.downloads.toLocaleString()} downloads`,
      signal: top.downloads > 10_000 ? "positive" : "neutral",
    },
  };
}

async function checkCurseForge(name: string): Promise<ReputationReport["curseforge"] & { hit?: ReputationSource }> {
  if (!name) return { found: false };
  // CurseForge public search via their website search JSON is rate-limited; use a fallback HEAD probe via DuckDuckGo isn't reliable.
  // Use the public search endpoint without auth (best-effort).
  const url = `https://www.curseforge.com/api/v1/mods/search?gameId=432&pageSize=3&searchFilter=${encodeURIComponent(name)}&classId=6`;
  const r = await safeFetch(url);
  if (!r?.ok) return { found: false };
  const j = (await r.json().catch(() => null)) as { data?: Array<{ name: string; slug: string; downloadCount: number; links?: { websiteUrl?: string } }> } | null;
  const top = j?.data?.find((d) => d.name.toLowerCase().includes(name.toLowerCase()) || name.toLowerCase().includes(d.name.toLowerCase()));
  if (!top) return { found: false };
  const link = top.links?.websiteUrl || `https://www.curseforge.com/minecraft/mc-mods/${top.slug}`;
  return {
    found: true,
    downloads: top.downloadCount,
    url: link,
    hit: {
      source: "CurseForge",
      url: link,
      title: top.name,
      snippet: `${top.downloadCount.toLocaleString()} downloads`,
      signal: top.downloadCount > 10_000 ? "positive" : "neutral",
    },
  };
}

async function checkGithubAuthor(author?: string): Promise<ReputationReport["github_author"] & { hit?: ReputationSource }> {
  if (!author) return { found: false };
  const handle = author.replace(/\s+/g, "").replace(/[^A-Za-z0-9-]/g, "");
  if (!handle) return { found: false };
  const r = await safeFetch(`https://api.github.com/users/${encodeURIComponent(handle)}`);
  if (!r?.ok) return { found: false };
  const j = (await r.json().catch(() => null)) as { login: string; followers: number; public_repos: number; created_at: string; html_url: string } | null;
  if (!j?.login) return { found: false };
  const ageDays = (Date.now() - new Date(j.created_at).getTime()) / 86_400_000;
  const signal: ReputationSource["signal"] = ageDays > 365 && j.public_repos > 3 ? "positive" : ageDays < 60 ? "warning" : "neutral";
  return {
    found: true,
    followers: j.followers,
    public_repos: j.public_repos,
    created_at: j.created_at,
    url: j.html_url,
    hit: {
      source: "GitHub",
      url: j.html_url,
      title: `@${j.login}`,
      snippet: `${j.public_repos} repos · ${j.followers} followers · joined ${j.created_at.slice(0, 10)}`,
      signal,
    },
  };
}

async function checkReddit(name: string): Promise<ReputationSource[]> {
  if (!name) return [];
  const query = `${name} (malware OR stealer OR scam OR rat OR virus)`;
  const url = `https://www.reddit.com/search.json?q=${encodeURIComponent(query)}&restrict_sr=&sort=relevance&t=year&limit=5`;
  const r = await safeFetch(url);
  if (!r?.ok) return [];
  const j = (await r.json().catch(() => null)) as { data?: { children?: Array<{ data: { title: string; permalink: string; subreddit: string; selftext?: string } }> } } | null;
  const items = j?.data?.children ?? [];
  return items.slice(0, 4).map((c) => ({
    source: `Reddit r/${c.data.subreddit}`,
    url: `https://www.reddit.com${c.data.permalink}`,
    title: c.data.title,
    snippet: c.data.selftext?.slice(0, 180),
    signal: "warning",
  }));
}

async function summarizeWithAi(payload: {
  name: string;
  author?: string;
  curseforge: ReputationReport["curseforge"];
  modrinth: ReputationReport["modrinth"];
  github: ReputationReport["github_author"];
  reddit: ReputationSource[];
}): Promise<{ summary: string; sentiment: ReputationReport["community_sentiment"]; trust: ReputationReport["author_trust"] }> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) {
    return { summary: "AI summary unavailable.", sentiment: "neutral", trust: "unknown" };
  }
  const gateway = createLovableAiGatewayProvider(key);
  const schema = z.object({
    summary: z.string().max(600),
    sentiment: z.enum(["positive", "mixed", "neutral", "negative", "malware_accused"]),
    trust: z.enum(["established", "new", "unknown", "suspicious"]),
  });

  const prompt = `You are a Minecraft mod safety analyst. Based ONLY on the evidence below, write a 2-3 sentence reputation summary for the mod, classify community sentiment, and rate the author's trust level. Be honest about uncertainty.

Mod name: ${payload.name}
Author: ${payload.author ?? "unknown"}

CurseForge: ${JSON.stringify(payload.curseforge)}
Modrinth: ${JSON.stringify(payload.modrinth)}
GitHub author: ${JSON.stringify(payload.github)}
Reddit malware/scam search results: ${JSON.stringify(payload.reddit.map((r) => ({ title: r.title, snippet: r.snippet })))}

Return JSON: { "summary": string, "sentiment": "positive"|"mixed"|"neutral"|"negative"|"malware_accused", "trust": "established"|"new"|"unknown"|"suspicious" }`;

  try {
    const { text } = await generateText({
      model: gateway("google/gemini-2.5-flash-lite"),
      prompt,
    });
    const cleaned = text.replace(/```json|```/g, "").trim();
    const parsed = schema.parse(JSON.parse(cleaned));
    return { summary: parsed.summary, sentiment: parsed.sentiment, trust: parsed.trust };
  } catch (e) {
    console.error("AI summary failed", e);
    return { summary: "AI summary unavailable.", sentiment: "neutral", trust: "unknown" };
  }
}

export async function fetchReputation(name: string, author?: string): Promise<ReputationReport> {
  if (!name) {
    return {
      presence_score: 0,
      community_sentiment: "neutral",
      author_trust: "unknown",
      summary: "No mod name detected in manifest — cannot perform reputation lookup.",
      sources: [],
    };
  }

  const [mr, cf, gh, reddit] = await Promise.all([
    checkModrinth(name),
    checkCurseForge(name),
    checkGithubAuthor(author),
    checkReddit(name),
  ]);

  const sources: ReputationSource[] = [];
  if (mr.hit) sources.push(mr.hit);
  if (cf.hit) sources.push(cf.hit);
  if (gh.hit) sources.push(gh.hit);
  sources.push(...reddit);

  const presence_score = (mr.found ? 50 : 0) + (cf.found ? 35 : 0) + (gh.found ? 15 : 0);

  const ai = await summarizeWithAi({ name, author, curseforge: cf, modrinth: mr, github: gh, reddit });

  return {
    presence_score,
    community_sentiment: ai.sentiment,
    author_trust: ai.trust,
    summary: ai.summary,
    sources,
    curseforge: cf,
    modrinth: mr,
    github_author: gh,
  };
}

export function reputationVerdict(rep: ReputationReport): "safe" | "low_risk" | "suspicious" | "likely_malicious" | "confirmed_malicious" | "unknown" {
  if (rep.community_sentiment === "malware_accused") return "likely_malicious";
  if (rep.community_sentiment === "negative" && rep.author_trust === "suspicious") return "likely_malicious";
  if (rep.author_trust === "suspicious") return "suspicious";
  if (rep.presence_score >= 60 && rep.community_sentiment === "positive" && rep.author_trust === "established") return "safe";
  if (rep.presence_score >= 35) return "low_risk";
  if (rep.presence_score === 0) return "suspicious"; // totally unknown is risky
  return "unknown";
}

export function combineVerdicts(
  code: "safe" | "low_risk" | "suspicious" | "likely_malicious" | "confirmed_malicious",
  rep: "safe" | "low_risk" | "suspicious" | "likely_malicious" | "confirmed_malicious" | "unknown",
): "safe" | "low_risk" | "suspicious" | "likely_malicious" | "confirmed_malicious" {
  const rank = { safe: 0, low_risk: 1, suspicious: 2, likely_malicious: 3, confirmed_malicious: 4 } as const;
  const c = rank[code];
  const r = rep === "unknown" ? 1 : rank[rep];
  const max = Math.max(c, r);
  // If both are >= suspicious, escalate
  const final = (c >= 2 && r >= 2) ? Math.min(4, max + 1) : max;
  return (["safe", "low_risk", "suspicious", "likely_malicious", "confirmed_malicious"] as const)[final];
}
