import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

type Verdict = Database["public"]["Enums"]["verdict"];

const MALICIOUS: Verdict[] = ["suspicious", "likely_malicious", "confirmed_malicious"];

function publicClient() {
  return createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

const RecordInput = z.object({
  sha256: z.string().regex(/^[a-f0-9]{0,64}$/i).optional().nullable(),
  fileName: z.string().min(1).max(512),
  gameId: z.string().min(1).max(64),
  verdict: z.enum(["safe", "low_risk", "suspicious", "likely_malicious", "confirmed_malicious", "unknown"]),
  severityCounts: z.record(z.string(), z.number().int().nonnegative()).default({}),
  source: z.enum(["file", "url"]),
});

export const recordScanEvent = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => RecordInput.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const sha = data.sha256 && /^[a-f0-9]{64}$/i.test(data.sha256) ? data.sha256.toLowerCase() : null;

    const { error: insertErr } = await supabaseAdmin.from("scan_events").insert({
      sha256: sha,
      file_name: data.fileName,
      game_id: data.gameId,
      verdict: data.verdict,
      severity_counts: data.severityCounts,
      source: data.source,
    });
    if (insertErr) throw new Error(insertErr.message);

    // Upsert into the malware signature DB when verdict is malicious and we have a hash.
    if (sha && MALICIOUS.includes(data.verdict)) {
      const { data: existing } = await supabaseAdmin
        .from("known_mods")
        .select("id, hit_count, verdict")
        .eq("sha256", sha)
        .maybeSingle();

      if (existing) {
        const rank: Record<Verdict, number> = {
          safe: 0, low_risk: 1, unknown: 2, suspicious: 3, likely_malicious: 4, confirmed_malicious: 5,
        };
        const nextVerdict: Verdict = rank[data.verdict] > rank[existing.verdict] ? data.verdict : existing.verdict;
        await supabaseAdmin
          .from("known_mods")
          .update({
            hit_count: (existing.hit_count ?? 0) + 1,
            last_seen: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            verdict: nextVerdict,
          })
          .eq("id", existing.id);
      } else {
        await supabaseAdmin.from("known_mods").insert({
          sha256: sha,
          name: data.fileName,
          verdict: data.verdict,
          game_id: data.gameId,
          source: data.source,
          notes: `Auto-classified from scanner (${data.source}).`,
        });
      }
    }

    return { ok: true };
  });

export const getDashboardStats = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();
  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

  const [eventsRes, knownRes, totalRes] = await Promise.all([
    sb.from("scan_events").select("verdict, game_id, created_at, severity_counts").gte("created_at", since),
    sb.from("known_mods").select("id", { count: "exact", head: true }),
    sb.from("scan_events").select("id", { count: "exact", head: true }),
  ]);

  const events = eventsRes.data ?? [];
  const malicious = events.filter((e) => MALICIOUS.includes(e.verdict as Verdict));

  // per-day per-verdict timeseries (7d)
  const days: { date: string; safe: number; suspicious: number; malicious: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86_400_000);
    days.push({ date: d.toISOString().slice(0, 10), safe: 0, suspicious: 0, malicious: 0 });
  }
  const idx = new Map(days.map((d, i) => [d.date, i]));
  for (const e of events) {
    const k = (e.created_at as string).slice(0, 10);
    const i = idx.get(k);
    if (i === undefined) continue;
    const v = e.verdict as Verdict;
    if (v === "safe" || v === "low_risk") days[i].safe++;
    else if (v === "suspicious") days[i].suspicious++;
    else if (v === "likely_malicious" || v === "confirmed_malicious") days[i].malicious++;
  }

  // per-game breakdown (7d)
  const perGame = new Map<string, { total: number; malicious: number }>();
  for (const e of events) {
    const row = perGame.get(e.game_id as string) ?? { total: 0, malicious: 0 };
    row.total++;
    if (MALICIOUS.includes(e.verdict as Verdict)) row.malicious++;
    perGame.set(e.game_id as string, row);
  }
  const games = Array.from(perGame.entries())
    .map(([game_id, v]) => ({ game_id, ...v }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 8);

  // verdict mix (7d)
  const mix = { safe: 0, suspicious: 0, likely_malicious: 0, confirmed_malicious: 0, low_risk: 0, unknown: 0 } as Record<Verdict, number>;
  for (const e of events) mix[e.verdict as Verdict]++;

  return {
    totalScansAllTime: totalRes.count ?? 0,
    knownMalwareCount: knownRes.count ?? 0,
    scans7d: events.length,
    blocked7d: malicious.length,
    days,
    games,
    mix,
  };
});

export const getRecentEvents = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => z.object({ limit: z.number().int().min(1).max(50).default(8) }).parse(input))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const { data: rows, error } = await sb
      .from("scan_events")
      .select("id, file_name, game_id, verdict, source, created_at, sha256")
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const lookupHash = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ sha256: z.string().length(64).regex(/^[a-f0-9]{64}$/i) }).parse(input))
  .handler(async ({ data }) => {
    const sb = publicClient();
    const hash = data.sha256.toLowerCase();
    const [knownRes, eventsRes] = await Promise.all([
      sb.from("known_mods").select("name, verdict, source, notes, hit_count, first_seen, last_seen, game_id").eq("sha256", hash).maybeSingle(),
      sb.from("scan_events").select("id", { count: "exact", head: true }).eq("sha256", hash),
    ]);
    return {
      sha256: hash,
      known: knownRes.data ?? null,
      sightings: eventsRes.count ?? 0,
    };
  });

export const getThreatLevel = createServerFn({ method: "GET" }).handler(async () => {
  const sb = publicClient();
  const sinceHour = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  const { data, error } = await sb
    .from("scan_events")
    .select("verdict")
    .gte("created_at", sinceHour);
  if (error) throw new Error(error.message);
  const rows = data ?? [];
  const total = rows.length;
  const malicious = rows.filter((r) => MALICIOUS.includes(r.verdict as Verdict)).length;
  const ratio = total > 0 ? malicious / total : 0;
  let level: "low" | "elevated" | "high" = "low";
  if (total >= 3 && ratio >= 0.5) level = "high";
  else if (total >= 1 && ratio >= 0.2) level = "elevated";
  return { level, total, malicious };
});