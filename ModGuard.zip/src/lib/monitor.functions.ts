import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type {
  MonitorProcess, MonitorConnection, ResourceSample,
  MonitorAlert, ConsentDiff, ProcessExplanation,
} from "./monitor-types";

// ── pairAgent ─────────────────────────────────────────────────────────────────
const PairAgentInput = z.object({
  label: z.string().min(1).max(128),
  hostname: z.string().max(256).optional(),
  os: z.string().max(64).optional(),
});

export const pairAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => PairAgentInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const secretBytes = new Uint8Array(32);
    crypto.getRandomValues(secretBytes);
    const secret = Array.from(secretBytes)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");

    // PBKDF2 hash of the secret for storage
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      "raw", enc.encode(secret), "PBKDF2", false, ["deriveBits"]
    );
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const derived = await crypto.subtle.deriveBits(
      { name: "PBKDF2", hash: "SHA-256", salt, iterations: 100_000 },
      keyMaterial, 256
    );
    const saltHex = Array.from(salt).map((b) => b.toString(16).padStart(2, "0")).join("");
    const derivedHex = Array.from(new Uint8Array(derived))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
    const secretHash = `pbkdf2:${saltHex}:${derivedHex}`;

    const { data: agent, error } = await supabaseAdmin
      .from("monitor_agents")
      .insert({
        user_id: context.userId,
        label: data.label,
        secret_hash: secretHash,
        hostname: data.hostname ?? null,
        os: data.os ?? null,
      })
      .select("id")
      .single();

    if (error || !agent) throw new Error(error?.message ?? "Failed to create agent");
    return { agentId: agent.id as string, secret };
  });

// ── getLiveProcesses ──────────────────────────────────────────────────────────
export const getLiveProcesses = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<MonitorProcess[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: snap } = await supabaseAdmin
      .from("monitor_snapshots")
      .select("id")
      .eq("user_id", context.userId)
      .order("taken_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!snap) return [];

    const { data: rows } = await supabaseAdmin
      .from("process_samples")
      .select("*")
      .eq("snapshot_id", snap.id)
      .order("cpu_pct", { ascending: false });

    return (rows ?? []).map((r) => ({
      pid: r.pid,
      name: r.name,
      modId: r.mod_id ?? null,
      gameId: r.game_id ?? null,
      cpuPct: Number(r.cpu_pct),
      memMb: Number(r.mem_mb),
      netInKbps: Number(r.net_in_kbps),
      netOutKbps: Number(r.net_out_kbps),
      startedAt: r.started_at ?? new Date().toISOString(),
      parentPid: r.parent_pid ?? null,
      cmdline: r.cmdline ?? undefined,
      risk: (r.risk as MonitorProcess["risk"]) ?? "low",
      persistsAfterClose: r.persists_after_close ?? false,
      abnormalResources: r.abnormal_resources ?? false,
    }));
  });

// ── getLiveConnections ────────────────────────────────────────────────────────
export const getLiveConnections = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<MonitorConnection[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: snap } = await supabaseAdmin
      .from("monitor_snapshots")
      .select("id")
      .eq("user_id", context.userId)
      .order("taken_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!snap) return [];

    const { data: rows } = await supabaseAdmin
      .from("network_samples")
      .select("*")
      .eq("snapshot_id", snap.id)
      .order("bytes_sent", { ascending: false });

    return (rows ?? []).map((r) => ({
      id: r.conn_id,
      pid: r.pid,
      processName: r.process_name,
      remoteHost: r.remote_host,
      remoteIp: r.remote_ip,
      remotePort: r.remote_port,
      bytesSent: Number(r.bytes_sent),
      bytesReceived: Number(r.bytes_received),
      requestCount: r.request_count,
      firstSeen: r.first_seen,
      lastSeen: r.last_seen,
      unknownDomain: r.unknown_domain,
    }));
  });

// ── getResourceSeries ─────────────────────────────────────────────────────────
const ResourceRangeInput = z.object({
  range: z.enum(["2m", "10m"]).default("2m"),
});

export const getResourceSeries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ResourceRangeInput.parse(input))
  .handler(async ({ data, context }): Promise<ResourceSample[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const minutes = data.range === "10m" ? 10 : 2;
    const since = new Date(Date.now() - minutes * 60 * 1000).toISOString();

    const { data: snaps } = await supabaseAdmin
      .from("monitor_snapshots")
      .select("id, taken_at")
      .eq("user_id", context.userId)
      .gte("taken_at", since)
      .order("taken_at", { ascending: true })
      .limit(60);

    if (!snaps?.length) return [];

    const snapIds = snaps.map((s) => s.id);
    const { data: rows } = await supabaseAdmin
      .from("process_samples")
      .select("snapshot_id, cpu_pct, mem_mb")
      .in("snapshot_id", snapIds);

    const bySnap = new Map<string, { cpuPct: number; memMb: number; count: number }>();
    for (const r of rows ?? []) {
      const cur = bySnap.get(r.snapshot_id) ?? { cpuPct: 0, memMb: 0, count: 0 };
      bySnap.set(r.snapshot_id, {
        cpuPct: cur.cpuPct + Number(r.cpu_pct),
        memMb: cur.memMb + Number(r.mem_mb),
        count: cur.count + 1,
      });
    }

    return snaps.map((s) => {
      const agg = bySnap.get(s.id);
      return {
        t: s.taken_at,
        cpuPct: agg ? Math.min(100, agg.cpuPct) : 0,
        gpuPct: 0,
        memPct: agg && agg.count > 0
          ? Math.round((agg.memMb / agg.count / 32768) * 100)
          : 0,
      };
    });
  });

// ── getOpenAlerts ─────────────────────────────────────────────────────────────
export const getOpenAlerts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<MonitorAlert[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: rows } = await supabaseAdmin
      .from("monitor_alerts")
      .select("*")
      .eq("user_id", context.userId)
      .is("resolved_at", null)
      .order("created_at", { ascending: false })
      .limit(50);

    return (rows ?? []).map((r) => ({
      id: r.id,
      kind: r.kind as MonitorAlert["kind"],
      severity: r.severity as MonitorAlert["severity"],
      title: r.title,
      message: r.message,
      pid: r.pid ?? undefined,
      processName: r.process_name ?? undefined,
      remoteHost: r.remote_host ?? undefined,
      createdAt: r.created_at,
    }));
  });

// ── getConsentDiff ────────────────────────────────────────────────────────────
export const getConsentDiff = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<ConsentDiff[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: snap } = await supabaseAdmin
      .from("monitor_snapshots")
      .select("id")
      .eq("user_id", context.userId)
      .order("taken_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!snap) return [];

    const { data: rows } = await supabaseAdmin
      .from("consent_violations")
      .select("*")
      .eq("snapshot_id", snap.id);

    const byMod = new Map<string, ConsentDiff>();
    for (const r of rows ?? []) {
      if (!byMod.has(r.mod_id)) {
        byMod.set(r.mod_id, {
          modId: r.mod_id,
          modName: r.mod_name,
          claims: [],
          mismatches: [],
        });
      }
      const diff = byMod.get(r.mod_id)!;
      const claim = {
        capability: r.capability,
        declared: r.declared,
        observed: r.observed,
        detail: r.detail ?? undefined,
      };
      diff.claims.push(claim);
      if (r.declared !== r.observed) diff.mismatches.push(claim);
    }

    return Array.from(byMod.values());
  });

// ── explainProcess ────────────────────────────────────────────────────────────
const ExplainInput = z.object({ pid: z.number().int().positive() });

export const explainProcess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ExplainInput.parse(input))
  .handler(async ({ data, context }): Promise<ProcessExplanation> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Latest snapshot for this user
    const { data: snap } = await supabaseAdmin
      .from("monitor_snapshots")
      .select("id")
      .eq("user_id", context.userId)
      .order("taken_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!snap) throw new Error("No snapshot found");

    const { data: proc } = await supabaseAdmin
      .from("process_samples")
      .select("*")
      .eq("snapshot_id", snap.id)
      .eq("pid", data.pid)
      .order("sampled_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!proc) throw new Error(`No process sample found for PID ${data.pid}`);

    const { data: conns } = await supabaseAdmin
      .from("network_samples")
      .select("*")
      .eq("snapshot_id", snap.id)
      .eq("pid", data.pid);

    const { data: violations } = proc.mod_id
      ? await supabaseAdmin
          .from("consent_violations")
          .select("*")
          .eq("snapshot_id", snap.id)
          .eq("mod_id", proc.mod_id)
      : { data: [] };

    const payload = {
      process: {
        pid: proc.pid,
        name: proc.name,
        cmdline: proc.cmdline,
        cpuPct: proc.cpu_pct,
        memMb: proc.mem_mb,
        netOutKbps: proc.net_out_kbps,
        persistsAfterClose: proc.persists_after_close,
        abnormalResources: proc.abnormal_resources,
        modId: proc.mod_id,
        gameId: proc.game_id,
      },
      connections: (conns ?? []).map((c) => ({
        remoteHost: c.remote_host,
        remotePort: c.remote_port,
        bytesSent: c.bytes_sent,
        unknownDomain: c.unknown_domain,
      })),
      consentViolations: (violations ?? []).map((v) => ({
        capability: v.capability,
        declared: v.declared,
        observed: v.observed,
        detail: v.detail,
      })),
    };

    // Call Claude via Lovable AI Gateway
    const { createLovableAiGatewayProvider } = await import("./ai-gateway.server");
    const { generateObject } = await import("ai");
    const { z: zod } = await import("zod");

    const provider = createLovableAiGatewayProvider(process.env.LOVABLE_API_KEY!);
    const model = provider("anthropic/claude-sonnet-4-6");

    const ExplanationSchema = zod.object({
      risk: zod.enum(["low", "medium", "high", "suspicious"]),
      summary: zod.string(),
      reasons: zod.array(zod.string()).min(1).max(5),
      recommendedAction: zod.enum(["allow", "monitor", "kill", "uninstall"]),
    });

    const { object } = await generateObject({
      model,
      schema: ExplanationSchema,
      system: `You are ModGuard's security analyst. Given a process running on a gamer's machine alongside a game mod, plus its network connections and any consent violations, produce a plain-English risk assessment.

Be direct and non-technical. The user is a gamer, not a security expert.
Focus on what the process is doing that the user never consented to.
Risk levels: low = normal game behavior, medium = worth watching, high = likely malicious, suspicious = confirmed attack pattern.
Recommended actions: allow = safe, monitor = watch it, kill = terminate now, uninstall = remove the mod immediately.`,
      prompt: `Analyze this background process:\n\n${JSON.stringify(payload, null, 2)}`,
    });

    return {
      pid: data.pid,
      risk: object.risk,
      summary: object.summary,
      reasons: object.reasons,
      recommendedAction: object.recommendedAction,
    };
  });
