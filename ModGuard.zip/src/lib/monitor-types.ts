// Shared contract between the Process Monitor frontend (Lovable) and the
// companion-agent backend (Claude). Treat this as the single source of truth —
// any backend payload MUST conform to these types.

export type RiskLabel = "low" | "medium" | "high" | "suspicious";

export type MonitorProcess = {
  pid: number;
  name: string;          // e.g. "javaw.exe", "RobloxPlayerBeta.exe"
  modId?: string | null; // FK to known_mods.id when attributable
  gameId?: string | null;
  cpuPct: number;        // 0..100, single-core normalized * 100
  memMb: number;         // resident MB
  netInKbps: number;
  netOutKbps: number;
  startedAt: string;     // ISO
  parentPid?: number | null;
  cmdline?: string;
  risk: RiskLabel;
  // Set true when the parent game/mod has exited but this process is still alive.
  persistsAfterClose?: boolean;
  // True when CPU or memory deviates >3σ from the baseline for this process name.
  abnormalResources?: boolean;
};

export type MonitorConnection = {
  id: string;            // stable hash of (pid, remoteHost, remotePort)
  pid: number;
  processName: string;
  remoteHost: string;    // domain when resolvable, else IP
  remoteIp: string;
  remotePort: number;
  bytesSent: number;
  bytesReceived: number;
  requestCount: number;
  firstSeen: string;     // ISO
  lastSeen: string;      // ISO
  // Backend sets this to true if remoteHost is not on a known-good allowlist
  // for the attributed mod/game.
  unknownDomain: boolean;
};

export type ResourceSample = {
  t: string;             // ISO timestamp
  cpuPct: number;        // overall CPU 0..100
  gpuPct: number;        // overall GPU 0..100 (0 if unavailable)
  memPct: number;        // overall mem 0..100
};

export type ConsentClaim = {
  capability: string;            // "network.outbound", "fs.write", "process.spawn", ...
  declared: boolean;             // mod manifest declares this capability
  observed: boolean;             // actually observed at runtime
  detail?: string;
};

export type ConsentDiff = {
  modId: string;
  modName: string;
  claims: ConsentClaim[];
  // Convenience: any claim where declared !== observed (typically observed && !declared).
  mismatches: ConsentClaim[];
};

export type ProcessExplanation = {
  pid: number;
  risk: RiskLabel;
  summary: string;           // plain-English, one paragraph
  reasons: string[];         // bullet points
  recommendedAction?: "allow" | "monitor" | "kill" | "uninstall";
};

export type MonitorAlert = {
  id: string;
  kind: "persistence" | "unknown_domain" | "abnormal_resources";
  severity: "info" | "warning" | "critical";
  title: string;
  message: string;
  pid?: number;
  processName?: string;
  remoteHost?: string;
  createdAt: string;
};

export type MonitorSnapshot = {
  takenAt: string;
  processes: MonitorProcess[];
  connections: MonitorConnection[];
  resources: ResourceSample[];   // most recent 60 samples (~2 minutes at 2s cadence)
  alerts: MonitorAlert[];
  consent: ConsentDiff[];
};