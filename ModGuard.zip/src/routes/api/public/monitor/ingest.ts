// POST /api/public/monitor/ingest
// Receives signed snapshots from the companion agent. HMAC-gated, no session required.
// user_id is ALWAYS derived from the verified agent_id — never trusted from the payload.

import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const TRUSTED_DOMAINS = new Set([
  "minecraft.net","session.minecraft.net","api.modrinth.com",
  "media.forgecdn.net","edge.forgecdn.net","modrinth.com",
  "roblox.com","presence.roblox.com","auth.roblox.com","rbxcdn.com",
  "curseforge.com","api.curseforge.com","forgecdn.net",
  "steampowered.com","steamcommunity.com","valve.net","steam-chat.com",
  "twitch.tv","discord.com","discordapp.com",
]);

const ProcessSchema = z.object({
  pid: z.number().int(),
  name: z.string().max(256),
  modId: z.string().max(128).nullable().optional(),
  gameId: z.string().max(64).nullable().optional(),
  cpuPct: z.number().min(0).max(100),
  memMb: z.number().min(0),
  netInKbps: z.number().min(0).default(0),
  netOutKbps: z.number().min(0).default(0),
  startedAt: z.string().datetime().optional(),
  parentPid: z.number().int().nullable().optional(),
  cmdline: z.string().max(2048).optional(),
  risk: z.enum(["low","medium","high","suspicious"]).default("low"),
  persistsAfterClose: z.boolean().default(false),
  abnormalResources: z.boolean().default(false),
});

const ConnectionSchema = z.object({
  id: z.string().max(128),
  pid: z.number().int(),
  processName: z.string().max(256),
  remoteHost: z.string().max(253),
  remoteIp: z.string().max(45),
  remotePort: z.number().int().min(1).max(65535),
  bytesSent: z.number().min(0).default(0),
  bytesReceived: z.number().min(0).default(0),
  requestCount: z.number().int().min(0).default(0),
  firstSeen: z.string().datetime(),
  lastSeen: z.string().datetime(),
  unknownDomain: z.boolean().default(false),
});

const ResourceSampleSchema = z.object({
  t: z.string().datetime(),
  cpuPct: z.number().min(0).max(100),
  gpuPct: z.number().min(0).max(100).default(0),
  memPct: z.number().min(0).max(100),
});

const ConsentClaimSchema = z.object({
  capability: z.string().max(64),
  declared: z.boolean(),
  observed: z.boolean(),
  detail: z.string().max(512).optional(),
});

const ConsentDiffSchema = z.object({
  modId: z.string().max(128),
  modName: z.string().max(256),
  claims: z.array(ConsentClaimSchema),
  mismatches: z.array(ConsentClaimSchema),
});

const SnapshotPayload = z.object({
  agentId: z.string().uuid(),
  takenAt: z.string().datetime(),
  processes: z.array(ProcessSchema).max(500),
  connections: z.array(ConnectionSchema).max(1000),
  resources: z.array(ResourceSampleSchema).max(60),
  consent: z.array(ConsentDiffSchema).max(100),
});

async function verifyHmac(body: string, sigHeader: string, secret: string): Promise<boolean> {
  try {
    const parts = Object.fromEntries(sigHeader.split(",").map((p: string) => p.split("=")));
    const t = parseInt(parts["t"] ?? "0", 10);
    const v1 = parts["v1"] ?? "";
    if (!t || !v1) return false;
    if (Math.abs(Date.now() / 1000 - t) > 300) return false;

    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]
    );
    const sigBytes = new Uint8Array(v1.match(/.{2}/g)!.map((h: string) => parseInt(h, 16)));
    const msg = enc.encode(`${t}.${body}`);
    return await crypto.subtle.verify("HMAC", key, sigBytes, msg);
  } catch {
    return false;
  }
}

function isUnknownDomain(host: string): boolean {
  const h = host.toLowerCase().replace(/^www\./, "");
  if (TRUSTED_DOMAINS.has(h)) return false;
  for (const d of TRUSTED_DOMAINS) {
    if (h.endsWith(`.${d}`)) return false;
  }
  return true;
}

async function runAlertEngine(
  supabaseAdmin: ReturnType<typeof import("@/integrations/supabase/client.server")["supabaseAdmin"]["from"]> extends never ? never : Awaited<typeof import("@/integrations/supabase/client.server")>["supabaseAdmin"],
  userId: string,
  payload: z.infer<typeof SnapshotPayload>,
) {
  const alerts: Array<{
    user_id: string; kind: string; severity: string;
    title: string; message: string;
    pid?: number; process_name?: string; remote_host?: string;
    target_key: string;
  }> = [];

  for (const proc of payload.processes) {
    if (proc.persistsAfterClose) {
      alerts.push({
        user_id: userId, kind: "persistence", severity: "critical",
        title: "Process persists after game closed",
        message: `${proc.name} (PID ${proc.pid}) is still running after the game exited.`,
        pid: proc.pid, process_name: proc.name,
        target_key: `persistence:${proc.pid}:${proc.name}`,
      });
    }
  }

  for (const conn of payload.connections) {
    if (isUnknownDomain(conn.remoteHost)) {
      alerts.push({
        user_id: userId, kind: "unknown_domain", severity: "warning",
        title: "Outbound traffic to unrecognized domain",
        message: `${conn.processName} (PID ${conn.pid}) is sending data to ${conn.remoteHost} — not on any known-safe allowlist.`,
        pid: conn.pid, process_name: conn.processName, remote_host: conn.remoteHost,
        target_key: `unknown_domain:${conn.pid}:${conn.remoteHost}`,
      });
    }
  }

  for (const proc of payload.processes) {
    if (proc.abnormalResources) {
      alerts.push({
        user_id: userId, kind: "abnormal_resources", severity: "warning",
        title: "Abnormal resource usage detected",
        message: `${proc.name} (PID ${proc.pid}) is using ${proc.cpuPct.toFixed(1)}% CPU — well above its normal baseline.`,
        pid: proc.pid, process_name: proc.name,
        target_key: `abnormal_resources:${proc.name}`,
      });
    }
  }

  if (!alerts.length) return;

  const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const { data: existing } = await (supabaseAdmin as Awaited<typeof import("@/integrations/supabase/client.server")>["supabaseAdmin"])
    .from("monitor_alerts")
    .select("kind, target_key")
    .eq("user_id", userId)
    .is("resolved_at", null)
    .gte("created_at", cutoff);

  const existingKeys = new Set(
    (existing ?? []).map((r: { kind: string; target_key: string }) => `${r.kind}:${r.target_key}`)
  );
  const toInsert = alerts.filter((a) => !existingKeys.has(`${a.kind}:${a.target_key}`));
  if (toInsert.length) {
    await (supabaseAdmin as Awaited<typeof import("@/integrations/supabase/client.server")>["supabaseAdmin"])
      .from("monitor_alerts").insert(toInsert);
  }
}

async function updateBaselines(
  supabaseAdmin: Awaited<typeof import("@/integrations/supabase/client.server")>["supabaseAdmin"],
  userId: string,
  processes: z.infer<typeof ProcessSchema>[],
) {
  for (const proc of processes) {
    const { data: existing } = await supabaseAdmin
      .from("process_baselines")
      .select("*")
      .eq("user_id", userId)
      .eq("process_name", proc.name)
      .maybeSingle();

    if (!existing) {
      await supabaseAdmin.from("process_baselines").insert({
        user_id: userId, process_name: proc.name,
        sample_count: 1, cpu_mean: proc.cpuPct, cpu_stddev: 0,
        mem_mean: proc.memMb, mem_stddev: 0,
      });
    } else {
      const n = existing.sample_count + 1;
      const cpuDelta = proc.cpuPct - Number(existing.cpu_mean);
      const cpuMean = Number(existing.cpu_mean) + cpuDelta / n;
      const memDelta = proc.memMb - Number(existing.mem_mean);
      const memMean = Number(existing.mem_mean) + memDelta / n;
      await supabaseAdmin
        .from("process_baselines")
        .update({
          sample_count: n,
          cpu_mean: cpuMean,
          cpu_stddev: Math.sqrt(
            (Math.pow(Number(existing.cpu_stddev), 2) * (n - 2) +
              Math.pow(proc.cpuPct - cpuMean, 2)) / Math.max(1, n - 1)
          ),
          mem_mean: memMean,
          mem_stddev: Math.sqrt(
            (Math.pow(Number(existing.mem_stddev), 2) * (n - 2) +
              Math.pow(proc.memMb - memMean, 2)) / Math.max(1, n - 1)
          ),
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", userId)
        .eq("process_name", proc.name);
    }
  }
}

export const Route = createFileRoute("/api/public/monitor/ingest")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
    const body = await request.text();

    let payload: z.infer<typeof SnapshotPayload>;
    try {
      payload = SnapshotPayload.parse(JSON.parse(body));
    } catch {
      return Response.json({ error: "Invalid payload" }, { status: 400 });
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: agent } = await supabaseAdmin
      .from("monitor_agents")
      .select("id, user_id, secret_hash")
      .eq("id", payload.agentId)
      .maybeSingle();

    if (!agent) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const sigHeader = request.headers.get("x-monitor-sig") ?? "";
    const hmacKey = process.env.MONITOR_AGENT_HMAC_KEY ?? agent.secret_hash;
    const validSig = await verifyHmac(body, sigHeader, hmacKey);
    if (!validSig) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const userId = agent.user_id;

    const { data: snapshot } = await supabaseAdmin
      .from("monitor_snapshots")
      .insert({ agent_id: agent.id, user_id: userId, taken_at: payload.takenAt })
      .select("id")
      .single();

    if (!snapshot) return Response.json({ error: "Failed to store snapshot" }, { status: 500 });

    const snapshotId = snapshot.id;

    if (payload.processes.length) {
      await supabaseAdmin.from("process_samples").insert(
        payload.processes.map((p) => ({
          snapshot_id: snapshotId, user_id: userId,
          pid: p.pid, name: p.name,
          mod_id: p.modId ?? null, game_id: p.gameId ?? null,
          cpu_pct: p.cpuPct, mem_mb: p.memMb,
          net_in_kbps: p.netInKbps ?? 0, net_out_kbps: p.netOutKbps ?? 0,
          started_at: p.startedAt ?? null, parent_pid: p.parentPid ?? null,
          cmdline: p.cmdline ?? null, risk: p.risk ?? "low",
          persists_after_close: p.persistsAfterClose ?? false,
          abnormal_resources: p.abnormalResources ?? false,
        }))
      );
    }

    const enrichedConns = payload.connections.map((c) => ({
      ...c, unknownDomain: isUnknownDomain(c.remoteHost),
    }));

    if (enrichedConns.length) {
      await supabaseAdmin.from("network_samples").insert(
        enrichedConns.map((c) => ({
          snapshot_id: snapshotId, user_id: userId,
          conn_id: c.id, pid: c.pid, process_name: c.processName,
          remote_host: c.remoteHost, remote_ip: c.remoteIp, remote_port: c.remotePort,
          bytes_sent: c.bytesSent, bytes_received: c.bytesReceived,
          request_count: c.requestCount, first_seen: c.firstSeen, last_seen: c.lastSeen,
          unknown_domain: c.unknownDomain,
        }))
      );
    }

    const violations = payload.consent.flatMap((diff) =>
      diff.claims
        .filter((c) => c.declared !== c.observed)
        .map((c) => ({
          snapshot_id: snapshotId, user_id: userId,
          mod_id: diff.modId, mod_name: diff.modName,
          capability: c.capability, declared: c.declared,
          observed: c.observed, detail: c.detail ?? null,
        }))
    );
    if (violations.length) {
      await supabaseAdmin.from("consent_violations").insert(violations);
    }

    await supabaseAdmin
      .from("monitor_agents")
      .update({ last_seen_at: new Date().toISOString() })
      .eq("id", agent.id);

    await Promise.allSettled([
      runAlertEngine(supabaseAdmin as never, userId, payload),
      updateBaselines(supabaseAdmin, userId, payload.processes),
    ]);

    return Response.json({ ok: true, snapshotId }, { status: 200 });
  },
      },
    },
});
