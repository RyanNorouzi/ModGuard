import { createFileRoute } from "@tanstack/react-router";
import { getConsentDiff } from "@/lib/monitor.functions";

export const Route = createFileRoute("/api/monitor/consent")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const data = await getConsentDiff();
          return Response.json(data);
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Internal error";
          return Response.json({ error: msg }, { status: msg.includes("Unauthorized") ? 401 : 500 });
        }
      },
    },
  },
});