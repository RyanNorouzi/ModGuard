import { createFileRoute } from "@tanstack/react-router";
import { getResourceSeries } from "@/lib/monitor.functions";

export const Route = createFileRoute("/api/monitor/resources")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const url = new URL(request.url);
          const range = (url.searchParams.get("range") === "10m" ? "10m" : "2m") as "2m" | "10m";
          const data = await getResourceSeries({ data: { range } });
          return Response.json(data);
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Internal error";
          return Response.json({ error: msg }, { status: msg.includes("Unauthorized") ? 401 : 500 });
        }
      },
    },
  },
});