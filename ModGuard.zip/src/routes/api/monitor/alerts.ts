import { createFileRoute } from "@tanstack/react-router";
import { getOpenAlerts } from "@/lib/monitor.functions";

export const Route = createFileRoute("/api/monitor/alerts")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const data = await getOpenAlerts();
          return Response.json(data);
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Internal error";
          return Response.json({ error: msg }, { status: msg.includes("Unauthorized") ? 401 : 500 });
        }
      },
    },
  },
});