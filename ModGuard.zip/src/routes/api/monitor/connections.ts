import { createFileRoute } from "@tanstack/react-router";
import { getLiveConnections } from "@/lib/monitor.functions";

export const Route = createFileRoute("/api/monitor/connections")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const data = await getLiveConnections();
          return Response.json(data);
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Internal error";
          return Response.json({ error: msg }, { status: msg.includes("Unauthorized") ? 401 : 500 });
        }
      },
    },
  },
});