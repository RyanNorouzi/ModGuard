import { createFileRoute } from "@tanstack/react-router";
import { explainProcess } from "@/lib/monitor.functions";

export const Route = createFileRoute("/api/monitor/explain")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = (await request.json().catch(() => null)) as { pid?: number } | null;
          if (!body || typeof body.pid !== "number") {
            return Response.json({ error: "Body must include { pid: number }" }, { status: 400 });
          }
          const data = await explainProcess({ data: { pid: body.pid } });
          return Response.json(data);
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Internal error";
          if (msg.includes("Unauthorized")) return Response.json({ error: msg }, { status: 401 });
          if (msg.includes("No process") || msg.includes("No snapshot")) return Response.json({ error: msg }, { status: 404 });
          return Response.json({ error: msg }, { status: 500 });
        }
      },
    },
  },
});