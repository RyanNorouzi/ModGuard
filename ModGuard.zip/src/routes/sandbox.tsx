import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  ArrowLeft, FlaskConical, Upload, Loader2, Play, RotateCcw,
  HardDrive, Globe, Cpu, KeyRound, FileCode, AlertTriangle,
  CheckCircle2, ShieldAlert, Terminal, FileText, Download,
  Target, ServerCrash,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { generateIncidentReport } from "@/lib/incident-report.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/sandbox")({
  head: () => ({
    meta: [
      { title: "Mod Sandbox — ModGuard" },
      { name: "description", content: "Simulate running a mod in an isolated sandbox and watch what it actually tries to do." },
    ],
  }),
  component: SandboxPage,
});

type Severity = "info" | "ok" | "warn" | "bad" | "crit";
type Event = {
  t: number; // ms from start
  kind: "fs" | "net" | "proc" | "reg" | "code" | "system";
  severity: Severity;
  title: string;
  detail: string;
};

const KIND_META: Record<Event["kind"], { icon: any; label: string }> = {
  fs: { icon: HardDrive, label: "Filesystem" },
  net: { icon: Globe, label: "Network" },
  proc: { icon: Cpu, label: "Process" },
  reg: { icon: KeyRound, label: "Registry" },
  code: { icon: FileCode, label: "Code" },
  system: { icon: Terminal, label: "System" },
};

function sevClass(s: Severity) {
  switch (s) {
    case "ok": return "text-emerald-700 bg-emerald-50 border-emerald-200 dark:text-emerald-300 dark:bg-emerald-500/10 dark:border-emerald-500/30";
    case "info": return "text-sky-700 bg-sky-50 border-sky-200 dark:text-sky-300 dark:bg-sky-500/10 dark:border-sky-500/30";
    case "warn": return "text-amber-800 bg-amber-50 border-amber-200 dark:text-amber-300 dark:bg-amber-500/10 dark:border-amber-500/30";
    case "bad": return "text-orange-800 bg-orange-50 border-orange-300 dark:text-orange-300 dark:bg-orange-500/10 dark:border-orange-500/30";
    case "crit": return "text-red-800 bg-red-50 border-red-300 dark:text-red-300 dark:bg-red-500/10 dark:border-red-500/30";
  }
}

// Heuristic "sandbox" — generates a plausible behavior trace from the filename + extension.
// This is a simulation for demo/education; it does NOT execute the file.
function simulate(file: File): Event[] {
  const name = file.name.toLowerCase();
  const ext = "." + (name.split(".").pop() ?? "");
  const size = file.size;
  const ev: Event[] = [];
  const push = (t: number, kind: Event["kind"], severity: Severity, title: string, detail: string) =>
    ev.push({ t, kind, severity, title, detail });

  push(0, "system", "info", "Sandbox booted", `Isolated VM started. Loaded ${file.name} (${(size / 1024).toFixed(1)} KB).`);
  push(150, "fs", "info", "File extracted", `Unpacked into /sandbox/work/${file.name}`);

  const sus = /(crack|keygen|free|hack|cheat|loader|stealer|inject|nitro|robux|vbucks|exec)/.test(name);
  const archive = /\.(zip|7z|rar)$/.test(name);
  const native = /\.(exe|dll|asi)$/.test(ext);
  const script = /\.(lua|py|ts4script|js|ps1|bat|sh)$/.test(ext);
  const jvm = /\.jar$/.test(ext);
  const minecraft = jvm || /\.(mcmeta|mcpack|mcaddon)$/.test(ext) || /(forge|fabric|mcmod|minecraft|mc-|_mc)/.test(name);
  const chatExploit = /(pay|autopay|tpa|grief|dupe|xray|killaura|autotype|chatspam|scam)/.test(name);

  if (archive) {
    push(400, "fs", "warn", "Archive contains executable", "Found bundled .exe inside archive — common dropper pattern.");
  }
  if (jvm) {
    push(500, "code", "info", "JAR manifest read", "Main-Class located. Bytecode scanning…");
    push(900, "net", sus ? "crit" : "ok", sus ? "Outbound to suspicious host" : "Outbound to mod CDN",
      sus ? "POST https://discord-app-cdn.click/api/upload (auth cookie)" : "GET https://media.forgecdn.net/files/…");
  }
  if (minecraft) {
    push(750, "code", "info", "Minecraft mod loaded", "Detected Forge/Fabric entrypoint. Hooking ClientPlayerEntity events.");
    push(1050, "code", "warn", "Subscribes to ClientTickEvent / ServerJoin", "Mod listens for the moment the player joins a server.");
    if (chatExploit || sus) {
      push(1300, "code", "crit", "Injects chat command on server join",
        "Calls Minecraft.getInstance().player.connection.sendChat(\"/pay ryrythebro 9999\") right after ServerJoinEvent.");
      push(1450, "net", "bad", "Outbound to hardcoded webhook",
        "POST https://discord.com/api/webhooks/… with player username + server IP.");
      push(1600, "system", "crit", "Auto-payment behavior",
        "Mod transfers in-game currency to a hardcoded account with no user prompt.");
    } else {
      push(1300, "code", "ok", "No chat injection observed", "Mod did not call sendChat / sendCommand during the run.");
    }
  }
  if (native) {
    push(600, "code", "warn", "Native binary loaded", "PE/ELF image mapped into memory. Imports: WinINet, AdvApi32.");
    push(1200, "reg", "bad", "Autostart key written", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run added.");
    push(1500, "proc", "crit", "Spawned hidden PowerShell", "powershell.exe -nop -w hidden -enc <base64>");
  }
  if (script) {
    push(700, "code", "warn", "Script reads env vars", "Accessed APPDATA, LOCALAPPDATA, USERPROFILE.");
    push(1100, "net", "bad", "Exfil attempt", "POST 12.4 MB to https://transfer.sh/anon");
  }
  if (sus) {
    push(1700, "fs", "crit", "Reads browser data", "Opened …\\Chrome\\User Data\\Default\\Login Data");
    push(2000, "net", "crit", "Beacon to off-allowlist host", "TLS to free-robux-gen.xyz:443");
  }
  if (!sus && !native && !script && !jvm) {
    push(800, "fs", "ok", "Reads game directory only", "Stayed within the game's mod folder. No network activity.");
    push(1400, "system", "ok", "Clean exit", "Process exited 0. No persistence, no exfil.");
  } else {
    push(2400, "system", sus || native ? "crit" : "warn", "Sandbox verdict",
      sus || native ? "Behaves like a credential stealer." : "Did things its manifest did not declare.");
  }
  return ev.sort((a, b) => a.t - b.t);
}

function verdictFor(events: Event[]) {
  if (events.some((e) => e.severity === "crit")) return { label: "Malicious", tone: "bg-red-600 text-white" };
  if (events.some((e) => e.severity === "bad")) return { label: "High Risk", tone: "bg-orange-500 text-white" };
  if (events.some((e) => e.severity === "warn")) return { label: "Suspicious", tone: "bg-amber-500 text-black" };
  return { label: "Looks Safe", tone: "bg-emerald-600 text-white" };
}

function SandboxPage() {
  const [file, setFile] = useState<File | null>(null);
  const [running, setRunning] = useState(false);
  const [shown, setShown] = useState<Event[]>([]);
  const events = useMemo(() => (file ? simulate(file) : []), [file]);

  const run = useCallback(() => {
    if (!file || running) return;
    setShown([]);
    setRunning(true);
    const evs = simulate(file);
    let i = 0;
    const tick = () => {
      if (i >= evs.length) { setRunning(false); return; }
      setShown((prev) => [...prev, evs[i]]);
      i++;
      setTimeout(tick, 350 + Math.random() * 250);
    };
    tick();
  }, [file, running]);

  const reset = () => { setShown([]); setRunning(false); };

  const verdict = shown.length === events.length && events.length > 0 ? verdictFor(shown) : null;

  const [report, setReport] = useState<string>("");
  const [purpose, setPurpose] = useState<string>("");
  const [suspiciousBackends, setSuspiciousBackends] = useState<Array<{ host: string; why: string }>>([]);
  const [reportLoading, setReportLoading] = useState(false);
  const genReport = useServerFn(generateIncidentReport);

  const buildReport = async () => {
    if (!file || !verdict || reportLoading) return;
    setReportLoading(true);
    setReport("");
    setPurpose("");
    setSuspiciousBackends([]);
    try {
      const res = await genReport({
        data: {
          fileName: file.name,
          fileSize: file.size,
          verdict: verdict.label,
          events: shown.map((e) => ({
            t: e.t, kind: e.kind, severity: e.severity, title: e.title, detail: e.detail,
          })),
        },
      });
      setReport(res.report);
      setPurpose(res.purpose ?? "");
      setSuspiciousBackends(res.suspiciousBackends ?? []);
      toast.success("Incident report generated");
    } catch (err: any) {
      toast.error(err?.message ?? "Failed to generate report");
    } finally {
      setReportLoading(false);
    }
  };

  const downloadReport = () => {
    if (!report || !file) return;
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const safeName = file.name.replace(/[^a-z0-9.-]/gi, "_");
    const blob = new Blob([report], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ModGuard-Incident-${safeName}-${stamp}.md`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-border bg-background/75 px-4 backdrop-blur-md">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-5 w-5" /> Back
        </Link>
        <div className="h-5 w-px bg-border" />
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground shadow-sm">
          <FlaskConical className="h-4.5 w-4.5" strokeWidth={2.5} />
        </span>
        <span className="font-display text-lg font-bold tracking-tight">Mod Sandbox</span>
        <span className="ml-2 rounded-full border border-amber-400/60 bg-amber-500/15 px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest text-amber-700 dark:text-amber-300">Simulation</span>
      </header>

      <main className="mx-auto w-full max-w-5xl px-5 py-8">
        <div className="mb-6">
          <h1 className="font-display text-2xl font-bold tracking-tight">Test a mod in an isolated sandbox</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Drop a mod file and watch a simulated trace of what it would do at runtime — filesystem, network, processes, registry.
            Nothing is actually executed on your machine.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-[1fr,1.4fr]">
          {/* Left: file picker */}
          <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
            <label
              htmlFor="sb-file"
              className="flex h-48 cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-background/50 px-4 text-center hover:bg-accent"
            >
              <Upload className="h-7 w-7 text-muted-foreground" />
              <div className="text-sm font-medium">{file ? file.name : "Drop a mod file"}</div>
              <div className="text-xs text-muted-foreground">
                {file ? `${(file.size / 1024).toFixed(1)} KB` : ".jar · .dll · .exe · .lua · .ts4script · .zip"}
              </div>
            </label>
            <input
              id="sb-file"
              type="file"
              className="hidden"
              onChange={(e) => { const f = e.target.files?.[0] ?? null; setFile(f); setShown([]); }}
            />
            <div className="mt-4 flex gap-2">
              <Button onClick={run} disabled={!file || running} className="flex-1">
                {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                {running ? "Running…" : "Run in sandbox"}
              </Button>
              <Button variant="outline" onClick={reset} disabled={running}>
                <RotateCcw className="h-4 w-4" /> Reset
              </Button>
            </div>
            <div className="mt-4 rounded-lg border border-border bg-background/50 p-3 text-xs text-muted-foreground">
              <div className="mb-1 font-semibold text-foreground">How it works</div>
              Behavior is inferred from filename, extension, and size using known mod-malware patterns.
              For full dynamic analysis, connect the ModGuard agent on the <Link to="/monitor" className="underline">Monitor</Link> page.
            </div>
          </div>

          {/* Right: trace */}
          <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4 text-muted-foreground" />
                <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                  Behavior Trace
                </h2>
              </div>
              {verdict && (
                <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${verdict.tone}`}>
                  {verdict.label === "Looks Safe" ? <CheckCircle2 className="h-4 w-4" /> : <ShieldAlert className="h-4 w-4" />}
                  {verdict.label}
                </span>
              )}
            </div>

            {shown.length === 0 ? (
              <div className="flex h-64 items-center justify-center text-sm text-muted-foreground">
                {file ? "Click \"Run in sandbox\" to start." : "Pick a file to begin."}
              </div>
            ) : (
              <ol className="space-y-2">
                {shown.map((e, i) => {
                  const Icon = KIND_META[e.kind].icon;
                  return (
                    <li
                      key={i}
                      className={`flex items-start gap-3 rounded-lg border p-3 text-sm ${sevClass(e.severity)}`}
                    >
                      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{e.title}</span>
                          <span className="ml-auto font-mono text-[10px] opacity-70">
                            +{(e.t / 1000).toFixed(2)}s · {KIND_META[e.kind].label}
                          </span>
                        </div>
                        <div className="mt-0.5 break-words font-mono text-xs opacity-90">{e.detail}</div>
                      </div>
                      {(e.severity === "crit" || e.severity === "bad") && (
                        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                      )}
                    </li>
                  );
                })}
                {running && (
                  <li className="flex items-center gap-2 px-3 py-2 text-xs text-muted-foreground">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" /> Capturing more activity…
                  </li>
                )}
              </ol>
            )}
          </div>
        </div>

        {verdict && (
          <div className="mt-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                Incident Report
              </h2>
              <span className="rounded-full border border-border bg-background px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                Hackathon-ready
              </span>
              <div className="ml-auto flex gap-2">
                <Button size="sm" onClick={buildReport} disabled={reportLoading}>
                  {reportLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
                  {report ? "Regenerate" : "Generate report"}
                </Button>
                <Button size="sm" variant="outline" onClick={downloadReport} disabled={!report}>
                  <Download className="h-4 w-4" /> Download .md
                </Button>
              </div>
            </div>
            {report ? (
              <div className="grid gap-4 md:grid-cols-[1.6fr,1fr]">
                <pre className="max-h-[480px] overflow-auto whitespace-pre-wrap rounded-lg border border-border bg-background/60 p-4 font-mono text-xs leading-relaxed text-foreground">
{report}
                </pre>
                <aside className="flex flex-col gap-3">
                  <div className="rounded-lg border border-border bg-background/60 p-4">
                    <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                      <Target className="h-3.5 w-3.5" /> Purpose of the mod
                    </div>
                    <p className="text-sm leading-relaxed text-foreground">
                      {purpose || "No purpose inferred."}
                    </p>
                  </div>
                  <div className="rounded-lg border border-border bg-background/60 p-4">
                    <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                      <ServerCrash className="h-3.5 w-3.5" /> Unneeded / suspicious backends
                    </div>
                    {suspiciousBackends.length === 0 ? (
                      <p className="text-sm text-muted-foreground">
                        No suspicious backend calls detected for this mod's apparent purpose.
                      </p>
                    ) : (
                      <ul className="space-y-2">
                        {suspiciousBackends.map((b, i) => (
                          <li
                            key={i}
                            className="rounded-md border border-red-300 bg-red-50 p-2 text-xs dark:border-red-500/30 dark:bg-red-500/10"
                          >
                            <div className="break-all font-mono font-semibold text-red-800 dark:text-red-300">
                              {b.host}
                            </div>
                            {b.why && (
                              <div className="mt-1 text-red-900/80 dark:text-red-200/80">{b.why}</div>
                            )}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </aside>
              </div>
            ) : (
              <div className="rounded-lg border border-dashed border-border bg-background/40 p-6 text-center text-sm text-muted-foreground">
                {reportLoading
                  ? "Generating incident summary with Claude…"
                  : "Click \"Generate report\" to produce a judge-ready incident summary from this trace."}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}