import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Shield, Upload, Loader2, ArrowLeft, Search, AlertTriangle, CheckCircle2,
  Link2, Lock, Sparkles, X, Activity, Zap, TrendingUp, Hash, Radio,
  ChevronRight, ShieldCheck, Gamepad2, Skull, Eye, Cpu, KeyRound, FlaskConical,
} from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip as RTooltip,
  ResponsiveContainer, CartesianGrid,
} from "recharts";
import { Button } from "@/components/ui/button";
import { VerdictBadge, type Verdict } from "@/components/VerdictBadge";
import { scanJar } from "@/lib/scan.functions";
import { scanGameFile } from "@/lib/scan-game.functions";
import {
  recordScanEvent, getDashboardStats, getRecentEvents, lookupHash, getThreatLevel,
} from "@/lib/dashboard.functions";
import { StripeEmbeddedCheckout } from "@/components/StripeEmbeddedCheckout";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton,
  SidebarMenuItem, SidebarProvider, SidebarTrigger, SidebarInset, useSidebar,
} from "@/components/ui/sidebar";
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from "@/components/ui/collapsible";

const FREE_GAME_IDS = new Set(["minecraft", "roblox", "gtav", "wow", "cs2"]);
const FREE_SCAN_LIMIT = 5;
const SCAN_STORAGE_KEY = "modguard:free-scans-used";
const PRO_STORAGE_KEY = "modguard:pro";
const PRO_MONTHLY_PRICE = "modguard_pro_monthly";
const PRO_YEARLY_PRICE = "modguard_pro_yearly";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ModGuard — Mod Safety Scanner" },
      { name: "description", content: "Scan mods for the world's most-modded games." },
    ],
  }),
  component: Index,
});

type Game = {
  id: string;
  name: string;
  accept: string;
  exts: string[];
  engine: "jar" | "binary";
  mode: "file" | "url";
  cta: string;          // CTA button label, game-specific
  placeholder?: string; // for url mode
  trustedHosts?: string[]; // legit domains for url mode
  accent: string;
  accentText: string;
  tint: string;
  ring: string;
  gradient: string;
  threat: string;
  scannerTitle: string;
  scannerSubtitle: string;
  hints: string[];
};

const GAMES: Game[] = [
  { id: "minecraft", name: "Minecraft", accept: ".jar", exts: [".jar"], engine: "jar", mode: "file",
    cta: "Scan .jar mod",
    accent: "bg-emerald-500", accentText: "text-emerald-700", tint: "bg-emerald-50", ring: "border-emerald-200",
    gradient: "from-emerald-500 via-emerald-600 to-teal-700",
    threat: "Malicious .jar mods that steal Microsoft tokens",
    scannerTitle: "Drop a .jar mod",
    scannerSubtitle: "We unpack it and look for session-token stealers.",
    hints: ["Microsoft account token stealers are the #1 threat", "Stick to CurseForge or Modrinth"] },
  { id: "roblox", name: "Roblox", accept: "", exts: [], engine: "binary", mode: "url",
    cta: "Check URL",
    placeholder: "https://roblox.com/...",
    trustedHosts: ["roblox.com", "www.roblox.com", "web.roblox.com", "create.roblox.com"],
    accent: "bg-rose-500", accentText: "text-rose-700", tint: "bg-rose-50", ring: "border-rose-200",
    gradient: "from-rose-500 via-red-600 to-rose-700",
    threat: "Phishing sites & fake Robux / executor links",
    scannerTitle: "Paste a Roblox link",
    scannerSubtitle: "Most Roblox scams happen the moment you click an offsite URL.",
    hints: ["Fake Robux generators & 'free executor' sites steal your account", "Lookalike domains like r0blox.com are the #1 trick"] },
  { id: "gtav", name: "GTA V / FiveM", accept: ".asi,.dll,.rpf,.zip,.7z", exts: [".asi", ".dll", ".rpf", ".zip", ".7z"], engine: "binary", mode: "file",
    cta: "Scan mod menu",
    accent: "bg-lime-500", accentText: "text-lime-700", tint: "bg-lime-50", ring: "border-lime-200",
    gradient: "from-lime-500 via-green-600 to-emerald-700",
    threat: "Mod menus disguised as free cheats = info-stealers",
    scannerTitle: "Scan a mod menu",
    scannerSubtitle: "Free menus are the #1 way stealers get in.",
    hints: ["Mod menus are a top stealer-delivery channel", "FiveM resource zips can hide trojan .dlls"] },
  { id: "wow", name: "World of Warcraft", accept: ".zip,.lua,.toc", exts: [".zip", ".lua", ".toc"], engine: "binary", mode: "file",
    cta: "Scan addon",
    accent: "bg-amber-500", accentText: "text-amber-700", tint: "bg-amber-50", ring: "border-amber-200",
    gradient: "from-amber-500 via-orange-600 to-yellow-700",
    threat: "Fake addons phishing Battle.net credentials",
    scannerTitle: "Scan an addon",
    scannerSubtitle: "Fake updates and weakaura imports phish Battle.net.",
    hints: ["Addons asking for Battle.net password are scams", "Stick to CurseForge / WoWUp / Wago"] },
  { id: "cs2", name: "Counter-Strike 2", accept: ".exe,.dll,.vpk,.zip", exts: [".exe", ".dll", ".vpk", ".zip"], engine: "binary", mode: "file",
    cta: "Scan cheat / skin tool",
    accent: "bg-orange-500", accentText: "text-orange-700", tint: "bg-orange-50", ring: "border-orange-200",
    gradient: "from-orange-500 via-orange-600 to-red-700",
    threat: "\"Free undetected\" cheats that hijack your Steam",
    scannerTitle: "Scan a \"free cheat\"",
    scannerSubtitle: "Undetected = detected stealer. Skin changers too.",
    hints: ["Free cheats = Steam-session stealers", "Skin-changer .exe files are almost always RATs"] },
  { id: "sims4", name: "The Sims 4", accept: ".package,.ts4script,.zip", exts: [".package", ".ts4script", ".zip"], engine: "binary", mode: "file",
    cta: "Scan .ts4script",
    accent: "bg-cyan-500", accentText: "text-cyan-700", tint: "bg-cyan-50", ring: "border-cyan-200",
    gradient: "from-cyan-500 via-sky-600 to-blue-700",
    threat: "Malicious .ts4script bundles running Python payloads",
    scannerTitle: "Scan a .ts4script",
    scannerSubtitle: "Python scripts can run anything — including stealers.",
    hints: ["ts4script files are Python — they can run any code", "Treat unknown ts4script bundles as untrusted"] },
  { id: "skyrim", name: "Skyrim / SE", accept: ".esp,.esm,.esl,.bsa,.zip,.7z", exts: [".esp", ".esm", ".esl", ".bsa", ".zip", ".7z"], engine: "binary", mode: "file",
    cta: "Scan mod archive",
    accent: "bg-slate-600", accentText: "text-slate-700", tint: "bg-slate-100", ring: "border-slate-300",
    gradient: "from-slate-600 via-slate-700 to-zinc-800",
    threat: "Bundled .exe \"installers\" hidden inside archives",
    scannerTitle: "Scan a mod archive",
    scannerSubtitle: ".exe \"installers\" hidden inside .zip/.7z are trojans.",
    hints: ["Watch out for bundled .exe installers inside archives", "Use Nexus Mods or Mod Organizer 2"] },
  { id: "gmod", name: "Garry's Mod", accept: ".gma,.zip,.lua", exts: [".gma", ".zip", ".lua"], engine: "binary", mode: "file",
    cta: "Scan Lua addon",
    accent: "bg-red-500", accentText: "text-red-700", tint: "bg-red-50", ring: "border-red-200",
    gradient: "from-red-500 via-red-600 to-rose-700",
    threat: "Backdoored Lua addons from sketchy Discords",
    scannerTitle: "Scan a Lua addon",
    scannerSubtitle: "Leaked addons from random Discords run OS commands.",
    hints: ["Malicious Lua addons can run arbitrary OS commands", "Avoid 'leaked' addons from random Discords"] },
  { id: "stardew", name: "Stardew Valley", accept: ".zip,.dll", exts: [".zip", ".dll"], engine: "binary", mode: "file",
    cta: "Scan .dll mod",
    accent: "bg-yellow-500", accentText: "text-yellow-700", tint: "bg-yellow-50", ring: "border-yellow-200",
    gradient: "from-yellow-400 via-amber-500 to-orange-600",
    threat: "Untrusted .dll mods & fake SMAPI bundles",
    scannerTitle: "Scan a .dll mod",
    scannerSubtitle: "Untrusted .dlls and fake SMAPI bundles hide malware.",
    hints: ["Only install SMAPI mods from Nexus Mods", "Raw .dll mods deserve extra scrutiny"] },
  { id: "cyberpunk", name: "Cyberpunk 2077", accept: ".archive,.zip,.dll,.7z", exts: [".archive", ".zip", ".dll", ".7z"], engine: "binary", mode: "file",
    cta: "Scan Red4ext plugin",
    accent: "bg-fuchsia-500", accentText: "text-fuchsia-700", tint: "bg-fuchsia-50", ring: "border-fuchsia-200",
    gradient: "from-fuchsia-500 via-purple-600 to-indigo-700",
    threat: "Fake Red4ext / CET plugins running native code",
    scannerTitle: "Scan a Red4ext plugin",
    scannerSubtitle: "Native plugins from unknown authors run full code.",
    hints: ["Red4ext / CET plugins run native code — check the author", "Stick to Nexus Mods CP77 releases"] },
  { id: "fallout4", name: "Fallout 4", accept: ".esp,.esm,.ba2,.zip,.7z", exts: [".esp", ".esm", ".ba2", ".zip", ".7z"], engine: "binary", mode: "file",
    cta: "Scan mod installer",
    accent: "bg-yellow-600", accentText: "text-yellow-800", tint: "bg-yellow-50", ring: "border-yellow-300",
    gradient: "from-yellow-600 via-amber-700 to-stone-800",
    threat: "Bundled .exe \"mod loaders\" that drop trojans",
    scannerTitle: "Scan a mod installer",
    scannerSubtitle: "Bundled .exe \"mod loaders\" are common droppers.",
    hints: ["F4SE plugin .dlls run with full permissions", "Bundled installers are a common malware vector"] },
  { id: "valheim", name: "Valheim", accept: ".dll,.zip", exts: [".dll", ".zip"], engine: "binary", mode: "file",
    cta: "Scan BepInEx plugin",
    accent: "bg-sky-500", accentText: "text-sky-700", tint: "bg-sky-50", ring: "border-sky-200",
    gradient: "from-sky-500 via-blue-600 to-indigo-700",
    threat: "Unverified BepInEx plugins from outside Thunderstore",
    scannerTitle: "Scan a BepInEx plugin",
    scannerSubtitle: "Unverified plugins from outside Thunderstore are risky.",
    hints: ["BepInEx plugins run native .NET — verify the author", "Use Thunderstore mod manager when possible"] },
  { id: "terraria", name: "Terraria", accept: ".tmod,.zip", exts: [".tmod", ".zip"], engine: "binary", mode: "file",
    cta: "Scan .tmod",
    accent: "bg-teal-500", accentText: "text-teal-700", tint: "bg-teal-50", ring: "border-teal-200",
    gradient: "from-teal-500 via-emerald-600 to-green-700",
    threat: "Forum .tmod files trojaned outside the Mod Browser",
    scannerTitle: "Scan a .tmod file",
    scannerSubtitle: "Forum .tmods outside the Mod Browser get trojaned.",
    hints: ["Install only from the in-game Mod Browser", "Random .tmod files from forums can be trojaned"] },
  { id: "ark", name: "ARK: Survival", accept: ".mod,.zip", exts: [".mod", ".zip"], engine: "binary", mode: "file",
    cta: "Scan mod loader",
    accent: "bg-emerald-600", accentText: "text-emerald-800", tint: "bg-emerald-50", ring: "border-emerald-300",
    gradient: "from-emerald-600 via-green-700 to-teal-800",
    threat: "Fake \"mod loader\" .exe files from third-party sites",
    scannerTitle: "Scan a \"mod loader\"",
    scannerSubtitle: "Third-party .exe installers pretend to be mod tools.",
    hints: ["Use Steam Workshop, not third-party installers", "Bundled 'mod loaders' are usually malware"] },
  { id: "amongus", name: "Among Us", accept: ".zip,.dll,.exe", exts: [".zip", ".dll", ".exe"], engine: "binary", mode: "file",
    cta: "Scan mod menu",
    accent: "bg-pink-500", accentText: "text-pink-700", tint: "bg-pink-50", ring: "border-pink-200",
    gradient: "from-pink-500 via-rose-600 to-red-700",
    threat: "\"Always Imposter\" mod menus that are stealers",
    scannerTitle: "Scan a mod menu",
    scannerSubtitle: "\"Always Imposter\" mods are stealers in disguise.",
    hints: ["'Always Imposter' mods are a common stealer disguise", "Innersloth doesn't endorse any external mod menus"] },
];

function bytesToBase64(bytes: Uint8Array): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return btoa(bin);
}

function buildEventPayload(r: AnyResult, game: Game, source: "file" | "url") {
  const sev: Record<string, number> = {};
  for (const f of r.findings) sev[f.severity] = (sev[f.severity] ?? 0) + 1;
  return {
    sha256: r.sha256 && /^[a-f0-9]{64}$/i.test(r.sha256) ? r.sha256 : undefined,
    fileName: r.fileName.slice(0, 500),
    gameId: game.id,
    verdict: r.verdict,
    severityCounts: sev,
    source,
  };
}

// Client-side URL heuristic scanner (used by url-mode games like Roblox)
function scanUrlHeuristic(input: string, game: Game): AnyResult {
  const findings: AnyResult["findings"] = [];
  const rationale: string[] = [];
  let url: URL | null = null;
  try {
    url = new URL(input.trim().match(/^https?:\/\//i) ? input.trim() : `https://${input.trim()}`);
  } catch {
    return {
      fileName: input, sha256: "",
      verdict: "confirmed_malicious" as Verdict,
      rationale: ["Not a valid URL."],
      findings: [{ severity: "high", category: "format", detail: "Could not parse as a URL.", evidence: input }],
    };
  }
  const host = url.hostname.toLowerCase();
  const trusted = (game.trustedHosts ?? []).map((h) => h.toLowerCase());
  const isTrustedExact = trusted.includes(host);
  const isTrustedSub = trusted.some((t) => host === t || host.endsWith("." + t));

  // Heuristic checks
  const scamKeywords = ["free", "robux", "generator", "executor", "hack", "gen", "giveaway", "win", "claim", "promo", "vbucks", "synapse", "krnl"];
  const hitKeywords = scamKeywords.filter((k) => host.includes(k) || url!.pathname.toLowerCase().includes(k));
  const lookalikeChars = /[0-9]/.test(host.split(".")[0]) && /roblox|robux/.test(host);
  const isPunycode = host.includes("xn--");
  const isIpLiteral = /^\d{1,3}(\.\d{1,3}){3}$/.test(host);
  const cheapTlds = [".xyz", ".top", ".click", ".gq", ".tk", ".ml", ".cf", ".buzz", ".fit", ".rest"];
  const isCheapTld = cheapTlds.some((t) => host.endsWith(t));
  const isHttp = url.protocol === "http:";

  if (isTrustedExact || isTrustedSub) {
    rationale.push(`Host matches official ${game.name} domain (${host}).`);
  } else {
    rationale.push(`Host ${host} is NOT on the official ${game.name} domain list.`);
    findings.push({ severity: "medium", category: "domain", detail: "Off-site link. Most scams begin here.", evidence: host });
  }
  if (lookalikeChars) findings.push({ severity: "critical", category: "lookalike", detail: "Domain mimics Roblox/Robux with digits.", evidence: host });
  if (isPunycode) findings.push({ severity: "high", category: "homoglyph", detail: "Punycode/IDN domain — often used to spoof real brands.", evidence: host });
  if (isIpLiteral) findings.push({ severity: "high", category: "ip-literal", detail: "Raw IP address instead of a domain.", evidence: host });
  if (isCheapTld) findings.push({ severity: "medium", category: "tld", detail: "Cheap/throwaway TLD commonly used by scam pages.", evidence: host });
  if (isHttp) findings.push({ severity: "medium", category: "transport", detail: "No HTTPS — credentials could be intercepted.", evidence: url.protocol });
  if (hitKeywords.length) findings.push({ severity: "high", category: "scam-keywords", detail: `Phishing keywords in URL: ${hitKeywords.join(", ")}.`, evidence: host + url.pathname });

  let verdict: Verdict = "safe";
  if (findings.some((f) => f.severity === "critical")) verdict = "confirmed_malicious";
  else if (findings.filter((f) => f.severity === "high").length >= 1) verdict = "confirmed_malicious";
  else if (findings.length >= 2) verdict = "suspicious";
  else if (findings.length === 1) verdict = "suspicious";
  else if (isTrustedExact || isTrustedSub) verdict = "safe";

  if (verdict === "safe") rationale.push("No phishing indicators detected.");
  else rationale.push(`${findings.length} risk indicator${findings.length === 1 ? "" : "s"} detected.`);

  return { fileName: url.toString(), sha256: "", verdict, rationale, findings };
}


type AnyResult = {
  fileName: string;
  sha256: string;
  verdict: Verdict;
  rationale: string[];
  findings: { severity: string; category: string; detail: string; evidence?: string }[];
};

function Index() {
  const scanJarFn = useServerFn(scanJar);
  const scanGameFn = useServerFn(scanGameFile);
  const recordScanFn = useServerFn(recordScanEvent);
  const qc = useQueryClient();
  const recordMutation = useMutation({
    mutationFn: recordScanFn,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["dashboard-stats"] });
      qc.invalidateQueries({ queryKey: ["recent-events"] });
      qc.invalidateQueries({ queryKey: ["threat-level"] });
    },
  });
  const [game, setGame] = useState<Game | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<AnyResult | null>(null);
  const [query, setQuery] = useState("");
  const [scansUsed, setScansUsed] = useState(0);
  const [showPaywall, setShowPaywall] = useState<null | "locked" | "limit" | "upgrade">(null);
  const [isPro, setIsPro] = useState(false);

  useEffect(() => {
    const raw = typeof window !== "undefined" ? localStorage.getItem(SCAN_STORAGE_KEY) : null;
    setScansUsed(raw ? Math.max(0, parseInt(raw, 10) || 0) : 0);
    setIsPro(typeof window !== "undefined" && localStorage.getItem(PRO_STORAGE_KEY) === "1");
  }, []);

  const scansLeft = Math.max(0, FREE_SCAN_LIMIT - scansUsed);

  const { freeGames, proGames } = useMemo(() => {
    const q = query.trim().toLowerCase();
    const match = (g: Game) => !q || g.name.toLowerCase().includes(q);
    return {
      freeGames: GAMES.filter((g) => FREE_GAME_IDS.has(g.id) && match(g)),
      proGames: GAMES.filter((g) => !FREE_GAME_IDS.has(g.id) && match(g)),
    };
  }, [query]);
  const totalMatches = freeGames.length + proGames.length;

  function consumeScan() {
    const next = scansUsed + 1;
    setScansUsed(next);
    try { localStorage.setItem(SCAN_STORAGE_KEY, String(next)); } catch {}
  }

  function pickGame(g: Game) {
    if (!isPro && !FREE_GAME_IDS.has(g.id)) { setShowPaywall("locked"); return; }
    setGame(g); setResult(null);
  }

  async function onFile(file: File) {
    if (!game) return;
    if (!isPro && scansLeft <= 0) { setShowPaywall("limit"); return; }
    const ok = game.exts.some((e) => file.name.toLowerCase().endsWith(e));
    if (!ok) { toast.error(`Accepted: ${game.exts.join(", ")}`); return; }
    if (file.size > 80_000_000) { toast.error("Max 80MB"); return; }
    setBusy(true); setResult(null);
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const fileBase64 = bytesToBase64(bytes);
      let scanned: AnyResult;
      if (game.engine === "jar") {
        const r = await scanJarFn({ data: { fileName: file.name, fileBase64 } });
        scanned = { fileName: r.fileName, sha256: r.sha256, verdict: r.finalVerdict as Verdict, rationale: r.rationale, findings: r.findings };
      } else {
        const r = await scanGameFn({ data: { fileName: file.name, fileBase64 } });
        scanned = { fileName: r.fileName, sha256: r.sha256, verdict: r.verdict as Verdict, rationale: r.rationale, findings: r.findings };
      }
      setResult(scanned);
      recordMutation.mutate({ data: buildEventPayload(scanned, game, "file") });
      if (!isPro) consumeScan();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Scan failed");
    } finally { setBusy(false); }
  }

  function onUrl(value: string) {
    if (!game) return;
    if (!isPro && scansLeft <= 0) { setShowPaywall("limit"); return; }
    if (!value.trim()) { toast.error("Enter a URL"); return; }
    setBusy(true); setResult(null);
    try {
      const r = scanUrlHeuristic(value, game);
      setResult(r);
      recordMutation.mutate({ data: buildEventPayload(r, game, "url") });
      if (!isPro) consumeScan();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Scan failed");
    } finally { setBusy(false); }
  }


  return (
    <SidebarProvider>
      <GamesSidebar
        freeGames={freeGames}
        proGames={proGames}
        totalMatches={totalMatches}
        query={query}
        setQuery={setQuery}
        activeId={game?.id ?? null}
        onPick={pickGame}
        onPickLocked={() => setShowPaywall("locked")}
        isPro={isPro}
      />
      <SidebarInset className="relative z-10 bg-transparent">
        <PaymentTestModeBanner />
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-border bg-background/75 px-4 backdrop-blur-md">
          <SidebarTrigger />
          <div className="h-5 w-px bg-border" />
          <button
            onClick={() => { setGame(null); setResult(null); }}
            className="flex cursor-pointer items-center gap-2"
          >
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground shadow-sm">
              <Shield className="h-4.5 w-4.5" strokeWidth={2.5} />
            </span>
            <span className="font-display text-lg font-bold tracking-tight">ModGuard</span>
            <span className="hidden sm:inline text-xs text-muted-foreground font-medium tracking-wide">3rd party modification scanner</span>
          </button>
          <div className="ml-auto flex items-center gap-2">
            <ThreatLevelPill />
            <Link
              to="/sandbox"
              className="hidden sm:inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold text-foreground shadow-sm hover:bg-accent"
              title="Open sandbox tester"
            >
              <FlaskConical className="h-4 w-4" /> Sandbox
            </Link>
            {!isPro && (
              <div className="hidden sm:flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground shadow-sm">
                <span className={scansLeft === 0 ? "text-danger font-semibold" : "text-foreground font-semibold"}>{scansLeft}</span>
                <span>/ {FREE_SCAN_LIMIT} free</span>
              </div>
            )}
            {isPro ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
                <Sparkles className="h-4 w-4" /> Pro
              </span>
            ) : (
              <button
                onClick={() => setShowPaywall("upgrade")}
                className="inline-flex items-center gap-1.5 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground shadow-sm hover:opacity-90"
              >
                <Sparkles className="h-4 w-4" /> Upgrade
              </button>
            )}
            <button
              onClick={() => {
                const next = !isPro;
                setIsPro(next);
                try {
                  if (next) localStorage.setItem(PRO_STORAGE_KEY, "1");
                  else localStorage.removeItem(PRO_STORAGE_KEY);
                } catch {}
                toast.success(next ? "Admin mode ON — Pro unlocked" : "Admin mode OFF");
              }}
              className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/60 bg-amber-500/15 px-3 py-1 text-xs font-semibold text-amber-700 shadow-sm hover:bg-amber-500/25 dark:text-amber-300"
              title="Admin override — bypass paywall"
            >
              <KeyRound className="h-4 w-4" /> Admin
            </button>
          </div>
        </header>

        <main className="mx-auto w-full max-w-6xl px-5 py-8">
          {!game ? (
            <CyberDashboard
              scansUsed={scansUsed}
              scansLeft={scansLeft}
              totalGames={GAMES.length}
              onPickGame={pickGame}
              freeGames={freeGames}
            />
          ) : (
            <>
              <div className="mb-5 flex items-center gap-3">
                <button
                  onClick={() => { setGame(null); setResult(null); }}
                  className="inline-flex cursor-pointer items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
                >
                  <ArrowLeft className="h-5 w-5" /> Dashboard
                </button>
                <div className="h-4 w-px bg-border" />
                <div className={`h-2 w-2 rounded-full ${game.accent}`} />
                <span className="font-display text-sm font-semibold">{game.name}</span>
                <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  {game.mode === "url" ? "URL CHECK" : game.exts.join(" ")}
                </span>
              </div>

              <div className="mb-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
                <h1 className="font-display text-xl font-bold tracking-tight">{game.scannerTitle}</h1>
                <p className="mt-1 text-sm text-muted-foreground">{game.scannerSubtitle}</p>
              </div>

              <ScanPanel game={game} disabled={busy} onFile={onFile} onUrl={onUrl} />

              {busy && (
                <div className="mt-4 flex items-center gap-3 rounded-xl border border-border bg-card p-3">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  <div className="text-sm font-mono">Detonating in sandbox · analyzing entropy · matching IoCs…</div>
                </div>
              )}

              {result && <Result r={result} />}
            </>
          )}
        </main>
      </SidebarInset>

      {showPaywall && <Paywall kind={showPaywall} onClose={() => setShowPaywall(null)} />}

      <div className="pointer-events-none fixed bottom-3 right-5 z-50 font-mono text-[10px] uppercase tracking-widest text-muted-foreground/60">
        v1.0.0 · SOC
      </div>
    </SidebarProvider>
  );
}

/* -------------------------- Sidebar -------------------------- */

function GamesSidebar({
  freeGames, proGames, totalMatches, query, setQuery, activeId, onPick, onPickLocked, isPro,
}: {
  freeGames: Game[]; proGames: Game[]; totalMatches: number;
  query: string; setQuery: (v: string) => void;
  activeId: string | null;
  onPick: (g: Game) => void; onPickLocked: () => void;
  isPro: boolean;
}) {
  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center gap-2 px-2 py-1.5 group-data-[collapsible=icon]:justify-center">
          <span className="grid h-8 w-8 flex-shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground shadow-sm">
            <Gamepad2 className="h-4.5 w-4.5" strokeWidth={2.5} />
          </span>
          <div className="min-w-0 group-data-[collapsible=icon]:hidden">
            <div className="font-display text-sm font-bold tracking-tight">Game Library</div>
            <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{GAMES.length} engines</div>
          </div>
        </div>
        <div className="px-2 pb-2 group-data-[collapsible=icon]:hidden">
          <div className="flex items-center gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/40 px-2.5 py-1.5">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search games…"
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <GameGroup label="Free Games" badge="Included" badgeClass="bg-emerald-500/15 text-emerald-700" defaultOpen>
          {freeGames.length === 0 ? (
            <EmptyHint />
          ) : (
            freeGames.map((g) => (
              <GameMenuItem
                key={g.id}
                g={g}
                active={g.id === activeId}
                onClick={() => onPick(g)}
              />
            ))
          )}
        </GameGroup>

        <GameGroup label="Pro Games" badge="Pro" badgeClass="bg-primary/15 text-primary" defaultOpen>
          {proGames.length === 0 ? (
            <EmptyHint />
          ) : (
            proGames.map((g) => (
              <GameMenuItem
                key={g.id}
                g={g}
                active={g.id === activeId}
                locked={!isPro}
                onClick={() => (isPro ? onPick(g) : onPickLocked())}
              />
            ))
          )}
        </GameGroup>

        {totalMatches === 0 && (
          <div className="px-3 py-2 text-xs text-muted-foreground group-data-[collapsible=icon]:hidden">
            No games match "{query}".
          </div>
        )}

        <SidebarGroup>
          <SidebarGroupLabel>Defense</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Process Monitor">
                  <Link to="/monitor" className="flex items-center gap-2">
                    <Activity className="h-4 w-4" />
                    <span>Process Monitor</span>
                    <span className="ml-auto rounded-full bg-primary/15 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-primary group-data-[collapsible=icon]:hidden">New</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        <ThreatTicker />
      </SidebarFooter>
    </Sidebar>
  );
}

function GameGroup({
  label, badge, badgeClass, defaultOpen, children,
}: { label: string; badge: string; badgeClass: string; defaultOpen?: boolean; children: React.ReactNode }) {
  const { state } = useSidebar();
  if (state === "collapsed") {
    return (
      <SidebarGroup>
        <SidebarGroupContent>
          <SidebarMenu>{children}</SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>
    );
  }
  return (
    <Collapsible defaultOpen={defaultOpen} className="group/collapsible">
      <SidebarGroup>
        <SidebarGroupLabel asChild>
          <CollapsibleTrigger className="flex w-full items-center justify-between rounded-md px-2 py-1.5 hover:bg-sidebar-accent/60">
            <span className="flex items-center gap-2">
              <ChevronRight className="h-3.5 w-3.5 transition-transform group-data-[state=open]/collapsible:rotate-90" />
              <span className="font-display text-xs font-semibold uppercase tracking-widest">{label}</span>
            </span>
            <span className={`rounded-full px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider ${badgeClass}`}>{badge}</span>
          </CollapsibleTrigger>
        </SidebarGroupLabel>
        <CollapsibleContent>
          <SidebarGroupContent>
            <SidebarMenu>{children}</SidebarMenu>
          </SidebarGroupContent>
        </CollapsibleContent>
      </SidebarGroup>
    </Collapsible>
  );
}

function GameMenuItem({
  g, active, locked, onClick,
}: { g: Game; active: boolean; locked?: boolean; onClick: () => void }) {
  return (
    <SidebarMenuItem>
      <SidebarMenuButton onClick={onClick} isActive={active} tooltip={g.name} className="group/item">
        <span className={`h-4 w-1 flex-shrink-0 rounded-full ${g.accent} ${locked ? "opacity-50" : ""}`} />
        <span className="flex-1 truncate font-display text-sm font-medium">{g.name}</span>
        {locked ? (
          <Lock className="h-3.5 w-3.5 text-muted-foreground" />
        ) : (
          <span className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground group-data-[collapsible=icon]:hidden">
            {g.mode === "url" ? "URL" : g.exts[0]?.replace(".", "") ?? ""}
          </span>
        )}
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}

function EmptyHint() {
  return <div className="px-3 py-1.5 text-xs text-muted-foreground group-data-[collapsible=icon]:hidden">—</div>;
}

/* -------------------------- Cyber additions -------------------------- */

function ThreatLevelPill() {
  const fn = useServerFn(getThreatLevel);
  const { data } = useQuery({
    queryKey: ["threat-level"],
    queryFn: () => fn(),
    refetchInterval: 30_000,
  });
  const level = data?.level ?? "low";
  const cfg = {
    low: { dot: "bg-safe", text: "text-safe", label: "LOW" },
    elevated: { dot: "bg-warn", text: "text-warn-foreground", label: "ELEVATED" },
    high: { dot: "bg-critical", text: "text-critical", label: "HIGH" },
  }[level];
  return (
    <div
      className="hidden md:inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 font-mono text-[10px] uppercase tracking-widest shadow-sm"
      title={data ? `${data.malicious} malicious / ${data.total} scans · last hour` : "no data yet"}
    >
      <span className="relative flex h-2 w-2">
        <span className={`absolute inline-flex h-full w-full animate-ping rounded-full ${cfg.dot} opacity-60`} />
        <span className={`relative inline-flex h-2 w-2 rounded-full ${cfg.dot}`} />
      </span>
      <span className="text-muted-foreground">DEFCON</span>
      <span className={`font-semibold ${cfg.text}`}>{cfg.label}</span>
    </div>
  );
}

function ThreatTicker() {
  const fn = useServerFn(getRecentEvents);
  const { data } = useQuery({
    queryKey: ["recent-events"],
    queryFn: () => fn({ data: { limit: 5 } }),
    refetchInterval: 10_000,
  });
  const items = data ?? [];
  return (
    <div className="px-2 pb-1 pt-2 group-data-[collapsible=icon]:hidden">
      <div className="mb-1.5 flex items-center gap-1.5 px-1 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
        <Radio className="h-3 w-3 animate-pulse text-primary" />
        Live Scan Feed
      </div>
      {items.length === 0 ? (
        <div className="rounded-md bg-sidebar-accent/30 p-2 text-[10px] text-muted-foreground">
          No scans yet. Run a scan to populate the feed.
        </div>
      ) : (
        <ul className="space-y-1">
          {items.map((it) => {
            const game = GAMES.find((g) => g.id === it.game_id);
            const tone =
              it.verdict === "confirmed_malicious" || it.verdict === "likely_malicious" ? "bg-critical"
              : it.verdict === "suspicious" ? "bg-danger"
              : it.verdict === "safe" || it.verdict === "low_risk" ? "bg-safe"
              : "bg-muted";
            return (
              <li key={it.id} className="flex items-start gap-2 rounded-md bg-sidebar-accent/40 p-1.5">
                <span className={`mt-1 h-1.5 w-1.5 flex-shrink-0 rounded-full ${tone}`} />
                <div className="min-w-0">
                  <div className="truncate text-[11px] font-medium leading-tight">
                    {game?.name ?? it.game_id} · {verdictShort(it.verdict)}
                  </div>
                  <div className="truncate font-mono text-[9px] text-muted-foreground">{it.file_name}</div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function verdictShort(v: string) {
  return ({
    confirmed_malicious: "malicious",
    likely_malicious: "likely malicious",
    suspicious: "suspicious",
    low_risk: "low risk",
    safe: "clean",
    unknown: "unknown",
  } as Record<string, string>)[v] ?? v;
}

function CyberDashboard({
  scansUsed, scansLeft, totalGames, onPickGame, freeGames,
}: {
  scansUsed: number; scansLeft: number; totalGames: number;
  onPickGame: (g: Game) => void; freeGames: Game[];
}) {
  const statsFn = useServerFn(getDashboardStats);
  const lookupFn = useServerFn(lookupHash);
  const { data: stats } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: () => statsFn(),
    refetchInterval: 15_000,
  });

  const [hash, setHash] = useState("");
  const [lookup, setLookup] = useState<null | Awaited<ReturnType<typeof lookupFn>>>(null);
  const [looking, setLooking] = useState(false);

  async function checkHash() {
    const h = hash.trim().toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(h)) {
      toast.error("Enter a valid SHA-256 (64 hex chars)");
      return;
    }
    setLooking(true);
    try {
      const r = await lookupFn({ data: { sha256: h } });
      setLookup(r);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Lookup failed");
    } finally {
      setLooking(false);
    }
  }

  const topThreatGame = useMemo(() => {
    if (!stats || stats.games.length === 0) return null;
    return [...stats.games].sort((a, b) => b.malicious - a.malicious)[0];
  }, [stats]);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          <Cpu className="h-3.5 w-3.5" /> ModGuard SOC · operational
        </div>
        <h1 className="mt-2 font-display text-3xl font-bold tracking-tight">Scan mods before you install</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Every scan is recorded. Malicious hashes land in the signature database so the next person who tries
          the same file gets blocked instantly.
        </p>

        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard icon={Activity} label="Scans · all time"
            value={(stats?.totalScansAllTime ?? 0).toLocaleString()}
            hint={`${stats?.scans7d ?? 0} in last 7d`} tone="primary" />
          <StatCard icon={ShieldCheck} label="Malicious · 7d"
            value={(stats?.blocked7d ?? 0).toLocaleString()}
            hint={`${stats?.scans7d ? Math.round((stats.blocked7d / stats.scans7d) * 100) : 0}% of scans`} tone="safe" />
          <StatCard icon={Skull} label="Known malware sigs"
            value={(stats?.knownMalwareCount ?? 0).toLocaleString()}
            hint="unique SHA-256" tone="danger" />
          <StatCard icon={Zap} label="Top-risk game"
            value={topThreatGame ? (GAMES.find((g) => g.id === topThreatGame.game_id)?.name ?? topThreatGame.game_id) : "—"}
            hint={topThreatGame ? `${topThreatGame.malicious}/${topThreatGame.total} malicious` : "no data yet"} tone="warn" />
        </div>
      </div>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <h3 className="font-display text-sm font-semibold">Scans per day · 7d</h3>
            </div>
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">stacked by verdict</span>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats?.days ?? []} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="g-safe" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--safe)" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="var(--safe)" stopOpacity={0.05} />
                  </linearGradient>
                  <linearGradient id="g-susp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--warn)" stopOpacity={0.7} />
                    <stop offset="100%" stopColor="var(--warn)" stopOpacity={0.05} />
                  </linearGradient>
                  <linearGradient id="g-mal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--critical)" stopOpacity={0.7} />
                    <stop offset="100%" stopColor="var(--critical)" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(d) => d.slice(5)} stroke="var(--muted-foreground)" />
                <YAxis tick={{ fontSize: 10 }} allowDecimals={false} stroke="var(--muted-foreground)" />
                <RTooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", fontSize: 12 }} />
                <Area type="monotone" dataKey="safe" stackId="1" stroke="var(--safe)" fill="url(#g-safe)" />
                <Area type="monotone" dataKey="suspicious" stackId="1" stroke="var(--warn)" fill="url(#g-susp)" />
                <Area type="monotone" dataKey="malicious" stackId="1" stroke="var(--critical)" fill="url(#g-mal)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gamepad2 className="h-4 w-4 text-primary" />
              <h3 className="font-display text-sm font-semibold">Per-game scans · 7d</h3>
            </div>
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">total vs malicious</span>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={(stats?.games ?? []).map((g) => ({
                  name: GAMES.find((x) => x.id === g.game_id)?.name ?? g.game_id,
                  total: g.total,
                  malicious: g.malicious,
                }))}
                margin={{ top: 4, right: 8, left: -16, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" interval={0} angle={-20} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 10 }} allowDecimals={false} stroke="var(--muted-foreground)" />
                <RTooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", fontSize: 12 }} />
                <Bar dataKey="total" fill="var(--primary)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="malicious" fill="var(--critical)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gamepad2 className="h-4.5 w-4.5 text-primary" />
              <h2 className="font-display text-base font-semibold">Quick launch</h2>
            </div>
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{totalGames} engines</span>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            {freeGames.slice(0, 6).map((g) => (
              <button
                key={g.id}
                onClick={() => onPickGame(g)}
                className="group flex items-center gap-3 rounded-xl border border-border bg-background/60 p-3 text-left transition-all hover:border-foreground/40 hover:shadow-sm"
              >
                <div className={`h-9 w-1.5 flex-shrink-0 rounded-full ${g.accent}`} />
                <div className="min-w-0 flex-1">
                  <div className="font-display text-sm font-semibold leading-tight">{g.name}</div>
                  <div className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground">{g.threat}</div>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-foreground" />
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
            <div className="mb-2 flex items-center gap-2">
              <Hash className="h-4 w-4 text-primary" />
              <h3 className="font-display text-sm font-semibold">IoC Hash Lookup</h3>
            </div>
            <p className="text-xs text-muted-foreground">Paste a SHA-256 to check the malware signature database.</p>
            <div className="mt-3 flex gap-2">
              <input
                value={hash}
                onChange={(e) => setHash(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && checkHash()}
                placeholder="e.g. 9f86d081884c7d659a2feaa0c55ad015…"
                className="w-full rounded-md border border-border bg-background px-2.5 py-1.5 font-mono text-[11px] outline-none placeholder:text-muted-foreground/60 focus:border-primary"
              />
              <Button size="sm" onClick={checkHash} disabled={looking}>
                {looking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
            {lookup && (
              <div className="mt-3 rounded-lg border border-border bg-background/60 p-2.5">
                {lookup.known ? (
                  <>
                    <VerdictBadge verdict={lookup.known.verdict as Verdict} size="md" />
                    <div className="mt-1.5 font-display text-sm font-semibold">{lookup.known.name}</div>
                    {lookup.known.notes && <div className="mt-0.5 text-xs text-muted-foreground">{lookup.known.notes}</div>}
                    <div className="mt-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      {lookup.known.hit_count} hit{lookup.known.hit_count === 1 ? "" : "s"} · {lookup.sightings} sighting{lookup.sightings === 1 ? "" : "s"}
                    </div>
                  </>
                ) : (
                  <>
                    <div className="font-display text-sm font-semibold">Not in signature database</div>
                    <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      {lookup.sightings} prior sighting{lookup.sightings === 1 ? "" : "s"}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
            <div className="mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <h3 className="font-display text-sm font-semibold">Verdict mix · 7d</h3>
            </div>
            <VerdictMix mix={stats?.mix} />
          </div>

          {scansLeft < FREE_SCAN_LIMIT && (
            <div className="rounded-2xl border border-border bg-card p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Free scans</div>
                <div className="font-display text-lg font-bold tabular-nums">{scansLeft}<span className="text-muted-foreground text-sm font-normal">/{FREE_SCAN_LIMIT}</span></div>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-primary transition-all" style={{ width: `${(scansUsed / FREE_SCAN_LIMIT) * 100}%` }} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function VerdictMix({ mix }: { mix?: Record<string, number> }) {
  const rows = [
    { key: "safe", label: "Clean", color: "bg-safe" },
    { key: "low_risk", label: "Low risk", color: "bg-primary" },
    { key: "suspicious", label: "Suspicious", color: "bg-warn" },
    { key: "likely_malicious", label: "Likely malicious", color: "bg-danger" },
    { key: "confirmed_malicious", label: "Confirmed malicious", color: "bg-critical" },
  ];
  const total = rows.reduce((s, r) => s + (mix?.[r.key] ?? 0), 0);
  if (!total) {
    return <div className="text-xs text-muted-foreground">No scans recorded in the last 7 days yet.</div>;
  }
  return (
    <ul className="space-y-2 text-xs">
      {rows.map((r) => {
        const v = mix?.[r.key] ?? 0;
        const pct = Math.round((v / total) * 100);
        return (
          <li key={r.key}>
            <div className="mb-1 flex items-center justify-between">
              <span>{r.label}</span>
              <span className="font-mono text-[10px] text-muted-foreground">{v} · {pct}%</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <div className={`h-full ${r.color}`} style={{ width: `${pct}%` }} />
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function StatCard({
  icon: Icon, label, value, hint, tone,
}: { icon: typeof Activity; label: string; value: string; hint: string; tone: "primary" | "safe" | "warn" | "danger" }) {
  const toneMap = {
    primary: "text-primary bg-primary/10",
    safe: "text-safe bg-safe/15",
    warn: "text-warn-foreground bg-warn/20",
    danger: "text-critical bg-critical/15",
  };
  return (
    <div className="rounded-xl border border-border bg-background/60 p-3.5">
      <div className="flex items-center gap-2">
        <span className={`grid h-7 w-7 place-items-center rounded-md ${toneMap[tone]}`}>
          <Icon className="h-4 w-4" />
        </span>
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</span>
      </div>
      <div className="mt-2 font-display text-2xl font-bold tabular-nums">{value}</div>
      <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{hint}</div>
    </div>
  );
}

function ScanPanel({ game, onFile, onUrl, disabled }: { game: Game; onFile: (f: File) => void; onUrl: (v: string) => void; disabled: boolean }) {
  const [drag, setDrag] = useState(false);
  const [url, setUrl] = useState("");
  const id = "file-input";

  const inputPane = game.mode === "url" ? (
    <div
      className={`relative rounded-xl border-2 border-dashed p-8 transition-all ${game.ring} ${game.tint} ${disabled ? "pointer-events-none opacity-60" : ""}`}
    >
      <div className={`mx-auto grid h-14 w-14 place-items-center rounded-xl ${game.accent} text-white`}>
        <Link2 className="h-6 w-6" />
      </div>
      <div className="mt-4 flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 shadow-sm">
        <Link2 className="h-5 w-5 flex-shrink-0 text-muted-foreground" />
        <input
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") onUrl(url); }}
          placeholder={game.placeholder ?? "https://..."}
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          disabled={disabled}
        />
      </div>
      <Button
        size="sm"
        onClick={() => onUrl(url)}
        disabled={disabled}
        className={`mt-3 w-full ${game.accent} text-white hover:opacity-90 border-0`}
      >
        {game.cta}
      </Button>
      <div className="mt-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        Checks lookalike domains, phishing keywords, cheap TLDs
      </div>
    </div>
  ) : (
    <div
      onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
      onDragLeave={() => setDrag(false)}
      onDrop={(e) => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) onFile(f); }}
      className={`relative rounded-xl border-2 border-dashed p-8 text-center transition-all ${game.ring} ${game.tint} ${drag ? "scale-[1.005]" : ""} ${disabled ? "pointer-events-none opacity-60" : ""}`}
    >
      <input id={id} type="file" accept={game.accept} className="hidden" disabled={disabled}
        onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.currentTarget.value = ""; }} />
      <div className={`mx-auto grid h-14 w-14 place-items-center rounded-xl ${game.accent} text-white`}>
        <Upload className="h-6 w-6" />
      </div>
      <div className="mt-3 text-sm text-foreground/80">Drop file or</div>
      <Button asChild size="sm" className={`mt-3 ${game.accent} text-white hover:opacity-90 border-0`}>
        <label htmlFor={id} className="cursor-pointer">{game.cta}</label>
      </Button>
      <div className="mt-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{game.exts.join(" ")} · max 80MB</div>
    </div>
  );

  return (
    <div className="grid gap-3 lg:grid-cols-[1.6fr_1fr]">
      {inputPane}

      <div className={`rounded-xl border ${game.ring} bg-card p-4`}>
        <div className={`mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-widest ${game.accentText}`}>
          <AlertTriangle className="h-4 w-4" />
          Threats
        </div>
        <ul className="space-y-1.5 text-xs">
          {game.hints.map((h, i) => (
            <li key={i} className="flex gap-2">
              <span className={`mt-1 h-1 w-1 flex-shrink-0 rounded-full ${game.accent}`} />
              <span className="leading-snug text-foreground/80">{h}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function Result({ r }: { r: AnyResult }) {
  return (
    <div className="mt-6 space-y-4">
      <div className="rounded-3xl border border-border bg-card p-6 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <VerdictBadge verdict={r.verdict} size="lg" />
          <span className="font-mono text-sm text-muted-foreground">{r.fileName}</span>
        </div>
        <ul className="mt-5 space-y-2 text-sm">
          {r.rationale.map((l, i) => (
            <li key={i} className="flex gap-2.5">
              <CheckCircle2 className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary" />
              <span>{l}</span>
            </li>
          ))}
        </ul>
      </div>

      {r.findings.length > 0 && (
        <div className="rounded-3xl border border-border bg-card p-6 shadow-sm">
          <div className="mb-4 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Findings · {r.findings.length}
          </div>
          <ul className="space-y-2.5">
            {r.findings.map((f, i) => (
              <li key={i} className="rounded-xl border border-border bg-background/60 p-4">
                <div className="flex items-center gap-2">
                  <Sev s={f.severity} />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{f.category}</span>
                </div>
                <div className="mt-1.5 text-sm">{f.detail}</div>
                {f.evidence && <div className="mt-1 break-all font-mono text-xs text-muted-foreground">{f.evidence}</div>}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function Sev({ s }: { s: string }) {
  const map: Record<string, string> = {
    low: "bg-muted text-muted-foreground",
    medium: "bg-warn/20 text-warn-foreground",
    high: "bg-danger/15 text-danger",
    critical: "bg-critical/20 text-critical",
  };
  return <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider ${map[s] ?? "bg-muted"}`}>{s}</span>;
}

function Paywall({ kind, onClose }: { kind: "locked" | "limit" | "upgrade"; onClose: () => void }) {
  const [interval, setInterval] = useState<"month" | "year">("month");
  const [checkout, setCheckout] = useState(false);

  const title =
    kind === "limit" ? "You've used all 5 free scans"
    : kind === "locked" ? "This game needs Pro"
    : "Upgrade to ModGuard Pro";
  const subtitle =
    kind === "limit" ? "Go Pro for unlimited scans across every supported game."
    : kind === "locked" ? "Pro games are part of the full library. Upgrade to unlock and keep scanning."
    : "Unlimited scans across every supported game.";

  const priceId = interval === "month" ? PRO_MONTHLY_PRICE : PRO_YEARLY_PRICE;

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-background/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className={`w-full ${checkout ? "max-w-2xl" : "max-w-md"} rounded-2xl border border-border bg-card shadow-xl`}
      >
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground">
              <Sparkles className="h-5.5 w-5.5" />
            </span>
            <div>
              <div className="font-display text-base font-bold">{checkout ? "Checkout" : title}</div>
              <div className="text-xs text-muted-foreground">ModGuard Pro</div>
            </div>
          </div>
          <button onClick={onClose} className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        {checkout ? (
          <div className="p-2">
            <StripeEmbeddedCheckout priceId={priceId} />
          </div>
        ) : (
          <div className="p-6">
            <p className="text-sm text-foreground/80">{subtitle}</p>
            <ul className="mt-4 space-y-2 text-sm">
              {[
                "Unlimited scans across every game",
                "All Pro games unlocked",
                "Priority deep-scan engine",
                "Cancel anytime",
              ].map((f) => (
                <li key={f} className="flex gap-2.5">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>

            <div className="mt-5 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setInterval("month")}
                className={`rounded-xl border p-3 text-left transition ${interval === "month" ? "border-primary bg-primary/5" : "border-border hover:border-foreground/30"}`}
              >
                <div className="font-display text-lg font-bold">$6.99<span className="text-sm font-normal text-muted-foreground">/mo</span></div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Monthly</div>
              </button>
              <button
                type="button"
                onClick={() => setInterval("year")}
                className={`relative rounded-xl border p-3 text-left transition ${interval === "year" ? "border-primary bg-primary/5" : "border-border hover:border-foreground/30"}`}
              >
                <span className="absolute right-2 top-2 rounded-full bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-emerald-700">Save 46%</span>
                <div className="font-display text-lg font-bold">$45<span className="text-sm font-normal text-muted-foreground">/yr</span></div>
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Yearly</div>
              </button>
            </div>

            <div className="mt-5 flex gap-2">
              <Button className="flex-1" onClick={() => setCheckout(true)}>
                <Sparkles className="mr-1.5 h-5 w-5" /> Continue to checkout
              </Button>
              <Button variant="outline" onClick={onClose}>Not now</Button>
            </div>
            <p className="mt-3 text-center text-[11px] text-muted-foreground">
              Secure checkout · Cards, Apple Pay, Google Pay, Link
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
