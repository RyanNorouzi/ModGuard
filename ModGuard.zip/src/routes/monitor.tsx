import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Radio, Shield, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AlertBanners } from "@/components/monitor/AlertBanners";
import { ConsentCheck } from "@/components/monitor/ConsentCheck";
import { ExplanationSheet } from "@/components/monitor/ExplanationSheet";
import { NetworkPanel } from "@/components/monitor/NetworkPanel";
import { ProcessTable } from "@/components/monitor/ProcessTable";
import { ResourceGraph } from "@/components/monitor/ResourceGraph";
import {
  MONITOR_IS_LIVE, useAlerts, useConnections, useConsentDiff,
  useProcesses, useResourceSeries,
} from "@/lib/monitor-adapter";
import type { MonitorProcess } from "@/lib/monitor-types";

export const Route = createFileRoute("/monitor")({
  head: () => ({
    meta: [
      { title: "Process Monitor — ModGuard" },
      { name: "description", content: "Real-time monitoring of background processes spawned by your mods." },
    ],
  }),
  component: MonitorPage,
});

function MonitorPage() {
  const procs = useProcesses();
  const conns = useConnections();
  const consent = useConsentDiff();
  const alerts = useAlerts();
  const series = useResourceSeries();
  const [selected, setSelected] = useState<MonitorProcess | null>(null);

  return (
    <div className="monitor-theme min-h-screen bg-[hsl(var(--mon-bg))] text-[hsl(var(--mon-fg))]">
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-bg))]/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-3">
            <Button asChild variant="ghost" size="sm" className="text-[hsl(var(--mon-muted))] hover:text-[hsl(var(--mon-fg))] hover:bg-[hsl(var(--mon-accent))]/10 focus-visible:ring-[hsl(var(--mon-accent))]">
              <Link to="/"><ArrowLeft className="h-4 w-4" /> Scanner</Link>
            </Button>
            <div className="h-5 w-px bg-[hsl(var(--mon-border))]" />
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-md bg-[hsl(var(--mon-accent))]/20 text-[hsl(var(--mon-accent))]">
                <Shield className="h-4 w-4" />
              </span>
              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--mon-muted))]">ModGuard / Defense</div>
                <h1 className="text-base font-semibold">Process Monitor</h1>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest ${
              MONITOR_IS_LIVE
                ? "border-[hsl(var(--mon-ok))]/40 bg-[hsl(var(--mon-ok))]/15 text-[hsl(var(--mon-ok))]"
                : "border-[hsl(var(--mon-warn))]/40 bg-[hsl(var(--mon-warn))]/15 text-[hsl(var(--mon-warn))]"
            }`}>
              <Radio className="h-3 w-3 animate-pulse" />
              {MONITOR_IS_LIVE ? "Live agent" : "Mock data"}
            </span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6">
        {!MONITOR_IS_LIVE && (
          <div className="rounded-lg border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface))] px-4 py-2.5 text-xs text-[hsl(var(--mon-muted))]">
            <Database className="mr-1.5 inline h-3.5 w-3.5" />
            Backend not yet connected — rendering deterministic mock telemetry. Set{" "}
            <code className="font-mono text-[hsl(var(--mon-fg))]">VITE_MONITOR_SOURCE=live</code> once the companion agent is online.
          </div>
        )}

        <AlertBanners alerts={alerts.data ?? []} />

        <section className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <ResourceGraph series={series} />
          </div>
          <Stat label="Processes" value={procs.data?.length ?? 0} hint="background tasks tied to mods" />
        </section>

        <section>
          <SectionTitle>Background processes</SectionTitle>
          <ProcessTable
            processes={procs.data ?? []}
            selectedPid={selected?.pid ?? null}
            onSelect={setSelected}
          />
          <p className="mt-1.5 font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--mon-muted))]">
            Click a row to ask Claude what it's doing
          </p>
        </section>

        <section>
          <SectionTitle>Network activity</SectionTitle>
          <NetworkPanel connections={conns.data ?? []} />
        </section>

        <section>
          <SectionTitle>Mod consent check</SectionTitle>
          <ConsentCheck diffs={consent.data ?? []} />
        </section>
      </main>

      <ExplanationSheet process={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-2 font-mono text-[11px] uppercase tracking-widest text-[hsl(var(--mon-muted))]">{children}</h2>
  );
}

function Stat({ label, value, hint }: { label: string; value: number; hint: string }) {
  return (
    <div className="rounded-lg border border-[hsl(var(--mon-border))] bg-[hsl(var(--mon-surface))] p-5">
      <div className="font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--mon-muted))]">{label}</div>
      <div className="mt-2 font-display text-4xl font-bold text-[hsl(var(--mon-fg))]">{value}</div>
      <div className="mt-1 text-xs text-[hsl(var(--mon-muted))]">{hint}</div>
    </div>
  );
}