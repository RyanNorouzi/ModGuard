import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/checkout/return")({
  validateSearch: (search: Record<string, unknown>): { session_id?: string } => ({
    session_id: typeof search.session_id === "string" ? search.session_id : undefined,
  }),
  component: CheckoutReturn,
});

function CheckoutReturn() {
  const { session_id } = Route.useSearch();

  useEffect(() => {
    if (session_id) {
      try {
        localStorage.setItem("modguard:pro", "1");
      } catch {}
    }
  }, [session_id]);

  return (
    <div className="min-h-screen grid place-items-center bg-background p-6">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 text-center shadow-sm">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-primary text-primary-foreground">
          <CheckCircle2 className="h-7 w-7" />
        </div>
        <h1 className="mt-5 font-display text-2xl font-bold">
          {session_id ? "You're on ModGuard Pro" : "Checkout incomplete"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {session_id
            ? "Unlimited scans are now unlocked across every supported game."
            : "We couldn't find your checkout session. Try again from the app."}
        </p>
        <Button asChild className="mt-6 w-full">
          <Link to="/">Back to ModGuard</Link>
        </Button>
      </div>
    </div>
  );
}
