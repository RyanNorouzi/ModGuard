# ModGuard Companion Agent v3 — Enhanced

Reads real OS processes and network connections, applies multi-signal risk
scoring, optionally calls Claude AI for plain-English analysis on flagged
processes, and POSTs signed snapshots to the ModGuard backend every 2 seconds.

## Requirements

```bash
pip3 install psutil requests
```

## Setup

### 1. Pair with your ModGuard account
In the app go to **Settings → Pair Monitor**, click **Pair**, and copy the
`agentId` and `secret`.

### 2. Run

```bash
python3 agent.py --api-url https://your-app.url --agent-id <id> --secret <secret>
```

With Claude AI analysis on flagged processes:

```bash
python3 agent.py --api-url https://your-app.url --agent-id <id> --secret <secret> --anthropic-key <key>
```

Then set `VITE_MONITOR_SOURCE=live` in your app's `.env` to see real data.

Press `Ctrl+C` to stop.

## What it detects

- Suspicious processes spawned by games (PowerShell, cmd, netcat, curl, etc.)
- Obfuscated or encoded command lines (base64, hidden windows, remote code download)
- Processes that persist after the parent game exits
- Outbound connections to suspicious domains (pastebin, transfer.sh, typosquats)
- Abnormal CPU/memory usage vs. rolling baseline (3σ rule)
- High outbound bandwidth suggesting data exfiltration

## macOS permissions

Go to **System Preferences → Privacy & Security → Full Disk Access** and add
Terminal for full network connection visibility.
