#!/usr/bin/env python3
"""
ModGuard Enhanced Companion Agent
Reads real OS processes and network connections, applies multi-signal
risk scoring, calls Claude for AI analysis on flagged processes,
and POSTs signed snapshots to the ModGuard backend every 2 seconds.

Usage:
  python3 agent.py --api-url https://your-app.url --agent-id <uuid> --secret <secret>
  python3 agent.py --api-url https://your-app.url --agent-id <uuid> --secret <secret> --anthropic-key <key>

Requirements:
  pip3 install psutil requests
"""

import argparse, hashlib, hmac, json, logging, socket, time, re
from datetime import datetime, timezone
import psutil, requests

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("modguard-agent")

# ── Game process map ──────────────────────────────────────────────────────────
GAME_PROCESSES = {
    "javaw.exe": "minecraft", "java": "minecraft",
    "RobloxPlayerBeta.exe": "roblox", "RobloxPlayer.exe": "roblox",
    "cs2.exe": "cs2", "csgo.exe": "cs2",
    "GenshinImpact.exe": "genshin", "Cyberpunk2077.exe": "cyberpunk",
    "Skyrim.exe": "skyrim", "SkyrimSE.exe": "skyrim",
    "valheim.exe": "valheim", "Terraria.exe": "terraria",
    "dota2.exe": "dota2", "FortniteClient-Win64-Shipping.exe": "fortnite",
    "StardewValley.exe": "stardew",
}

# ── Trusted domains ───────────────────────────────────────────────────────────
TRUSTED_DOMAINS = {
    "minecraft.net", "session.minecraft.net", "api.modrinth.com",
    "media.forgecdn.net", "modrinth.com", "roblox.com",
    "presence.roblox.com", "curseforge.com", "steampowered.com",
    "steamcommunity.com", "discord.com", "discordapp.com",
    "localhost", "127.0.0.1", "twitch.tv", "amazonaws.com",
}

# ── Suspicious process names that should never be spawned by a game ───────────
SUSPICIOUS_PROCESS_NAMES = {
    "powershell.exe", "powershell", "cmd.exe", "wscript.exe",
    "cscript.exe", "mshta.exe", "regsvr32.exe", "rundll32.exe",
    "certutil.exe", "bitsadmin.exe", "curl.exe", "wget",
    "nc", "ncat", "netcat", "nmap",
}

# ── Suspicious command-line patterns ─────────────────────────────────────────
SUSPICIOUS_CMDLINE_PATTERNS = [
    r"-enc\s+[A-Za-z0-9+/=]{20,}",
    r"-nop\s+-w\s+hidden",
    r"invoke-expression",
    r"downloadstring",
    r"webclient",
    r"bypass\s+-",
    r"iex\s*\(",
    r"start-process.*-windowstyle\s+hidden",
    r"regsvr32.*scrobj",
    r"mshta.*http",
    r"certutil.*-decode",
    r"bitsadmin.*transfer",
    r"curl.*\|\s*(bash|sh|python)",
    r"wget.*\|\s*(bash|sh|python)",
    r"chmod.*\+x.*&&",
    r"\/tmp\/[a-z0-9]{8,}",
]

# ── Suspicious remote host patterns ──────────────────────────────────────────
SUSPICIOUS_HOST_PATTERNS = [
    r"pastebin\.com",
    r"transfer\.sh",
    r"ngrok\.io",
    r"\.xyz$",
    r"\.top$",
    r"\.tk$",
    r"\.pw$",
    r"telegra\.ph",
    r"discord.*cdn\.click",
    r"r0blox\.",
    r"free-robux",
    r"robux-gen",
    r"free-vbucks",
]

# ── DNS cache ─────────────────────────────────────────────────────────────────
_dns_cache = {}

def resolve_host(ip):
    now = time.time()
    if ip in _dns_cache:
        name, exp = _dns_cache[ip]
        if now < exp: return name
    try: name = socket.gethostbyaddr(ip)[0]
    except: name = ip
    _dns_cache[ip] = (name, now + 600)
    return name

def is_private_ip(ip):
    return ip.startswith(("127.", "10.", "192.168.", "169.254.", "::1"))

def is_unknown_domain(host):
    h = host.lower().replace("www.", "")
    if h in TRUSTED_DOMAINS: return False
    return not any(h.endswith(f".{d}") for d in TRUSTED_DOMAINS)

def is_suspicious_host(host):
    h = host.lower()
    return any(re.search(p, h) for p in SUSPICIOUS_HOST_PATTERNS)

# ── Risk scoring ──────────────────────────────────────────────────────────────
def score_process(proc, parent_is_game, conns):
    reasons = []
    score = 0
    name    = proc["name"].lower()
    cmdline = (proc["cmdline"] or "").lower()

    if parent_is_game and any(s in name for s in SUSPICIOUS_PROCESS_NAMES):
        score += 40
        reasons.append(f"Suspicious process '{proc['name']}' spawned by a game process")

    for pattern in SUSPICIOUS_CMDLINE_PATTERNS:
        if re.search(pattern, cmdline, re.IGNORECASE):
            score += 35
            reasons.append(f"Suspicious command-line pattern detected")
            break

    if proc.get("persistsAfterClose"):
        score += 30
        reasons.append("Process still running after parent game exited")

    if proc.get("abnormalResources"):
        score += 15
        reasons.append("CPU or memory usage significantly above baseline")

    for conn in conns:
        if conn["pid"] == proc["pid"]:
            if is_suspicious_host(conn["remoteHost"]):
                score += 45
                reasons.append(f"Outbound connection to suspicious domain: {conn['remoteHost']}")
            elif conn["unknownDomain"]:
                score += 20
                reasons.append(f"Outbound connection to unrecognized domain: {conn['remoteHost']}")

    if proc.get("netOutKbps", 0) > 500:
        score += 25
        reasons.append(f"High outbound traffic: {proc['netOutKbps']} KB/s")

    if score >= 60:   risk = "suspicious"
    elif score >= 35: risk = "high"
    elif score >= 15: risk = "medium"
    else:             risk = "low"

    return risk, reasons

# ── Claude AI analysis ────────────────────────────────────────────────────────
def ask_claude(proc, conns, reasons, key):
    if not key:
        return None
    try:
        payload = {
            "model": "claude-sonnet-4-6",
            "max_tokens": 300,
            "system": (
                "You are ModGuard's security analyst. Given a suspicious background process "
                "from a game mod, return JSON only — no markdown, no extra text:\n"
                '{"summary": "1-2 sentences plain English for a gamer", '
                '"recommendedAction": "allow|monitor|kill|uninstall"}'
            ),
            "messages": [{"role": "user", "content": json.dumps({
                "process": {
                    "name": proc["name"],
                    "cmdline": proc["cmdline"],
                    "cpuPct": proc["cpuPct"],
                    "netOutKbps": proc["netOutKbps"],
                    "persistsAfterClose": proc["persistsAfterClose"],
                },
                "connections": [
                    {"remoteHost": c["remoteHost"], "unknownDomain": c["unknownDomain"]}
                    for c in conns if c["pid"] == proc["pid"]
                ],
                "detectionReasons": reasons,
            })}],
        }
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            json=payload,
            headers={
                "x-api-key": key,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json",
            },
            timeout=8,
        )
        if r.status_code == 200:
            return json.loads(r.json()["content"][0]["text"])
    except Exception as e:
        log.debug(f"Claude call failed: {e}")
    return None

# ── HMAC signing ──────────────────────────────────────────────────────────────
def sign(body, secret):
    t   = int(time.time())
    sig = hmac.new(secret.encode(), f"{t}.{body}".encode(), hashlib.sha256).hexdigest()
    return f"t={t},v1={sig}"

# ── Baselines (Welford online algorithm) ─────────────────────────────────────
baselines = {}

def update_baseline(name, cpu, mem):
    b = baselines.get(name, {"n":0,"cm":0,"mm":0,"cs":0,"ms":0})
    n  = b["n"] + 1
    cm = b["cm"] + (cpu - b["cm"]) / n
    mm = b["mm"] + (mem - b["mm"]) / n
    cs = ((b["cs"]**2 * max(n-2,0) + (cpu-cm)**2) / max(n-1,1))**0.5
    ms = ((b["ms"]**2 * max(n-2,0) + (mem-mm)**2) / max(n-1,1))**0.5
    baselines[name] = {"n":n,"cm":cm,"mm":mm,"cs":cs,"ms":ms}
    return n > 10 and (
        abs(cpu - cm) > 3 * max(cs, 1) or
        abs(mem - mm) > 3 * max(ms, 1)
    )

# ── Collection ────────────────────────────────────────────────────────────────
def collect(window, anthropic_key):
    # Build PID map
    pid_map = {}
    try:
        for p in psutil.process_iter(["pid","name","ppid"]):
            pid_map[p.info["pid"]] = p.info
    except: pass

    game_pids = {
        pid for pid, info in pid_map.items()
        if GAME_PROCESSES.get(info.get("name",""))
    }

    # Connections first so scoring can use them
    conns = []
    try:
        for c in psutil.net_connections(kind="inet"):
            if not c.raddr or not c.raddr.ip: continue
            if is_private_ip(c.raddr.ip): continue
            host = resolve_host(c.raddr.ip)
            conns.append({
                "id": hashlib.sha256(f"{c.pid}:{host}:{c.raddr.port}".encode()).hexdigest()[:16],
                "pid": c.pid or 0,
                "processName": pid_map.get(c.pid or 0, {}).get("name", "unknown"),
                "remoteHost": host, "remoteIp": c.raddr.ip, "remotePort": c.raddr.port,
                "bytesSent": 0, "bytesReceived": 0, "requestCount": 1,
                "firstSeen": datetime.now(timezone.utc).isoformat(),
                "lastSeen":  datetime.now(timezone.utc).isoformat(),
                "unknownDomain": is_unknown_domain(host),
            })
    except: pass

    # Processes with full scoring
    procs = []
    for p in psutil.process_iter(["pid","name","cmdline","cpu_percent","memory_info","create_time","ppid"]):
        try:
            info = p.info
            name = info["name"] or "unknown"
            cpu  = p.cpu_percent(interval=None)
            mem  = (info["memory_info"].rss / 1024 / 1024) if info["memory_info"] else 0
            abnormal       = update_baseline(name, cpu, mem)
            parent_is_game = info.get("ppid") in game_pids
            persists = (
                info.get("ppid") in game_pids and
                not psutil.pid_exists(info.get("ppid", -1)) and
                not GAME_PROCESSES.get(name)
            )
            proc_dict = {
                "pid": info["pid"], "name": name, "modId": None,
                "gameId": GAME_PROCESSES.get(name),
                "cpuPct": round(cpu, 2), "memMb": round(mem, 1),
                "netInKbps": 0, "netOutKbps": 0,
                "startedAt": datetime.fromtimestamp(
                    info["create_time"], tz=timezone.utc
                ).isoformat() if info.get("create_time") else None,
                "parentPid": info.get("ppid"),
                "cmdline": " ".join(info["cmdline"] or [])[:512],
                "risk": "low",
                "persistsAfterClose": persists,
                "abnormalResources": abnormal,
            }
            risk, reasons = score_process(proc_dict, parent_is_game, conns)
            proc_dict["risk"] = risk

            if risk in ("high", "suspicious") and reasons:
                log.warning(f"[{risk.upper()}] {name} (PID {info['pid']})")
                for r in reasons:
                    log.warning(f"  • {r}")
                ai = ask_claude(proc_dict, conns, reasons, anthropic_key)
                if ai:
                    log.warning(f"  Claude: {ai.get('summary','')}")
                    log.warning(f"  Action: {ai.get('recommendedAction','').upper()}")

            procs.append(proc_dict)
        except (psutil.NoSuchProcess, psutil.AccessDenied): pass

    # Resource sample
    mem_info = psutil.virtual_memory()
    window.append({
        "t":      datetime.now(timezone.utc).isoformat(),
        "cpuPct": round(psutil.cpu_percent(interval=None), 1),
        "gpuPct": 0,
        "memPct": round(mem_info.percent, 1),
    })
    if len(window) > 60: window.pop(0)

    return procs, conns

# ── Main loop ─────────────────────────────────────────────────────────────────
def run(api_url, agent_id, secret, anthropic_key):
    url = f"{api_url.rstrip('/')}/api/public/monitor/ingest"
    log.info(f"ModGuard Enhanced Agent — posting to {url} every 2s")
    log.info("Press Ctrl+C to stop")
    window = []
    while True:
        try:
            procs, conns = collect(window, anthropic_key)
            snapshot = {
                "agentId": agent_id,
                "takenAt": datetime.now(timezone.utc).isoformat(),
                "processes": procs, "connections": conns,
                "resources": list(window), "consent": [],
            }
            body = json.dumps(snapshot, separators=(",", ":"))
            sig  = sign(body, secret)
            r = requests.post(
                url, data=body,
                headers={"Content-Type": "application/json", "X-Monitor-Sig": sig},
                timeout=5,
            )
            flagged = sum(1 for p in procs if p["risk"] in ("high","suspicious"))
            log.info(f"{len(procs)} processes, {len(conns)} connections, {flagged} flagged — HTTP {r.status_code}")
        except KeyboardInterrupt:
            log.info("Stopped.")
            break
        except Exception as e:
            log.warning(f"Error: {e}")
        time.sleep(2)

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="ModGuard Enhanced Companion Agent")
    p.add_argument("--api-url",       required=True,  help="ModGuard backend URL")
    p.add_argument("--agent-id",      required=True,  help="Agent UUID from pairing")
    p.add_argument("--secret",        required=True,  help="HMAC secret from pairing")
    p.add_argument("--anthropic-key", default="",     help="Anthropic API key for AI analysis")
    args = p.parse_args()
    run(args.api_url, args.agent_id, args.secret, args.anthropic_key)
