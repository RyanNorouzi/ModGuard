#!/bin/bash
# ModGuard — run locally
# Usage: bash start.sh

echo ""
echo "  ModGuard — starting..."
echo ""

# Check bun is installed
if ! command -v bun &> /dev/null; then
  echo "  Installing bun..."
  curl -fsSL https://bun.sh/install | bash
  export BUN_INSTALL="$HOME/.bun"
  export PATH="$BUN_INSTALL/bin:$PATH"
fi

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
  echo "  Installing dependencies..."
  bun install
fi

echo "  Open http://localhost:3000 in your browser"
echo "  Press Ctrl+C to stop"
echo ""

bun run dev
