# ModGuard — Process Monitor Backend Handoff

**Audience:** the Claude instance building the backend for the new Process Monitor feature.
**Frontend status:** complete and shipping against mock data behind a single adapter (`src/lib/monitor-adapter.ts`). Flip `VITE_MONITOR_SOURCE=live` and implement the endpoints below — no UI changes required.

The single source of truth for wire types is **`src/lib/monitor-types.ts`**. Do not redefine these types on the backend; import them or mirror them byte-for-byte.

---

## 1. What already exists (do not rebuild)

### Stack
- TanStack Start v1 on Cloudflare Workers
- Supabase (Postgres + auth + storage) via Lovable Cloud
- Server functions in `src/lib/*.functions.ts` (typed RPC)
- Server routes in `src/routes/api/**` (raw HTTP, for webhooks and external callers)
- AI: Lovable AI Gateway (supports Claude models — no separate `ANTHROPIC_API_KEY` required unless you want one). Key already provisioned as `LOVABLE_API_KEY`.

### Existing tables (`public` schema)

| Table | Purpose | Notes |
| --- | --- | --- |
| `known_mods` | Malware signature DB (SHA-256 → verdict) | `verdict` enum: `safe \| low_risk \| suspicious \| likely_malicious \| confirmed_malicious \| unknown` |
| `scan_events` | Public telemetry log of every scan | Anon-readable, service-role writable |
| `mod_reputation` | Cache of reputation lookups | Internal |

RLS is enabled on all three. `known_mods` and `scan_events` have `SELECT` policies for `anon` + `authenticated`. Service role has full access. **Do not loosen these policies.**

### Existing server functions you can reuse

| File | Function | Purpose |
| --- | --- | --- |
| `src/lib/scan.functions.ts` | `scanJar` | Hash + static analysis of a `.jar` |
| `src/lib/scan-game.functions.ts` | `scanGameFile` | Generic file scanner |
| `src/lib/dashboard.functions.ts` | `recordScanEvent`, `getDashboardStats`, `getRecentEvents`, `lookupHash`, `getThreatLevel` | SOC dashboard backing |

You can call `lookupHash`/`known_mods` from your monitor endpoints to enrich process attribution (e.g. "this process was spawned by a SHA-256 we already flagged as malicious").

### What is **out of scope** for the backend agent
- Do not touch `src/integrations/supabase/*` (auto-generated).
- Do not modify the scanner, dashboard, or payments code.
- Do not change the sidebar / index route.
- Do not edit `src/lib/monitor-types.ts` without coordinating with the frontend agent — it's the wire contract.

---

## 2. What you (Claude) need to build

### 2.1 Companion agent (local)

Browsers cannot read OS processes. Build a small local helper that runs on the player's machine and ships telemetry to the backend.

**Recommended stack:** Python 3.11 + `psutil` for processes/memory/CPU and `scapy` or `psutil.net_connections()` for sockets, packaged with `pyinstaller` as a single tray executable. Electron is acceptable but heavier. Pick one and document it in `agent/README.md`.

**Behavior:**
1. Sample every 2 seconds while a known game (`known_mods.game_id`) is running, every 10s otherwise.
2. Track parent/child relationships so we can detect orphaned children after a game exits.
3. Resolve outbound TCP/UDP destinations to hostnames where possible (reverse DNS, cache 10 min).
4. POST batched snapshots to `POST /api/public/monitor/ingest` (see §2.3).
5. Auth: HMAC-SHA256 of the raw body using a per-install secret. Header: `X-Monitor-Sig: t=<unix>,v1=<hex>`. Reject if `|now - t| > 300s` or signature mismatch.

**Install-time pairing:**
- User clicks "Pair monitor" in the app → frontend calls a new `pairAgent` server fn that creates a row in `monitor_agents` (see §2.2) and returns `{ agentId, secret }`.
- Agent stores secret in OS keychain.
- The pairing fn requires `requireSupabaseAuth`.

### 2.2 New tables (one migration)

Follow the project's GRANT rules: every public table needs explicit GRANTs in the same migration. See `public-schema-grants` knowledge.

```sql
-- monitor_agents: one row per installed companion agent
CREATE TABLE public.monitor_agents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  label text NOT NULL,
  secret_hash text NOT NULL,            -- bcrypt of the install secret
  hostname text,
  os text,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monitor_agents TO authenticated;
GRANT ALL ON public.monitor_agents TO service_role;
ALTER TABLE public.monitor_agents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "agents owned by user"
  ON public.monitor_agents FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- monitor_snapshots: one row per ingest call
CREATE TABLE public.monitor_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id uuid NOT NULL REFERENCES public.monitor_agents(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  taken_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- process_samples / network_samples / consent_violations:
--   one-to-many off monitor_snapshots; columns match monitor-types.ts.

-- process_baselines: rolling mean+stddev per (user_id, process_name)
--   maintained by a scheduled fn so abnormal_resources can be detected
--   without scanning the whole history each request.
```

RLS pattern for the rest: same `user_id = auth.uid()` policy + service-role full access + explicit GRANTs.

### 2.3 HTTP endpoints (server routes)

| Method + Path | Caller | Notes |
| --- | --- | --- |
| `POST /api/public/monitor/ingest` | Companion agent | HMAC-signed. Validates payload with Zod. Writes snapshot + child rows. Runs alert engine. |
| `GET /api/monitor/processes` | Frontend | Returns latest `MonitorProcess[]` for the calling user. |
| `GET /api/monitor/connections` | Frontend | Returns latest `MonitorConnection[]`. |
| `GET /api/monitor/resources?range=2m` | Frontend | Returns up to 60 `ResourceSample`s. |
| `GET /api/monitor/alerts` | Frontend | Returns open `MonitorAlert[]`. |
| `GET /api/monitor/consent` | Frontend | Returns `ConsentDiff[]` for the user's installed mods. |
| `POST /api/monitor/explain` | Frontend | Body: `{ pid: number }`. Loads the latest sample for that pid + its parent mod, sends to Claude via Lovable AI Gateway, returns `ProcessExplanation`. |

All `/api/monitor/*` endpoints (no `public/`) must require an authenticated session. `/api/public/monitor/ingest` is intentionally public but HMAC-gated — never trust the payload's `user_id`; derive it from the verified `agent_id`.

### 2.4 Server functions (preferred over routes for the frontend reads)

Frontend already calls REST paths via `fetch`. If you'd prefer server fns (typed, automatic auth), swap `src/lib/monitor-adapter.ts`'s `jget(...)` calls for `useServerFn(...)` calls — but keep the same return shapes. Either is fine.

Suggested fns to expose:
- `getLiveProcesses() → MonitorProcess[]`
- `getLiveConnections() → MonitorConnection[]`
- `getResourceSeries({ range: "2m"|"10m" }) → ResourceSample[]`
- `getOpenAlerts() → MonitorAlert[]`
- `getConsentDiff() → ConsentDiff[]`
- `explainProcess({ pid: number }) → ProcessExplanation`
- `pairAgent({ label: string }) → { agentId: string; secret: string }` (requires auth)

All must use `.middleware([requireSupabaseAuth])` except `pairAgent` which also requires it.

### 2.5 Alert engine

Triggered at the end of every successful ingest call (cheaper than cron; runs per-user).

Rules:
1. **persistence** — process is still running ≥ 60s after its `gameId`'s last sample was missing.
2. **unknown_domain** — connection's `remoteHost` not in `mod_allowlist[modId]` and not in the global trusted list (`minecraft.net`, `roblox.com`, `modrinth.com`, `curseforge.com`, etc.).
3. **abnormal_resources** — `cpuPct` or `memMb` deviates > 3σ from the row in `process_baselines` for that process name.

Write deduplicated rows to a new `monitor_alerts` table (1 row per `(user_id, kind, target)` per 24h).

### 2.6 Claude call (for `/api/monitor/explain`)

Use the existing Lovable AI Gateway helper (`src/lib/ai-gateway.server.ts`). Model: `anthropic/claude-3-5-sonnet-20241022` (or whatever Claude model the gateway exposes — check `cloud-ai-models` knowledge).

Prompt skeleton:
```
System: You are ModGuard's security analyst. Given a single process + its
network connections + the parent mod's declared capabilities, output JSON
matching ProcessExplanation:
  { risk: "low"|"medium"|"high"|"suspicious",
    summary: string,             // 1-2 sentences, plain English, no jargon
    reasons: string[],           // 2-5 short bullets
    recommendedAction: "allow"|"monitor"|"kill"|"uninstall" }

User: <JSON dump of the process + connections + consent diff>
```

Use AI SDK `Output.object(z.object({...}))` for constrained decoding. Cache the result for 60s keyed by `(pid, last_seen_ts)`.

---

## 3. Wire contract (frozen)

See **`src/lib/monitor-types.ts`**. A sample valid ingest payload lives at **`fixtures/monitor/snapshot.example.json`** — replay it against your ingest endpoint to smoke-test.

## 4. Secrets you need

- `LOVABLE_API_KEY` — already set. Use this for Claude calls. **Do not** ask the user for `ANTHROPIC_API_KEY`.
- `MONITOR_AGENT_HMAC_KEY` (optional, server-wide pepper) — add via `add_secret` if you want defense-in-depth on top of per-agent secrets.

## 5. Deliverable checklist

- [ ] Migration creating `monitor_agents`, `monitor_snapshots`, `process_samples`, `network_samples`, `consent_violations`, `process_baselines`, `monitor_alerts` + GRANTs + RLS.
- [ ] `src/routes/api/public/monitor/ingest.ts` with HMAC verification + Zod validation + alert engine.
- [ ] `src/routes/api/monitor/{processes,connections,resources,alerts,consent}.ts` (or matching server fns).
- [ ] `src/routes/api/monitor/explain.ts` calling Claude via Lovable AI Gateway.
- [ ] `src/lib/monitor.functions.ts` exporting `pairAgent` + any other typed RPCs.
- [ ] `agent/` directory containing the companion agent source + `README.md` with build/run instructions.
- [ ] Once endpoints return the contract types, set `VITE_MONITOR_SOURCE=live` in `.env` to flip the UI.

When all green, the existing `/monitor` page will Just Work.