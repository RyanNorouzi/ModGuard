## Incident Report Feature — Architecture Audit

Scope: `src/lib/incident-report.functions.ts` and the report UI inside `src/routes/sandbox.tsx` (state, handlers, render block lines 133–174 and 290–322).

---

### 1. Misplaced logic / files in wrong layer

- **Anthropic transport is inlined in the server function.** `incident-report.functions.ts` builds the prompt, calls `fetch("https://api.anthropic.com/v1/messages")`, parses the response, and shapes the DTO all in one handler. Per project conventions, network/SDK code belongs in a `.server.ts` helper (e.g. `src/lib/anthropic.server.ts`) that the `.functions.ts` thin-wraps. As-is, swapping models, mocking in tests, or adding a second Claude-backed feature means copy-pasting the fetch block.
- **Prompt template lives next to transport.** The 20-line markdown prompt is hardcoded inside the handler. Prompts are content, not transport — they belong in `src/lib/prompts/incident-report.ts` (or a `.md` asset) so they can be edited without touching server code and reused if you add a "regenerate with notes" flow.
- **Download / blob logic lives in the page component.** `downloadReport` (DOM `createElement`, `URL.createObjectURL`, filename sanitization) is generic browser plumbing in the middle of a route file. Belongs in `src/lib/download.ts` (or a `useDownload` hook). The filename sanitizer (`replace(/[^a-z0-9.-]/gi, "_")`) is also a reusable util.
- **`simulate()` and `verdictFor()` live in the route file.** Both are pure functions with zero React. They should sit in `src/lib/sandbox-sim.ts` so the report feature, future tests, and any "share trace" flow can import them without pulling in the route.
- **Severity → Tailwind class map (`sevClass`) and `KIND_META`** are presentation tokens hardcoded in the route. They belong in a small `src/components/sandbox/` module (or design-token file) — and the raw `text-emerald-700 / bg-red-600` literals violate the project rule against hardcoded color utilities; they should be semantic tokens.

### 2. Coupling / state management issues

- **Report state has no link to the trace it describes.** `report`, `reportLoading`, `file`, and `shown` are four independent `useState`s. If the user uploads a new file or hits Reset after generating a report, the stale report keeps rendering under the new verdict — there is no `useEffect` that clears `report` when `file` or `shown` changes. That is a correctness bug, not just a smell.
- **`buildReport` reads `verdict`, which is recomputed every render** from `shown.length === events.length`. Because `events = useMemo(...)` returns a new array when `file` changes, the verdict object identity churns; nothing memoizes it, so any child that took it as a prop would re-render unnecessarily.
- **No request lifecycle protection.** `buildReport` has no `AbortController`, no in-flight ref, and no guard against the user navigating away mid-request — Claude calls can take 10–20s. If they click Regenerate twice quickly, both responses race and the last to resolve wins (which may not be the latest click).
- **No caching / no TanStack Query.** The rest of the project standardizes on `useQuery` / `useMutation` (see `src/routes/index.tsx` `recordMutation`). This feature bypasses it, so you lose retry, cancellation, dedupe, devtools, and the loading-state conventions used elsewhere.
- **Server function is unauthenticated.** `generateIncidentReport` has no `.middleware([requireSupabaseAuth])`. On the published site this is a public endpoint that anyone can POST to and burn your Anthropic credits. There is also no rate limit and no per-user accounting.
- **Sandbox route is public, but the feature it powers calls a paid API.** Same risk surface — anyone can hit `/sandbox`, upload a file, and trigger Claude calls.

### 3. Vite / runtime / syntax concerns

- **No syntax errors found.** The `createServerFn().inputValidator(...).handler(...)` chain is intact; the route file's JSX balances; imports resolve.
- **`process.env.ANTHROPIC_API_KEY` is read inside `.handler()`** — correct per the server-function rules. ✅
- **`model: "claude-3-5-sonnet-latest"`** — the `-latest` alias is supported by Anthropic but is a moving target; a pinned date-stamped model (e.g. `claude-3-5-sonnet-20241022`) is safer for reproducible judging.
- **No `max_tokens` headroom check.** The prompt asks for "under 500 words" but `max_tokens: 1500` with no streaming means the user stares at a spinner with zero feedback for the full call. Streaming via `stream: true` + a server route (raw `Response`) would be the canonical fix, since `createServerFn` should not return streams.
- **Error surface leaks Anthropic body to the toast.** `throw new Error(\`Anthropic API error ${resp.status}: ${text.slice(0, 300)}\`)` is caught in the UI and shown via `toast.error(err.message)`. The first 300 chars of an Anthropic error often include account/request-id details — fine for a hackathon, not fine for production.
- **`<pre>{report}</pre>` renders raw Markdown.** Claude returns `#`, `##`, `-` literally; the user sees the syntax instead of formatted headings. There is a `react-markdown`-shaped gap here (or render to HTML server-side).
- **Input validator is hand-rolled, not Zod.** Inconsistent with the rest of the codebase and lets malformed `events[]` items through (no per-event field validation). Could cause a runtime crash inside the `.map(...)` if a client sends `{ events: [null] }`.
- **No timeout on `fetch`.** A hung Anthropic call ties up the worker until the platform kills it.

---

### Three ways to solve this (pick one, do not implement yet)

**Option A — Minimal cleanup (1 small PR).** Keep the current shape but fix the bugs: (1) add a `useEffect` that clears `report` when `file`/`shown` changes; (2) wrap the call in `useMutation` for cancellation + dedupe; (3) switch the validator to Zod; (4) render with `react-markdown`; (5) pin the model; (6) strip provider error bodies from the toast. Low risk, ~1 hour, no file moves.

**Option B — Extract layers (medium refactor).** Do Option A plus split the code: `src/lib/anthropic.server.ts` (transport + retry + timeout), `src/lib/prompts/incident-report.ts` (prompt template), `src/lib/sandbox-sim.ts` (`simulate`, `verdictFor`, types), `src/lib/download.ts` (`downloadBlob`, `safeFilename`), `src/components/sandbox/IncidentReportCard.tsx` (UI + mutation). The route file shrinks to composition. Unlocks reuse and tests; ~half a day.

**Option C — Productionize (larger).** Option B plus: (1) add `requireSupabaseAuth` middleware + a `report_generations` table with per-user rate limits and audit log; (2) move to a streaming server *route* (`src/routes/api/incident-report.ts`) so the report renders token-by-token; (3) replace ad-hoc Tailwind color literals in sandbox UI with semantic tokens to match the rest of the site; (4) add a tiny vitest suite for `simulate`/`verdictFor` and a mocked Anthropic test for the server fn. Day-plus of work, but this is what you want before exposing the API key on a public URL.

No code changed — awaiting your pick.